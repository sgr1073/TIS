#!/usr/bin/env python3
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import sys
import subprocess
import threading
from gi.repository import GObject
from gi.repository import GLib
import time
from gi.repository import Gdk
from time import sleep
import os
import base64
import sendgrid
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)
import datetime
import pandas as pd
from datetime import datetime as dt
from requests import get

sleep(.5)

createfile = subprocess.check_output(["""echo "" > /home/clientshared/.Temp/.B01/.prg.txt"""], stderr=None, shell=True)

class main_window():
    #initi main window class
    def __init__(self):

        self.gladefile = "/home/clientshared/sample.glade"

        wf = open("/home/clientshared/.General/Job_Number.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        wf = open("/home/clientshared/.General/Employee.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        wf = open("/home/clientshared/.General/Comments.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        #Start the hard drive wiping and send yes to visible
        self.builder = Gtk.Builder()
        self.builder.add_from_file(self.gladefile)

        cssProvider = Gtk.CssProvider()
        cssProvider.load_from_path('/home/clientshared/another.css')
        screen = Gdk.Screen.get_default()
        styleContext = Gtk.StyleContext()
        styleContext.add_provider_for_screen(screen, cssProvider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        #main window
        self.main_window = self.builder.get_object("window1")
        #signals
        self.builder.connect_signals(self)

        # start
        self.main_window = self.builder.get_object("window1")
        self.report = self.builder.get_object("report")
        self.drive_box_main = self.builder.get_object("drive_box_main")
        self.wiping_box = self.builder.get_object("wiping_box")
        self.button_box = self.builder.get_object("button_box")
        #employee entry
        self.employee = self.builder.get_object("employee")
        self.ne_entry = self.builder.get_object("ne_entry")
        self.submit_ne = self.builder.get_object("submit_ne")
        #job number entry
        self.job_number = self.builder.get_object("job_number")
        self.njn_entry = self.builder.get_object("njn_entry")
        self.submit_njn = self.builder.get_object("submit_njn")
        #comment entry
        self.comments = self.builder.get_object("comments")
        self.nec_entry = self.builder.get_object("nec_entry")
        self.submit_nc = self.builder.get_object("submit_nc")

        self.asset_tag = self.builder.get_object("asset_tag")
        self.battery = self.builder.get_object("battery")

        self.error_submitting = self.builder.get_object("error_submitting")
        self.submit_all = self.builder.get_object("submit_all")
        self.finishing_message = self.builder.get_object("finishing_message")
        self.drive_error = self.builder.get_object("drive_error")

        self.drive_box_main = self.builder.get_object("drive_box_main")
        self.test_box = self.builder.get_object("test_box")
        self.wiping_box = self.builder.get_object("wiping_box")
        self.no_hdd = self.builder.get_object("no_hdd")

        ### report window
        self.report_window = self.builder.get_object("run_report")
        self.report_window = self.builder.get_object("report_window")
        self.report_stack = self.builder.get_object("report_stack")
        ## sub report dates
        self.sd_box = self.builder.get_object("sd_box")
        self.ed_box = self.builder.get_object("ed_box")
        self.report_cancel = self.builder.get_object("report_cancel")
        self.sd_tog = self.builder.get_object("sd_tog")
        self.ed_tog = self.builder.get_object("ed_tog")
        self.sdtl = self.builder.get_object("sd_label")
        self.edtl = self.builder.get_object("ed_label")
        self.rd_email = self.builder.get_object("rd_email")
        self.rdc_email = self.builder.get_object("rdc_email")
        #
        self.repe = self.builder.get_object("repe")
        self.repec = self.builder.get_object("repec")
        self.sd_calendar = self.builder.get_object("sd_calendar")
        self.ed_calendar = self.builder.get_object("ed_calendar")
        self.error_dates = self.builder.get_object("error_dates")
        ## sub report job number
        self.jnr = self.builder.get_object("jnr")
        self.cjnr = self.builder.get_object("cjnr")
        self.jner = self.builder.get_object("jner")
        self.jncer = self.builder.get_object("jncer")
        #
        self.jner.set_text("bmartinolich@tworiversrecovery.com")
        self.jncer.set_text("bmartinolich@tworiversrecovery.com")
        #
        self.r_jn_err = self.builder.get_object("r_jn_err")
        self.r_jne_err = self.builder.get_object("r_jne_err")

        ta = os.remove("/home/clientshared/sampling.py")
        ta = os.remove("/home/clientshared/another.css")
        ta = os.remove("/home/clientshared/sample.glade")
        ta = os.remove("/home/clientshared/.HD")
        time.sleep(.05)

        #employee list creation
        wf = open("/home/clientshared/.General/Employees.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from streamftl_client.inventory_employee' >> '/home/clientshared/.General/Employees.txt'"], stderr=None, shell=True)
        em_file = open("/home/clientshared/.General/Employees.txt", "r")
        employees = []
        for line in em_file:
          stripped_line = line.strip()
          line_list = stripped_line.split()
          self.employee.append_text(line.replace('\n',''))
        em_file.close()
        self.employee.append_text("Other")

        #job_number creation
        wf = open("/home/clientshared/.General/Job_Number.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from streamftl_client.inventory_job_number' >> '/home/clientshared/.General/Job_Number.txt'"], stderr=None, shell=True)
        jn_file = open("/home/clientshared/.General/Job_Number.txt", "r")
        for line in jn_file:
          stripped_line = line.strip()
          line_list = stripped_line.split()
          self.job_number.append_text(line.replace('\n',''))
        jn_file.close()
        self.job_number.append_text("Other")

        #comments creation
        wf = open("/home/clientshared/.General/Comments.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from streamftl_client.inventory_notes' >> '/home/clientshared/.General/Comments.txt'"], stderr=None, shell=True)
        comments_file = open("/home/clientshared/.General/Comments.txt", "r")
        for line in comments_file:
          stripped_line = line.strip()
          line_list = stripped_line.split()
          self.comments.append_text(line.replace('\n',''))
        comments_file.close()
        self.comments.append_text("Other")

        self.main_window.show()
        thread = threading.Thread(target=self.update)
        thread.daemon = True
        thread.start()

    def on_window1_destroy(self, object, data=None):
        print("quit with cancel")
        Gtk.main_quit()

    def on_wipe_drive_clicked(self, object, data=None):
        self.button_box.hide()
        self.drive_box_main.show()
        self.wiping_box.show()
        wf = open("/home/clientshared/.Bay1.sh","w")
        wf1 = wf.write(wiping_a)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay1.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay1.sh"])
        time.sleep(.1)
        wf = os.remove("/home/clientshared/.Bay1.sh")

    def on_employee_changed(self, object, data=None):
        testing = self.employee.get_active_text()
        print(testing)
        if testing == "Other":
            self.ne_entry.show()
            self.submit_ne.show()
        else:
            self.ne_entry.hide()
            self.submit_ne.hide()

    def on_job_number_changed(self, object, data=None):
        testing = self.job_number.get_active_text()
        print(testing)
        if testing == "Other":
            self.njn_entry.show()
            self.submit_njn.show()
        else:
            self.njn_entry.hide()
            self.submit_njn.hide()

    def on_comments_changed(self, object, data=None):
        testing = self.comments.get_active_text()
        print(testing)
        if testing == "Other":
            self.nec_entry.show()
            self.submit_nc.show()
        else:
            self.nec_entry.hide()
            self.submit_nc.hide()

    def on_submit_ne_clicked(self, object, data=None):
        print("Submit Employee")
        empl = self.ne_entry.get_text()
        createfile = subprocess.check_output(["""mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into streamftl_client.inventory_employee (employee) values ('{}')" """.format(empl)], stderr=None, shell=True)
        self.employee.remove_all()
        wf = open("/home/clientshared/.General/Employees.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from streamftl_client.inventory_employee' >> '/home/clientshared/.General/Employees.txt'"], stderr=None, shell=True)
        em_file = open("/home/clientshared/.General/Employees.txt", "r")
        employees = []
        for line in em_file:
          stripped_line = line.strip()
          line_list = stripped_line.split()
          self.employee.append_text(line.replace('\n',''))
        em_file.close()
        self.employee.append_text("Other")
        self.ne_entry.hide()
        self.submit_ne.hide()

    def on_submit_njn_clicked(self, object, data=None):
        print("Submit Employee")
        jobnm = self.njn_entry.get_text()
        createfile = subprocess.check_output(["""mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into streamftl_client.inventory_job_number (job_number) values ('{}')" """.format(jobnm)], stderr=None, shell=True)
        self.job_number.remove_all()
        wf = open("/home/clientshared/.General/Job_Number.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from streamftl_client.inventory_job_number' >> '/home/clientshared/.General/Job_Number.txt'"], stderr=None, shell=True)
        jn_file = open("/home/clientshared/.General/Job_Number.txt", "r")
        for line in jn_file:
          stripped_line = line.strip()
          line_list = stripped_line.split()
          self.job_number.append_text(line.replace('\n',''))
        jn_file.close()
        self.job_number.append_text("Other")
        self.njn_entry.hide()
        self.submit_njn.hide()

    def on_submit_nc_clicked(self, object, data=None):
        print("Submit Employee")
        comme = self.nec_entry.get_text()
        createfile = subprocess.check_output(["""mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into streamftl_client.inventory_notes (notes) values ('{}')" """.format(comme)], stderr=None, shell=True)
        self.comments.remove_all()
        wf = open("/home/clientshared/.General/Comments.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from streamftl_client.inventory_notes' >> '/home/clientshared/.General/Comments.txt'"], stderr=None, shell=True)
        comments_file = open("/home/clientshared/.General/Comments.txt", "r")
        for line in comments_file:
          stripped_line = line.strip()
          line_list = stripped_line.split()
          self.comments.append_text(line.replace('\n',''))
        comments_file.close()
        self.comments.append_text("Other")
        self.nec_entry.hide()
        self.submit_nc.hide()

    def on_submit_all_clicked(self, object, data=None):
        print("select all clicked")
        #get total drive count
        global test
        test = ""
        wiping = open("/home/clientshared/.Temp/.B01/.prg.txt").read().strip()
        if wiping != "Wiping":
            print("no drives")
            #pull data then send then power off send_info
            self.finishing_message = self.builder.get_object("finishing_message")
            self.finishing_message.show()
            load = self.job_number.get_active_text()
            load = load.strip()
            employee = self.employee.get_active_text()
            employee = employee.strip()
            comments = self.comments.get_active_text()
            comments = comments.strip()
            asset_tag = self.asset_tag.get_text()
            asset_tag = asset_tag.strip()
            battery = self.battery.get_active_text()
            battery = battery.strip()
            wf = open("/home/clientshared/.submit.sh","w")
            wf1 = wf.write(send_info)
            wf2 = wf.close()
            os.chmod("/home/clientshared/.submit.sh",509)
            a = subprocess.Popen(["/home/clientshared/.submit.sh","{}".format(load),"{}".format(employee),"{}".format(comments),"{}".format(asset_tag),"{}".format(battery)])
            time.sleep(.05)
            wf = os.remove("/home/clientshared/.submit.sh")
            test = "Complete"
        else:
            self.error_submitting.show()
            self.error_submitting.set_text("Once started to wipe the drive, wiping must finish before submitting")
            test = ""

    # on report
    def on_report_activate(self, object, data=None):
        sd = datetime.datetime.now()
        dm = int(sd.strftime("%m")) - 1
        dy = int(sd.strftime("%Y"))
        dd = int(sd.strftime("%d"))
        self.sd_calendar.select_month(dm, dy)
        self.sd_calendar.select_day(dd)
        self.ed_calendar.select_month(dm, dy)
        self.ed_calendar.select_day(dd)
        self.report_window.run()

    def on_report_cancel_clicked(self, object, data=None):
        self.report_window.hide()

    def on_report_send_clicked(self, object, data=None):
        type = self.report_stack.get_visible_child_name()
        if type == "Dates":
            email = self.rd_email.get_text()
            emailc = self.rdc_email.get_text()
            empty = self.error_dates.get_text()
            if empty == "" and email != "" and emailc != "" and email == emailc:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                start = start.strftime("%Y-%m-%d")
                end = end.strftime("%Y-%m-%d")
                print("they match now send")
                self.error_dates.set_text("")
                run = Email()
                run.send_email(start, end, email, "")
                self.report_window.hide()
            else:
                self.error_dates.set_text("Emails must match and not be empty")
        elif type == "Job_Number":
            print("Location is JN")
            job = self.jnr.get_text()
            cjob = self.cjnr.get_text()
            email = self.jner.get_text()
            cemail = self.jncer.get_text()
            if job == cjob and email == cemail and job != "" and email != "":
                print("sending through Job number")
                # send report using job Number
                run = Email()
                run.send_email("", "", email, job)
                self.report_window.hide()
            if job == "" or cjob == "":
                print("Job number cannot be empty")
                self.r_jn_err.set_text("Job Number Values Cannot Be Empty")
            if email == "" or cemail == "":
                print("Email Values cannot be empty")
                self.r_jne_err.set_text("Email Values Cannot Be Empty")
            if email != cemail:
                print("Job number doesn't match")
                self.r_jne_err.set_text("Email Values Do Not Match")
            if job != cjob:
                print("Job number cannot be empty")
                self.r_jn_err.set_text("Job Number Does Not Match")

    ######## dates for report
    def on_sd_tog_toggled(self, object, data=None):
        if self.sd_tog.get_active():
            self.error_dates.set_text("")
            self.repe.hide()
            self.repec.hide()
            self.rd_email.hide()
            self.rdc_email.hide()
            self.sd_box.show()
            self.sd_tog.hide()
            self.sdtl.set_label("Start Date")
            # self.sd_tog.set_active(False)
            # self.sd_tog.show()
        else:
            self.sd_box.hide()
            if self.ed_tog.get_active() == False:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                print(start)
                print(end)
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                if end >= start:
                    self.repe.show()
                    self.repec.show()
                    self.rd_email.show()
                    self.rdc_email.show()
                    self.error_dates.set_text("")
                else:
                    self.error_dates.set_text("End date must be the same or later than the start date")

    def on_ed_tog_toggled(self, object, data=None):
        if self.ed_tog.get_active():
            self.error_dates.set_text("")
            self.repe.hide()
            self.repec.hide()
            self.rd_email.hide()
            self.rdc_email.hide()
            self.ed_box.show()
            self.edtl.set_label("Start Date")
            self.ed_tog.hide()
        else:
            self.ed_box.hide()
            if self.sd_tog.get_active() == False:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                if end >= start:
                    self.repe.show()
                    self.repec.show()
                    self.rd_email.show()
                    self.rdc_email.show()
                    self.error_dates.set_text("")
                else:
                    self.error_dates.set_text("End date must be the same or later than the start date")

    def on_sd_calendar_day_selected(self, object, data=None):
        a = self.sd_calendar.get_date()
        year = a[0]
        month = a[1]
        month = month + 1
        day = a[2]
        self.sdtl.set_label("{}/{}/{}".format(month, day, year))
        self.sd_tog.set_active(False)
        self.sd_tog.show()

    def on_ed_calendar_day_selected(self, object, data=None):
        a = self.ed_calendar.get_date()
        year = a[0]
        month = a[1]
        month = month + 1
        day = a[2]
        self.edtl.set_label("{}/{}/{}".format(month, day, year))
        self.ed_tog.set_active(False)
        self.ed_tog.show()

    def update_label(self):
        #full cycle:
        drive_numbers = 2
        for i in range(1,drive_numbers):
            t = "B0{}".format(i)
            #progress
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            prgx = self.prg.get_text()
            prg = open('/home/clientshared/.Temp/.{}/.prg.txt'.format(t)).read().strip()
            #part 2
            if prgx != prg:
                if prg == "Passed":
                    #normal tab
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Passed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('failed')
                    self.prg_style.add_class('passed')

                elif prg == "Failed" or prg == "Failed: Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Failed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('failed')

                elif prg == "Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Wiping")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('failed')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('wiping')

            #Type and Cap
            tc = 'tc"{}"'.format(i)
            self.tc = self.builder.get_object("tc{}".format(i))
            tc = open('/home/clientshared/.Temp/.{}/.tc.txt'.format(t)).read().strip()
            self.tc.set_text(tc)
            #Serial
            s = 's"{}"'.format(i)
            self.s = self.builder.get_object("s{}".format(i))
            s = open('/home/clientshared/.Temp/.{}/.s.txt'.format(t)).read().strip()
            self.s.set_text(s)
            #Perc
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            p = open('/home/clientshared/.Temp/.{}/.p.txt'.format(t)).read().strip()
            self.p.set_text(p)
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            tr = open('/home/clientshared/.Temp/.{}/.tr.txt'.format(t)).read().strip()
            self.tr.set_text(tr)
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            te = open('/home/clientshared/.Temp/.{}/.te.txt'.format(t)).read().strip()
            self.te.set_text(te)
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            etf = open('/home/clientshared/.Temp/.{}/.etf.txt'.format(t)).read().strip()
            self.etf.set_text(etf)

        return False

    def update(self):
        while True:
            GLib.idle_add(self.update_label)
            time.sleep(1)

starting_a = """#!/bin/bash
for i in {1..1};
do
touch /home/clientshared/.Temp/.B0"$i"/.p.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.p.txt

touch /home/clientshared/.Temp/.B0"$i"/.te.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.te.txt

touch /home/clientshared/.Temp/.B0"$i"/.tr.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.tr.txt

touch /home/clientshared/.Temp/.B0"$i"/.etf.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.etf.txt

touch /home/clientshared/.Temp/.B0"$i"/.prg.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.prg.txt

touch /home/clientshared/.Temp/.B0"$i"/.c.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.c.txt

touch /home/clientshared/.Temp/.B0"$i"/.tc.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.tc.txt

touch /home/clientshared/.Temp/.B0"$i"/.tr1.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.tr1.txt

touch /home/clientshared/.Temp/.B0"$i"/.s.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.s.txt

touch /home/clientshared/.Temp/.B0"$i"/.dev.txt
echo "$dev7" > /home/clientshared/.Temp/.B0"$i"/.dev.txt

pkill .Bay"$i".sh
done
exit
"""

wiping_a = """#!/bin/bash

ac=B01


touch /home/clientshared/.Temp/."$ac"/.prg.txt
touch /home/clientshared/.Temp/."$ac"/.tr.txt
touch /home/clientshared/.Temp/."$ac"/.te.txt
touch /home/clientshared/.Temp/."$ac"/.etf.txt
touch /home/clientshared/.Temp/."$ac"/.s.txt
touch /home/clientshared/.Temp/."$ac"/.tc.txt
touch /home/clientshared/.Temp/."$ac"/.c.txt
touch /home/clientshared/.Temp/."$ac"/.p.txt
sleep 3s

prog=""
echo "$prog"
if [[ "$prog" == "Wiping" || "$prog" == "Testing" ]];
then
  true
else
  echo "Started Wiping"
  echo "Wiping" > /home/clientshared/.Temp/."$ac"/.prg.txt
  #send serial number
  touch /home/clientshared/.Temp/."$ac"/.p.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

  touch /home/clientshared/.Temp/."$ac"/.te.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

  touch /home/clientshared/.Temp/."$ac"/.tr.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

  touch /home/clientshared/.Temp/."$ac"/.etf.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

  touch /home/clientshared/.Temp/."$ac"/.t.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.t.txt

  touch /home/clientshared/.Temp/."$ac"/.c.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.c.txt

  touch /home/clientshared/.Temp/."$ac"/.log.log
  echo "" > /home/clientshared/.Temp/."$ac"/.log.log
  ## scan and get data

  dev7=$(sudo smartctl --scan | awk '{print $1}')
  s5=$(sudo smartctl -i "$dev7" | grep -i "Serial")
  echo "$dev7 $s5"

  s7=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $6}')
  touch /home/clientshared/.Temp/."$ac"/.dev.txt
  echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt

  # fi
  s5="$s7"
  if [[ "$s5" == "?" ]]; then s5=""; else false; fi
  if [[ ! -z "$s5" ]]
    then
      echo "Drive Present Starting Wipe: $(date)"
      dev7=$(sudo smartctl --scan | awk '{print $1}')
      s6=$(sudo smartctl -i "$dev7" | grep -i "Serial")
      echo "$dev7 $s6"
      ## scan and get dat
      hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
      s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
      #send type
      ttype=$(sudo smartctl -i "$dev7" | grep -i "ATA Version")
      if [[ ! -z "$ttype" ]]; then t7="SATA"; else t7="SAS"; fi
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      #rotation per minute
      size1=$(sudo smartctl -i "$dev7" | grep "Form Factor:" | awk '{print $3}')
      rpm=$(sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}')
      rpm1=$(sudo smartctl -i "$dev7" | grep -i "solid")
      if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
      #manufacturer and model
      hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
      mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6,$7,$8,$9,$10,$11,$12,$13}')
      manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}')
      tmanuf=${manuf:0:2}
      ttmanuf=${manuf:0:3}
      if [[ "$tmanuf" == "ST" ]]; then manuf="SEAGATE"; mdl=$(echo "$hdsent" | grep "Model" | awk '{print $5}'); else false; fi
      if [[ "$tmanuf" == "WD" && "$ttmanuf" != "WDC" ]]; then manuf="WDC"; mdl=$(echo "$hdsent" | grep "Model" | awk '{print $5}'); else false; fi
      #send serial
      touch /home/clientshared/.Temp/."$ac"/.s.txt
      echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
      #send type
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      #Remove HPA
      hpasectors=$(sudo hdparm -N "$dev7" | grep -i "max" | awk '{print $4}' | tr -d ",")
      hpasectors=${hpasectors##*/}
      remove=$(sudo hdparm -N p$hpasectors "$dev7")       remove=$(sudo hdparm -N "$dev7")
      sleep 1s
      #send capacity
      c7=$(sudo smartctl -i "$dev7" | grep -i "User Capacity:" | awk '{print $5,$6}' | tr -d "[ ]")
      echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      #set Write cache
      w=$(sudo hdparm -W1 "$dev7")
      sleep 1s
      w=$(sudo hdparm -W1 "$dev7")
      sleep 1s
      w=$(sudo hdparm -W1 "$dev7")
      sleep 1s
      w=$(sudo sdparm -s WCE "$dev7")
      sleep 1s
      w=$(sudo sdparm -s WCE "$dev7")
      sleep 1s
      ## start time
      st=$(date '+%H:%M:%S')
      sts=$(date '+%s' -d "$st")

      #### wiping dump file
      rm -f /home/clientshared/.Temp/."$ac"/.dump.txt
      touch /home/clientshared/.Temp/."$ac"/.dump.txt
      hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
      #initial health and set to zero if ?
      htx=$(echo "$hdsent" | grep "Health" | awk '{print $3}')
      if [[ "$htx" == "?" ]]; then htx="0"; else true; fi
      sleep 1
      ##########################################
      ### print up to window
      echo "$h $d $s7 $t7 $c7 $mdl $rpm $htx $s"

      ##date
      dte=$(date "+%Y-%m-%d")

      sleep 2
      # ###Testing how to wipe
      # echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      # echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      ###
      c7=$(sudo smartctl -i "$dev7" | grep -i "User Capacity:" | awk '{print $5,$6}' | tr -d "[ ]")
      echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      #get existing percetn if already SAS
      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      SSDD=$(sudo blockdev --getsize64 "$dev7")
      test1=$(sudo smartctl -i "$dev7" | grep -i "(SPL-3)")

      logging=""

      if [[ -z "$test1" ]]
      then
      ####################################start wiping if SATA
      echo "Drive is SATA capable: Wiping"
      rm -f /home/clientshared/.Temp/."$ac"/.log.log
      touch /home/clientshared/.Temp/."$ac"/.log.log
      SSDD=$(sudo blockdev --getsize64 "$dev7")
      echo "" > /home/clientshared/.Temp/."$ac"/.log.log
      sudo ddrescue -fnND -r 3 -s ${SSDD//[!0-9]/} -b 8 -K 0 --log-events=/home/clientshared/.Temp/."$ac"/.log.log /dev/zero "$dev7" > /home/clientshared/.Temp/."$ac"/.dump.txt &
      sleep 2

      ## start time loop
      time1=0
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      while [[ -z "$a" ]]
      do
      ## CURRENT PERCENTAGE
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      p=$(cat /home/clientshared/.Temp/."$ac"/.dump.txt | grep -a "pct" | tail -n 1 | awk '{print $3}' | tr -d " %, ")
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt
      sleep 1
      b="$p"
      b=${b%.*}
      if [ "$b" -gt 98 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      done
      #####WIPE AS SAS
      else
      ###start formatting
      echo "Drive is not SAS capable and if was started is at $p percent"
      sudo sg_format --format --ffmt=2 -Q -6 -e -l "$dev7"
      sleep 3s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l "$dev7"
      sleep 5s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l "$dev7"
      sleep 3s
      sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}'
      sleep 5s
      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      if [[ -z "$p" ]]; then sudo sg_format --format -Q -6 -e -l "$dev7"; else true; fi
      sleep 1s
      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      while [[ ! -z "$p" ]] && [[ -z "$logging" ]]
      do
      ## CURRENT PERCENTAGE

      sleep 1

      ## CURRENT TIME
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      ### if goes over
      b="$p"
      b=${b%.*}
      time1=$(( time1 + 1 ))
      if [[ "$time1" -eq 5 ]]; then finalp="$b"; time1=0; else false; fi
      if [ "$b" -gt 97 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      #SAS STOP
      if [[ -z "$p" ]]; then  echo "" > /home/clientshared/.Temp/."$ac"/.log.log; else true; fi
      logging=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      done
      fi
      ##done wiping
      #####finished now done and clear counts
      echo "Drive Started testing: $(date)"
      echo "Testing" > /home/clientshared/.Temp/."$ac"/.prg.txt
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

      ### What percent

      #sample if it wipe, if it did, then proceed to test, else result=Failed: Verify
      #sleep 30
      sleep 6s
      if [[ -z "$test1" ]]
      then
       p=$(cat /home/clientshared/.Temp/."$ac"/.log.log | grep -i "End of run" | awk '{print $2}' | tr -d " %, ")
       testp="$p"
       testp=${testp%.*}
       if [[ "$testp" -eq 100 ]]; then final="pass"; else final=""; p+="%"; fi
      else
       if [[ "$final" == "pass" ]]; then true; else p="$finalp"; final=""; p+="%"; fi
      fi
      #verify if went over 97%
        if [ "$final" == "pass" ]
        then
        echo "Drive Passed Write Sequence"
        p="100%"
        #scan for SG
        bloc=$(sudo sginfo -a /dev/sg0 | grep -i "phys" | awk '{print $6}')
        a=$(sudo sg_dd if=/dev/"$sgdev" of=- count=4MB bs="$bloc" dio=1 | od)
        b=$(echo "$a" | tail -n 1)
        echo "number of blocks for verify $b"
        num=$(echo "$a" | wc -l)
        if [[ "$b" -eq "17376444000" || "$b" -eq "17204400000" || "$b" -eq "172044000000" || "$b" -eq "173764440000" ]]; then num1="3"; else num1="1"; fi
        #end verify
        echo "num is $num1, if 3 then verifies, else 1"
        if [[ "$num1" -eq 3 ]]
        then
              echo "Start Self Test for:"
              echo ""
              ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
              if [[ "$ht" == "?" ]]; then ht=0; else false; fi
              #begin testing
              # does device support logging
              t1=$(sudo smartctl -l selftest "$dev7" | grep -e "does not support")
              if [[ -z "$t1" ]]
                #yes it does
              then
                startest=$(sudo smartctl -t short "$dev7")
                t1=$(sudo smartctl -l selftest "$dev7" | grep -e "Background")
                sleep 3
                if [[ ! -z "$t1" ]]
                then
                  startest=$(sudo smartctl -t short "$dev7")
                  test=$(sudo smartctl -l selftest "$dev7" | grep -i "Self-test execution status:" )
                  perc=$(echo "$test" | awk '{print $4}')
                  count=1
                  while [[ ! -z "$test" ]]
                  do
                    test=$(sudo smartctl -l selftest "$dev7" | grep -i "Self-test execution status:" )
                    perc1=$(echo "$test" | awk '{print $1}')
                    if [[ "$perc" != "$perc1" ]]
                    then
                      echo "$perc1"
                    else
                      true
                    fi
                    sleep 3
                    if [[ "$count" -lt 210 ]]
                    then
                      count=$(($count + 1))
                    else
                      test=""
                    fi
                    perc=$(echo "$test" | awk '{print $1}')
                  done
                else
                  startest=$(sudo smartctl -t short "$dev7")
                  sleep 1
                  test=$(sudo smartctl -c "$dev7" | grep -i "remaining" )
                  perc=$(echo "$test" | awk '{print $1}')
                  count=1
                  while [[ ! -z "$test" ]]
                  do
                    test=$(sudo smartctl -c "$dev7" | grep -i "remaining")
                    perc1=$(echo "$test" | awk '{print $1}')
                    if [[ "$perc" != "$perc1" ]]
                    then
                      echo "$perc1"
                    else
                      true
                    fi
                    sleep 1
                    if [[ "$count" -lt 210 ]]
                    then
                      count=$(($count + 1))
                    else
                      test=""
                    fi
                    perc=$(echo "$test" | awk '{print $1}')
                  done
                fi
                result=$(sudo smartctl -l selftest "$dev7" | grep "# 1")

                #is it the offline type?
                resulta=$(echo "$result" | grep "offline")
                #is it the completed type?
                resultb=$(echo "$result" | grep "Completed")

                if [[ ! -z "$resulta" ]]
                  then
                    resultc=$(sudo smartctl -l selftest "$dev7" | grep "# 1" | awk '{print $6,$7}')
                      if [ "$resultc" == "without error" ]
                        then
                        ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
                        if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                          if [ "$ht" -gt 59 ]
                            then
                            result="Passed"
                            result2="Passed"
                          else
                            result2="Failed: Health"
                            result="Failed"
                          fi
                      else
                        result2="Failed: DST"
                        result="Failed"
                      fi
              # different for SAS type
                elif [[ ! -z "$resultb" ]]
                    then
                      ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
                      if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                      if [ "$ht" -gt 59 ]
                        then
                          result="Passed"
                          result2="Passed"
                      else
                        result2="Failed: Health"
                        result="Failed"
                      fi
                else
                    result2="Failed: DST"
                    result="Failed"
                  fi
              else
                ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
                if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                if [ "$ht" -gt 59 ]
                  then
                    result="Passed"
                    result2="Passed"
                else
                    result2="Failed: Health SAS"
                    result="Failed"
                fi
              fi
        else
            result2="Failed: Verify"
            result="Failed"
        fi

        echo "$ac result = $result and result2 = $result2"
        ##### testing end
        #send serial
        touch /home/clientshared/.Temp/."$ac"/.s.txt
        echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
        #send type
        echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
        #send capacity
        if [[ -z "$c7" ]]
        then
          c7=$(sudo smartctl -i "$dev7" | grep -i "User Capacity:" | awk '{print $5,$6}' | tr -d "[ ]")
        else
          false
        fi
        echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
        echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
        echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
        echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
        echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
        echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
        if [[ "$result" == "Passed" ]] && [[ "$ht" -eq 100 ]]
          then result="Tested for Full Function R2/Ready for Reuse"
        elif [[ "$result" == "Passed" && "$ht" -lt 100 ]]
          then result="Tested for Key Function R2/Ready for Resale"
        else false
        fi
        echo "time to test: $count"
        echo "device: $dev7"
        else
          sleep 1

          #45 BAY
          dev7=$(sudo smartctl --scan | awk '{print $1}')

          sleep 1
          ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
          if [[ "$ht" == "?" ]] || [[ "$ht" == "" ]]; then ht=0; else false; fi
          echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
          echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
          result2="Failed: Wiping"
          result="Failed"
          #send serial
          #send type
          echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
          #send capacity
          if [[ -z "$c7" ]]
          then
            c7=$(sudo smartctl -i "$dev7" | grep -i "User Capacity:" | awk '{print $5,$6}' | tr -d "[ ]")
          else
            false
          fi
          echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
          echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
        fi
        dte=$(date "+%Y-%m-%d")
        cserial=$(sudo dmidecode -t system | grep Serial | awk '{print $3}')
    if [[ -z "$ch" ]]; then ch="N"; else true; fi
    if [[ -z "$c7" ]]
    then
      c7=$(sudo smartctl -i "$dev7" | grep -i "User Capacity:" | awk '{print $5,$6}' | tr -d "[ ]")
    else
      false
    fi
    if [[ -z "$size1" ]]
    then
      size1=$(sudo smartctl -i "$dev7" | grep "Form Factor:" | awk '{print $3}')
    else
      false
    fi
    if [[ -z "$rpm" ]]
    then
        rpm=$(sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}')
        rpm1=$(sudo smartctl -i "$dev7" | grep -i "solid")
        if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
    else
    false
    fi
    echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
    echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
    me=$(whoami)
    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt
    #location="jasperprogram.TIS_JBOD"

    # location="jasperprogram.TIS"
        test_int=$(curl -Is  http://www.google.com | head -n 1 | grep OK 2>/dev/null)
        while [[ -z "$test_int" ]]; do sleep 1s; test_int=$(curl -Is  http://www.google.com | head -n 1 | grep OK 2>/dev/null); done
        running=$(mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into streamftl_client.inventory_wiping (client, process, result, charge, serial_number, manufacturer, model, capacity, type_drive, size, RPM, date_wiped, job_number, employee, system_name, sub_system_name, system_serial, software_version, compliance, sub_result, time_lapsed, health_final, perc_done) values ('Stream', 'Wiping', '$result', '$ch', '$s5', '$manuf', '$mdl', '$c7', '$t7', '$size1', '$rpm', '$dte', '$loadnm', '$employee', '$me', '$compnum', '$cserial', 'Jasper Version 3.01', 'NIST-800-88 rev1: Clear: Overwrite Method', '$result2', '$te', '$ht', '$p')")
        echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
else
    echo "No device shown"
    #is no device
    touch /home/clientshared/.Temp/."$ac"/.p.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

    touch /home/clientshared/.Temp/."$ac"/.te.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

    touch /home/clientshared/.Temp/."$ac"/.tr.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

    touch /home/clientshared/.Temp/."$ac"/.etf.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

    touch /home/clientshared/.Temp/."$ac"/.prg.txt
    echo "No Device" > /home/clientshared/.Temp/."$ac"/.prg.txt

    touch /home/clientshared/.Temp/."$ac"/.c.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.c.txt

    touch /home/clientshared/.Temp/."$ac"/.tc.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tc.txt

    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt

    touch /home/clientshared/.Temp/."$ac"/.s.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.s.txt

    touch /home/clientshared/.Temp/."$ac"/.dev.txt
    echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt
  fi
fi
echo "Process $ac done at $p percent" && exit

"""


send_info = """#!/bin/bash
load=$1
employee=$2
notes=$3
asset_tag=$4
battery=$5
disposition="Tested for Key Functions, R2/Ready for Resale"

#system info
device_type=$(sudo dmidecode -t 3 | grep "Type")
device_type=${device_type:7:100}

#make
make=$(sudo dmidecode -t 1 | grep "Manufacturer")
make=${make:15:100}

#part
part_number=$(sudo dmidecode -t 1 | grep "Family")
part_number=${part_number:8:100}

#model
model=$(sudo dmidecode -t 1 | grep "Product Name")
model=${model:14:100}

#sys_serial
sys_serial=$(sudo dmidecode -t 1 | grep "Serial Number")
sys_serial=${sys_serial:16:100}

#product class
p1=$(echo "$device_type" | grep -i "desktop")
if [[ ! -z "$p1" ]]; then product_class="Desktop"; else false; fi

p2=$(echo "$device_type" | grep -i "notebook")
if [[ ! -z "$p2" ]]; then product_class="Laptop"; else false; fi

p3=$(echo "$device_type" | grep -i "laptop")
if [[ ! -z "$p3" ]]; then product_class="Laptop"; else false; fi

p4=$(echo "$device_type" | grep -i "convertible")
if [[ ! -z "$p4" ]]; then product_class="Laptop"; else false; fi

echo "$device_type | $product_class | $make | $part_number | $model | $sys_serial |"

#HDD
dev7=$(sudo smartctl --scan | awk '{print $1}')
## scan and get dat
hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
c7=$(sudo smartctl -i "$dev7" | grep -i "User Capacity:" | awk '{print $5,$6}' | tr -d "[ ]")
#type
ttype=$(sudo smartctl -i "$dev7" | grep -i "ATA Version")
if [[ ! -z "$ttype" ]]; then t7="SATA"; else t7="SAS"; fi
#is ssd?
issolid=$(sudo smartctl -i "$dev7" | grep -i "solid")
if [[ ! -z "$issolid" ]]; then t7="SSD"; else false; fi
hdd_result=$(cat /home/clientshared/.Temp/.B01/.prg.txt)
if [[ -z "$hdd_result" ]]; then hdd_result="Not Wiped"; else false; fi
echo "$c7 | $t7 | $hdd_result | $s7"

#comments
comments=$(cat /home/clientshared/comments.txt)

#RAM
# Type:
# echo "$a" | grep Type | grep -v Detail
#
# Size:
# echo "$a" | grep Size
#
# Speed:
# echo "$a" | grep Speed | grep -v Configured
#
# Manufacturer:
# echo "$a" | grep Manufacturer
#
# Part Number:
# echo "$a" | grep "Part Number:
a=$(sudo dmidecode -t 17)
sizea=$(echo "$a" | grep Size | grep GB)
if [[ -z "$sizea" ]]
then
size1=$(echo "$a" | grep Size | grep MB | awk '{print $2}' | grep '[0-9]'| paste -sd+ | bc)
ram="$(echo ${size1::1})GB"
else
size1=$(echo "$a" | grep Size | grep GB | awk '{print $2}' | grep '[0-9]'| paste -sd+ | bc)
ram="$(echo ${size1})GB"
fi

ramspeed=$(sudo dmidecode -t 17  | grep -i "Speed:" | grep -i "MT" | head -n 1 | awk '{print $2,$3}')
dtype=$(sudo dmidecode -t 17  | grep -i "DDR" | head -n 1 | awk '{print $2}')

#display size
screen=$(xrandr)
##
resolution=$(echo "$screen" | grep '*' | awk '{print $1}')
w=$(echo "$screen" | grep mm | awk '{print $13}' |  sed 's/[^0-9]*//g')
l=$(echo "$screen" | grep mm | awk '{print $15}' |  sed 's/[^0-9]*//g')
dia=$(echo "sqrt($(echo "$(($l**2 + $w**2))"))" | bc)
screen=""
##
sizedisplay=$(echo $dia/24.5 | bc)
sizedisplay+="in"
echo "$sizedisplay"

#CPU
#once I have more data I can build this out
cpu=$(sudo dmidecode -t 4 | grep "Version")
speed=${cpu: -7}
cpu=${cpu:10:-9}
echo "$cpu | $speed"

date=$(date "+%Y-%m-%d")
time=$(date '+%H:%M')

ip_address=$(wget -qO- http://ipecho.net/plain | xargs echo)

running=$(mysql -u streamftl -pm9Nt5eNV9GXa4qDv -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into streamftl_client.inventory (clients, ip_add, technician, asset_tag, load_number, form_factor, product_class, manufacturer, model_number, manufacturer_part, machine_serial, screen, hdd_size, hdd_type, hdd_result, hdd_serial, cpu_type, cpu_speed, memory_size, memory_type, battery, date, time, notes, disposition) values ('Stream FTL', '$ip_address', '$employee', '$asset_tag', '$load', '$device_type', '$product_class', '$make', '$model', '$part_number', '$sys_serial', '$sizedisplay', '$c7', '$t7', '$hdd_result', '$s7', '$cpu', '$speed', '$ram', '$dtype $ramspeed', '$battery', '$date', '$time', '$notes', '$disposition')");
sleep 3s
echo "now powering off command"
poweroff
"""

class Email():
    def send_email(self,a, b, c, j):
        # The thing is start date, b is end date, c is email if empty send standard incoming, The jn is job number then has
        # value do with job
        em = """#!/bin/bash
        touch /home/clientshared/.report.tsv
        echo -e "Client\tProcess\tResult\tCharge\tSerial Number\tManufacturer\tModel\tCapacity\tDrive Type\tSize\tRPM\tDate Wiped\tJob Number\tEmployee\tSystem Name\tSubsystem Name\tSystem Serial Number\tSoftware Version\tCompliance\tSub Result\tTime Elapsed\tInitial Health\tFinal Health\tPercent Done" > /home/clientshared/report.tsv
        """
        wf = open("/home/clientshared/.report.sh", "w")
        wf1 = wf.write(em)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.report.sh", 509)
        wf3 = subprocess.check_output(["/home/clientshared/.report.sh"], stderr=None, shell=True)
        time.sleep(.05)
        os.remove("/home/clientshared/.report.sh")
        subprocess.check_output(["mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from jasperprogram.TIS_JBOD1' >> /home/clientshared/report.tsv"], stderr=None, shell=True)
        df = pd.read_csv(r"/home/clientshared/report.tsv", header=0, index_col=False, sep='\t')
        print("ATTTTEEEENNN {} to {}".format(a, b))
        if a != "" and b != "":
            # df['Date Wiped'] = pd.to_datetime(df['Date Wiped'])
            start_date = a
            print(a)
            end_date = b
            print(b)
            mask = (df['Date Wiped'] > start_date) & (df['Date Wiped'] <= end_date)
            df = df.loc[mask]
            # df['Date Wiped'] = pd.to_datetime(df['Date Wiped']).dt.date
            t = df.to_excel("/home/clientshared/.Report.xlsx", index=False)
            ch = sum(df.Charge == "Y")
            total = len(df.index)
            print("The charge is {}".format(ch))
            if c == "":
                to_emails = 'sreina@jasperwiping.com'
                subject = 'Charge Report TIS from {} to {}'.format(a,b)
                html_content = 'Jasper Program,\n\nPlease create an invoice for ${}. The total billable wipes were {} from dates {} to {}.\n \nAll the drive information for the date range is attached in Excel format.\n\nThank you,\n \n\n-Santiago\n'.format(ch, ch, a, b)
            else:
                passed = sum(df["Sub Result"] == "Passed")
                failed = sum(df["Result"] == "Failed")
                ch = sum(df.Charge == "Y")
                total = len(df.index)
                to_emails='{}'.format(c)
                subject='Wiping Report TIS from {} to {}'.format(a,b)
                html_content='TIS,\n\nThe total attempts to wipe from dates {} to {} was {}.\n\nA total of {} of drives passed wiping.\n\nA total of {} failed wiping\nA total of {} drives were charged from wiping.\nPlease see the attached excel file.\n\nThank you,\n\nTIS\n'.format(a, b, total, passed, failed, ch)
        else:
            df['Job Number'] = df['Job Number'].apply(str)
            df = df.loc[df['Job Number'] == "{}".format(j)]
            t = df.to_excel("/home/clientshared/.Report.xlsx", index=False)
            passed = sum(df["Sub Result"] == "Passed")
            failed = sum(df["Result"] == "Failed")
            ch = sum(df.Charge == "Y")
            total = len(df.index)
            to_emails='{}'.format(c)
            subject='Wiping Report for Job {}'.format(j)
            html_content='\nTIS,\n\nThe total attempts to wipe for the job {} were {}.\nA total of {} drives passed wiping.\n\nA total of {} failed wiping\nA total of {} drives were charged from wiping.\nPlease see the attached excel file.\n\nThank you,\n\nTIS\n'.format(j, total, passed, failed, ch)

        msg = MIMEMultipart()

        msg['From'] = 'reports@jasperwiping.com'
        msg['To'] = to_emails
        msg['Subject'] = subject

        msg.attach(MIMEText(html_content, 'plain'))

        filename = "Reports.xlsx"
        attachment = open("/home/clientshared/.Report.xlsx", 'rb')

        part = MIMEBase('application', 'octet-stream')
        part.set_payload((attachment).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

        msg.attach(part)

        api_key = "a6fcf3bb-7bf0-4e62-b72e-a2a899975e86"

        postmark = PostmarkClient(server_token='{}'.format(api_key))
        postmark.emails.send(msg)

if __name__ == "__main__":
    main = main_window()
    Gtk.main()

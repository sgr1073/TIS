#!/usr/bin/env python3
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import sys
import subprocess
import threading
from gi.repository import GObject
from gi.repository import GLib
import time
from gi.repository import Gdk
from gi.repository import Pango
from time import sleep
import os
import base64
import datetime
import pandas as pd
from datetime import datetime as dt
import requests
from requests import get
import postmarker
import email
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import formatdate
from email import encoders
import sendgrid
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)
from postmarker.core import PostmarkClient

# ipt = "96.77.99.254" #TIS
# ipt1 = "38.88.190.26"
# ipt2 = "97.104.99.49" #Here
# # ipt = "70.62.107.226" #synergy
# ip = get('https://api.ipify.org').content.decode('utf8')
# print (ip)
# if ip == "97.100.109.182":
# if ip == "96.77.99.254":
# if ip == ipt or ip == ipt1 or ip == ipt2:
#     True
# else:
#     sys.exit()

class Email():
    def send_email(self,a, b, c, j):
        # The thing is start date, b is end date, c is email if empty send standard incoming, The jn is job number then has
        # value do with job
        em = """#!/bin/bash
        touch /home/clientshared/.report.tsv
        echo -e "Client\tProcess\tResult\tCharge\tSerial Number\tManufacturer\tModel\tCapacity\tDrive Type\tSize\tRPM\tDate Wiped\tJob Number\tEmployee\tSystem Name\tSubsystem Name\tSystem Serial Number\tSoftware Version\tCompliance\tSub Result\tTime Elapsed\tInitial Health\tFinal Health\tPercent Done" > /home/clientshared/report.tsv
        """
        wf = open("/home/clientshared/.report.sh", "w")
        wf1 = wf.write(em)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.report.sh", 509)
        wf3 = subprocess.check_output(["/home/clientshared/.report.sh"], stderr=None, shell=True)
        time.sleep(.05)
        os.remove("/home/clientshared/.report.sh")
        subprocess.check_output(["mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from jasperprogram.TIS_JBOD1' >> /home/clientshared/report.tsv"], stderr=None, shell=True)
        df = pd.read_csv(r"/home/clientshared/report.tsv", header=0, index_col=False, sep='\t')
        print("ATTTTEEEENNN {} to {}".format(a, b))
        if a != "" and b != "":
            # df['Date Wiped'] = pd.to_datetime(df['Date Wiped'])
            start_date = a
            print(a)
            end_date = b
            print(b)
            mask = (df['Date Wiped'] > start_date) & (df['Date Wiped'] <= end_date)
            df = df.loc[mask]
            # df['Date Wiped'] = pd.to_datetime(df['Date Wiped']).dt.date
            t = df.to_excel("/home/clientshared/.Report.xlsx", index=False)
            ch = sum(df.Charge == "Y")
            total = len(df.index)
            print("The charge is {}".format(ch))
            if c == "":
                to_emails = 'sreina@jasperwiping.com'
                subject = 'Charge Report TIS from {} to {}'.format(a,b)
                html_content = 'Jasper Program,\n\nPlease create an invoice for ${}. The total billable wipes were {} from dates {} to {}.\n \nAll the drive information for the date range is attached in Excel format.\n\nThank you,\n \n\n-Santiago\n'.format(ch, ch, a, b)
            else:
                passed = sum(df["Sub Result"] == "Passed")
                failed = sum(df["Result"] == "Failed")
                ch = sum(df.Charge == "Y")
                total = len(df.index)
                to_emails='{}'.format(c)
                subject='Wiping Report TIS from {} to {}'.format(a,b)
                html_content='TIS,\n\nThe total attempts to wipe from dates {} to {} was {}.\n\nA total of {} of drives passed wiping.\n\nA total of {} failed wiping\nA total of {} drives were charged from wiping.\nPlease see the attached excel file.\n\nThank you,\n\nTIS\n'.format(a, b, total, passed, failed, ch)
        else:
            df['Job Number'] = df['Job Number'].apply(str)
            df = df.loc[df['Job Number'] == "{}".format(j)]
            t = df.to_excel("/home/clientshared/.Report.xlsx", index=False)
            passed = sum(df["Sub Result"] == "Passed")
            failed = sum(df["Result"] == "Failed")
            ch = sum(df.Charge == "Y")
            total = len(df.index)
            to_emails='{}'.format(c)
            subject='Wiping Report for Job {}'.format(j)
            html_content='\nTIS,\n\nThe total attempts to wipe for the job {} were {}.\nA total of {} drives passed wiping.\n\nA total of {} failed wiping\nA total of {} drives were charged from wiping.\nPlease see the attached excel file.\n\nThank you,\n\nTIS\n'.format(j, total, passed, failed, ch)

        msg = MIMEMultipart()

        msg['From'] = 'reports@jasperwiping.com'
        msg['To'] = to_emails
        msg['Subject'] = subject

        msg.attach(MIMEText(html_content, 'plain'))

        filename = "Reports.xlsx"
        attachment = open("/home/clientshared/.Report.xlsx", 'rb')

        part = MIMEBase('application', 'octet-stream')
        part.set_payload((attachment).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

        msg.attach(part)

        api_key = subprocess.check_output(["echo $POSTMARK_API_KEY"], stderr=None, shell=True).decode("utf-8").strip()

        postmark = PostmarkClient(server_token='{}'.format(api_key))
        postmark.emails.send(msg)

class biting_button():
    def game_col(self,z):
        def on_Bz_clicked(object, data=None):
            if z < 10:
                prg = open('/home/clientshared/.Temp/.B0{}/.prg.txt'.format(z)).read().strip()
                serial = open('/home/clientshared/.Temp/.B0{}/.te.txt'.format(z)).read().strip()
            else:
                prg = open('/home/clientshared/.Temp/.B{}/.prg.txt'.format(z)).read().strip()
                serial = open('/home/clientshared/.Temp/.B{}/.te.txt'.format(z)).read().strip()

            if prg == "Stopping":
                if serial == "":
                    os.system("sudo killall .Bay{}.sh 2>/dev/null".format(z))
                    if z < 10:
                        wf = open('/home/clientshared/.Temp/.B0{}/.prg.txt'.format(z), "w")
                        wf1 = wf.write("Failed")
                        wf2 = wf.close()
                        print("Cancelled under 10 s Blank")
                    else:
                        wf = open('/home/clientshared/.Temp/.B{}/.prg.txt'.format(z), "w")
                        wf1 = wf.write("Failed")
                        wf2 = wf.close()
                        print("Cancelled over 10 s Blank")
                return
            if prg == "Wiping" and z < 10 and serial != "":
                wf = open('/home/clientshared/.Temp/.B0{}/.stopping.txt'.format(z), "w")
                wf1 = wf.write("Stop")
                wf2 = wf.close()
                wf = open('/home/clientshared/.Temp/.B0{}/.prg.txt'.format(z), "w")
                wf1 = wf.write("Stopping")
                wf2 = wf.close()
                return
            elif prg == "Wiping" and z > 9 and serial != "":
                wf = open('/home/clientshared/.Temp/.B{}/.stopping.txt'.format(z), "w")
                wf1 = wf.write("Stop")
                wf2 = wf.close()
                wf = open('/home/clientshared/.Temp/.B{}/.prg.txt'.format(z), "w")
                wf1 = wf.write("Stopping")
                wf2 = wf.close()
                return
            elif prg == "Wiping" and z < 10 and serial == "":
                os.system("sudo killall .Bay{}.sh 2>/dev/null".format(z))
                wf = open('/home/clientshared/.Temp/.B0{}/.prg.txt'.format(z), "w")
                wf1 = wf.write("Failed")
                wf2 = wf.close()
                print("Cancelled under 10 s Blank")
                return
            elif prg == "Wiping" and z > 9 and serial == "":
                os.system("sudo killall .Bay{}.sh 2>/dev/null".format(z))
                wf = open('/home/clientshared/.Temp/.B{}/.prg.txt'.format(z), "w")
                wf1 = wf.write("Failed")
                wf2 = wf.close()
                print("Cancelled under 10 s Blank")
                return

            wf = open("/home/clientshared/.Bay{}.sh".format(z),"w")
            wf1 = wf.write(b)
            wf2 = wf.close()
            os.chmod("/home/clientshared/.Bay{}.sh".format(z),509)
            if z < 10:
                a = subprocess.Popen(["/home/clientshared/.Bay{}.sh".format(z),"B0{}".format(z)])
            else:
                a = subprocess.Popen(["/home/clientshared/.Bay{}.sh".format(z),"B{}".format(z)])
            time.sleep(.1)
            wf = os.remove("/home/clientshared/.Bay{}.sh".format(z))
            print("Process {} started in background".format(z))
        return on_Bz_clicked


class main_window():
	#initi main window class
    def __init__(self):

        self.gladefile = "/home/clientshared/96.glade"

        # self.gladefile = "/home/sr/Documents/GitHub/jbeta/Jasper Wiping/Bay 96/96.glade"

        self.builder = Gtk.Builder()
        self.builder.add_from_file(self.gladefile)
        #main window
        self.main_window = self.builder.get_object("window1")
        self.close_button = self.builder.get_object("close_button")

        #popover
        self.popover = self.builder.get_object("popover")
        self.poplabel = self.builder.get_object("poplabel")

        cssProvider = Gtk.CssProvider()
        cssProvider.load_from_path('/home/clientshared/another.css')
        screen = Gdk.Screen.get_default()
        styleContext = Gtk.StyleContext()
        styleContext.add_provider_for_screen(screen, cssProvider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        self.testing = self.builder.get_object("testing")
        ###Mwnu
        self.main_menu = self.builder.get_object("main_menu")
        self.Change = self.builder.get_object("Change")
        self.Jnumber = self.builder.get_object("Jnumber")
        self.Employee = self.builder.get_object("Employee")
        ### change jn
        self.change_jn_window = self.builder.get_object("change_jn_window")
        self.enjn = self.builder.get_object("e_n_jn")
        self.ecnjn = self.builder.get_object("e_cn_jn")
        self.tjn = self.builder.get_object("tjn")
        self.errjn = self.builder.get_object("err_jn")
        ##change_e_window
        self.change_e_window = self.builder.get_object("change_e_window")
        self.ene = self.builder.get_object("ene")
        self.ecne = self.builder.get_object("ecne")
        self.texte = self.builder.get_object("te")
        self.erre = self.builder.get_object("erre")
        # start loop
        ##Btab
        self.BB2 = self.builder.get_object("BB2")
        ### report window
        self.report_window = self.builder.get_object("run_report")
        self.report_window = self.builder.get_object("report_window")
        self.report_stack = self.builder.get_object("report_stack")
        ## sub report dates
        self.sd_box = self.builder.get_object("sd_box")
        self.ed_box = self.builder.get_object("ed_box")
        self.report_cancel = self.builder.get_object("report_cancel")
        self.sd_tog = self.builder.get_object("sd_tog")
        self.ed_tog = self.builder.get_object("ed_tog")
        self.sdtl = self.builder.get_object("sd_label")
        self.edtl = self.builder.get_object("ed_label")
        self.rd_email = self.builder.get_object("rd_email")
        self.rdc_email = self.builder.get_object("rdc_email")
        #
        self.rd_email.set_text("bmartinolich@tworiversrecovery.com")
        self.rdc_email.set_text("bmartinolich@tworiversrecovery.com")
        #
        self.repe = self.builder.get_object("repe")
        self.repec = self.builder.get_object("repec")
        self.sd_calendar = self.builder.get_object("sd_calendar")
        self.ed_calendar = self.builder.get_object("ed_calendar")
        self.error_dates = self.builder.get_object("error_dates")
        ## sub report job number
        self.jnr = self.builder.get_object("jnr")
        self.cjnr = self.builder.get_object("cjnr")
        self.jner = self.builder.get_object("jner")
        self.jncer = self.builder.get_object("jncer")
        #
        self.jner.set_text("bmartinolich@tworiversrecovery.com")
        self.jncer.set_text("bmartinolich@tworiversrecovery.com")
        #
        self.r_jn_err = self.builder.get_object("r_jn_err")
        self.r_jne_err = self.builder.get_object("r_jne_err")
        ### report windo
        self.internet = self.builder.get_object("internet")
        ####
        self.job_scrap = self.builder.get_object("job_scrap")
        self.r_SATA = self.builder.get_object("r_SATA")
        self.r_SAS = self.builder.get_object("r_SAS")
        self.r_SSD = self.builder.get_object("r_SSD")
        # self.r_25 = self.builder.get_object("r_25")
        # self.r_35 = self.builder.get_object("r_35")
        self.cap_e_scrap = self.builder.get_object("cap_e_scrap")
        self.serial_e_scrap = self.builder.get_object("serial_e_scrap")
        self.tree_view = self.builder.get_object("tree_view")
        self.ch_jn_scrap = self.builder.get_object("ch_jn_scrap")
        self.liststore1 = self.builder.get_object("liststore1")
        self.scrap = self.builder.get_object("scrap")
        self.scrap_add = self.builder.get_object("scrap_add")
        self.scrap_cancel = self.builder.get_object("scrap_cancel")
        self.cap_e_scrap = self.builder.get_object("cap_e_scrap")
        self.serial_e_scrap = self.builder.get_object("serial_e_scrap")
        self.liststore1 = self.builder.get_object("liststore1")
        self.remove_scrap = self.builder.get_object("remove_scrap")
        self.job_scrap = self.builder.get_object("job_scrap")
        ####
        #set the JN
        tee = open("/home/clientshared/.General/.employee").read().strip()
        self.texte.set_text(tee)
        tjne = open("/home/clientshared/.General/.job_number").read().strip()
        self.tjn.set_text(tjne)

        self.SA = self.builder.get_object("SA")
        beast = getattr(main_window, "on_SA_clicked")
        self.SA.connect("clicked", beast)

        button_connect = biting_button()
        # events_connect = event_class()

        for i in range(1,97):
            #EVENTS
            events = 'events{}'.format(i)
            self.events = self.builder.get_object("events{}".format(i))
            #
            setattr(main_window, "on_events{}_enter_notify_event".format(i), self.enters(self,i))
            setattr(main_window, "on_events{}_leave_notify_event".format(i), self.leaves(self,i))
            #
            bevent1 = getattr(main_window, "on_events{}_enter_notify_event".format(i))
            bevent2 = getattr(main_window, "on_events{}_leave_notify_event".format(i))
            self.events.connect("enter-notify-event", bevent1)
            self.events.connect("leave-notify-event", bevent2)
            self.builder.connect_signals(self)

            #button
            B = 'B"{}"'.format(i)
            self.B = self.builder.get_object("B{}".format(i))

            setattr(main_window, "on_B{}_clicked".format(i), button_connect.game_col(i))
            beast = "on_B{}_clicked".format(i)
            beast = getattr(main_window, "on_B{}_clicked".format(i))
            self.B.connect("clicked", beast)

            # self.builder.get_object("{}1").connect("clicked",self.on_B1_clicked)
            self.builder.connect_signals(self)
            #button top
            BB = 'BB"{}"'.format(i)
            self.BB = self.builder.get_object("BB{}".format(i))
            #top button style initial
            self.BB_style = self.BB.get_style_context()
            self.BB_style.add_class('treg')
            #top button connetion
            B = 'B"{}"'.format(i)
            self.BB = self.builder.get_object("BB{}".format(i))
            beast = "on_B{}_clicked".format(i)
            beast = getattr(main_window, "on_B{}_clicked".format(i))
            self.BB.connect("clicked", beast)
            # self.builder.get_object("{}1").connect("clicked",self.on_B1_clicked)
            self.builder.connect_signals(self)

            #button top
            BBB = 'BBB"{}"'.format(i)
            self.BBB = self.builder.get_object("BBB{}".format(i))
            #top button style initial
            self.BBB_style = self.BBB.get_style_context()
            self.BBB_style.remove_class('twiping')
            self.BBB_style.remove_class('tpassed')
            self.BBB_style.add_class('treg')
            #top button connetion
            B = 'B"{}"'.format(i)
            self.BBB = self.builder.get_object("BBB{}".format(i))
            beast = "on_B{}_clicked".format(i)
            beast = getattr(main_window, "on_B{}_clicked".format(i))
            self.BBB.connect("clicked", beast)
            # self.builder.get_object("{}1").connect("clicked",self.on_B1_clicked)
            self.builder.connect_signals(self)

            #prg
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            self.prg.set_text("")
            #prg style
            self.prg_style = self.prg.get_style_context()
            self.prg_style.remove_class('wiping')
            self.prg_style.add_class('invisible')

            #per
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            self.p.set_text("")
            #per
            s = 's"{}"'.format(i)
            self.s = self.builder.get_object("s{}".format(i))
            #set ellipsis must get Pango
            self.s.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
            self.s.set_max_width_chars(18)
            # # self.s.set_text("Serial Number Here")
            # self.s_style = self.s.get_style_context()
            # self.s_style.remove_class('bottom')
            # self.s_style.add_class('label1')
            #tc
            tc = 'tc"{}"'.format(i)
            self.tc = self.builder.get_object("tc{}".format(i))
            self.tc.set_text("")
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            self.te.set_text("")
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            self.tr.set_text("")
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            self.etf.set_text("")
            #trr
            trr = 'trr"{}"'.format(i)
            self.trr = self.builder.get_object("trr{}".format(i))
            self.trr.set_width_chars(4)
            self.trr.set_text("")
            #ss
            ss = 'ss"{}"'.format(i)
            self.ss = self.builder.get_object("ss{}".format(i))
            self.ss.set_text("")
            self.ss.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
            self.ss.set_max_width_chars(12)
            #trB
            # trB = 'trB"{}"'.format(i)
            # self.trB = self.builder.get_object("trB{}".format(i))
            # self.trB.set_text("")
            #number trB length
            # trB = 'trB"{}"'.format(i)
            # self.trB = self.builder.get_object("trB{}".format(i))
            # self.trB.set_width_chars(6)

        file = os.remove("/home/clientshared/Bay96.py")
        file = os.remove("/home/clientshared/96.glade")
        file = os.remove("/home/clientshared/another.css")

        self.main_window.show()

        thread = threading.Thread(target=self.update)
        thread.daemon = True
        thread.start()

    def enters(self,x,z):
        def on_eventsz_enter_notify_event(x,object, data=None):
            self.poplabel = self.builder.get_object("poplabel")
            self.popover = self.builder.get_object("popover")
            events = 'events"{}"'.format(z)
            self.events = self.builder.get_object("events{}".format(z))
            self.popover.set_relative_to(self.events)
            if z < 10:
                s = open('/home/clientshared/.Temp/.B0{}/.s.txt'.format(z)).read().strip()
            else:
                s = open('/home/clientshared/.Temp/.B{}/.s.txt'.format(z)).read().strip()
            self.poplabel.set_text(s)
            self.popover.show()
        return on_eventsz_enter_notify_event

    def leaves(self,x,z):
        def on_eventsz_leave_notify_event(x, object, data=None):
            self.popover.hide()
        return on_eventsz_leave_notify_event

    def on_window1_destroy(self, object, data=None):
        print("quit with cancel")
        Gtk.main_quit()

    def on_close_button_activate(self, object, data=None):
        print("quit with cancel")
        Gtk.main_quit()

    ###on add Scrap
    def on_add_drives_activate(self, object, data=None):
        a = self.tjn.get_text()
        self.job_scrap.set_text(a)
        self.scrap.run()

    def on_scrap_cancel_clicked(self, object, data=None):
        self.liststore1.clear()
        self.scrap.hide()

    def on_scrap_add_clicked(self, object, data=None):
        jn = self.tjn.get_text()
        e = self.texte.get_text()
        date = datetime.date.today().strftime("%m/%d/%y")
        # comp serial
        stream = os.popen("""sudo dmidecode -t system | grep Serial | awk '{print $3}'""")
        output = stream.read()
        syssn = output.replace("\n", "")
        cats = list()
        item = self.liststore1.get_iter_first()
        while (item != None):
            cats.append(["no", self.liststore1.get_value(item, 0), self.liststore1.get_value(item, 1), "NA", "NA",
                         self.liststore1.get_value(item, 2), "NA", "{}".format(e), "{}".format(jn), "{}".format(date),
                         "NA", "Jasper Wiping v2.1", "{}".format(syssn), "NA", "NA", "NA", "NA", "NA"])
            item = self.liststore1.iter_next(item)
        # print(cats)
        # df = pd.DataFrame(cats,columns=['Type','Capacity','Serial Number'])
        # print(df)
        a = ""
        for i in cats:
            a = a + "\n{}".format(i)
        print(a)
        a = a.replace("'", "")
        a = a.replace("[", "")
        a = a.replace("]", "")
        a = a.replace(" ", "")
        print(a)
        ###here
        with open("/home/jasper2/Desktop/.Wiping_Report.txt", "a") as f:
            f.write(a)
            f.close()
        self.liststore1.clear()
        self.scrap.hide()

    def on_remove_scrap_clicked(self, object, data=None):
        self.liststore1.remove(self.select)

    def on_serial_e_scrap_activate(self, object, data=None):
        cap = self.cap_e_scrap.get_text()
        cap = "{} GB".format(cap)
        serial = self.serial_e_scrap.get_text()
        serial = serial.replace(".", "")
        if self.r_SATA.get_active():
            type = "SATA"
        if self.r_SAS.get_active():
            type = "SAS"
        if self.r_SSD.get_active():
            type = "SSD"
        print(type, cap, serial)
        self.liststore1.append([type, cap, serial])
        self.serial_e_scrap.set_text("")

    def on_select_changed(self, user_data, data=None):
        selected = user_data.get_selected()[1]
        if selected:
            self.select = selected

    # on report
    def on_report_activate(self, object, data=None):
        sd = datetime.datetime.now()
        dm = int(sd.strftime("%m")) - 1
        dy = int(sd.strftime("%Y"))
        dd = int(sd.strftime("%d"))
        self.sd_calendar.select_month(dm, dy)
        self.sd_calendar.select_day(dd)
        self.ed_calendar.select_month(dm, dy)
        self.ed_calendar.select_day(dd)
        self.report_window.run()

    def on_report_cancel_clicked(self, object, data=None):
        self.report_window.hide()

    def on_report_send_clicked(self, object, data=None):
        type = self.report_stack.get_visible_child_name()
        if type == "Dates":
            email = self.rd_email.get_text()
            emailc = self.rdc_email.get_text()
            empty = self.error_dates.get_text()
            if empty == "" and email != "" and emailc != "" and email == emailc:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                start = start.strftime("%Y-%m-%d")
                end = end.strftime("%Y-%m-%d")
                print("they match now send")
                self.error_dates.set_text("")
                run = Email()
                run.send_email(start, end, email, "")
                self.report_window.hide()
            else:
                self.error_dates.set_text("Emails must match and not be empty")
        elif type == "Job_Number":
            print("Location is JN")
            job = self.jnr.get_text()
            cjob = self.cjnr.get_text()
            email = self.jner.get_text()
            cemail = self.jncer.get_text()
            if job == cjob and email == cemail and job != "" and email != "":
                print("sending through Job number")
                # send report using job Number
                run = Email()
                run.send_email("", "", email, job)
                self.report_window.hide()
            if job == "" or cjob == "":
                print("Job number cannot be empty")
                self.r_jn_err.set_text("Job Number Values Cannot Be Empty")
            if email == "" or cemail == "":
                print("Email Values cannot be empty")
                self.r_jne_err.set_text("Email Values Cannot Be Empty")
            if email != cemail:
                print("Job number doesn't match")
                self.r_jne_err.set_text("Email Values Do Not Match")
            if job != cjob:
                print("Job number cannot be empty")
                self.r_jn_err.set_text("Job Number Does Not Match")

    ######## dates for report
    def on_sd_tog_toggled(self, object, data=None):
        if self.sd_tog.get_active():
            self.error_dates.set_text("")
            self.repe.hide()
            self.repec.hide()
            self.rd_email.hide()
            self.rdc_email.hide()
            self.sd_box.show()
            self.sd_tog.hide()
            self.sdtl.set_label("Start Date")
            # self.sd_tog.set_active(False)
            # self.sd_tog.show()
        else:
            self.sd_box.hide()
            if self.ed_tog.get_active() == False:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                print(start)
                print(end)
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                if end >= start:
                    self.repe.show()
                    self.repec.show()
                    self.rd_email.show()
                    self.rdc_email.show()
                    self.error_dates.set_text("")
                else:
                    self.error_dates.set_text("End date must be the same or later than the start date")

    def on_ed_tog_toggled(self, object, data=None):
        if self.ed_tog.get_active():
            self.error_dates.set_text("")
            self.repe.hide()
            self.repec.hide()
            self.rd_email.hide()
            self.rdc_email.hide()
            self.ed_box.show()
            self.edtl.set_label("Start Date")
            self.ed_tog.hide()
        else:
            self.ed_box.hide()
            if self.sd_tog.get_active() == False:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                if end >= start:
                    self.repe.show()
                    self.repec.show()
                    self.rd_email.show()
                    self.rdc_email.show()
                    self.error_dates.set_text("")
                else:
                    self.error_dates.set_text("End date must be the same or later than the start date")

    def on_sd_calendar_day_selected(self, object, data=None):
        a = self.sd_calendar.get_date()
        year = a[0]
        month = a[1]
        month = month + 1
        day = a[2]
        self.sdtl.set_label("{}/{}/{}".format(month, day, year))
        self.sd_tog.set_active(False)
        self.sd_tog.show()

    def on_ed_calendar_day_selected(self, object, data=None):
        a = self.ed_calendar.get_date()
        year = a[0]
        month = a[1]
        month = month + 1
        day = a[2]
        self.edtl.set_label("{}/{}/{}".format(month, day, year))
        self.ed_tog.set_active(False)
        self.ed_tog.show()

    # onjn
    def on_Jnumber_activate(self, object, data=None):
        print("J activated")
        self.change_jn_window.run()

    def on_ch_jn_scrap_clicked(self, object, data=None):
        print("J activated")
        self.change_jn_window.run()

    def on_close_jn_clicked(self, object, data=None):
        print("quit jn with cancel")
        self.errjn.set_text("")
        self.enjn.set_text("")
        self.ecnjn.set_text("")
        self.change_jn_window.hide()

    def on_ok_jn_clicked(self, object, data=None):
        njn = self.enjn.get_text()
        print(njn)
        cnjn = self.ecnjn.get_text()
        print(cnjn)
        print("hit ok and close")
        if njn == cnjn:
            self.tjn.set_text(njn)
            print("jn matched")
            self.errjn.set_text("")
            self.enjn.set_text("")
            self.ecnjn.set_text("")
            fe = open("/home/clientshared/.General/.job_number", "w")
            fe.write(njn)
            fe.close()
            self.change_jn_window.hide()
        else:
            self.errjn.set_text("Error: Job Number does not match")

    ##onem
    def on_e_activate(self, object, data=None):
        print("Employee activated")
        self.change_e_window.run()

    def on_close_e_clicked(self, object, data=None):
        print("quit e with cancel")
        self.erre.set_text("")
        self.ene.set_text("")
        self.ecne.set_text("")
        self.change_e_window.hide()

    def on_ok_e_clicked(self, object, data=None):
        ene = self.ene.get_text()
        print(ene)
        ecne = self.ecne.get_text()
        print(ecne)
        print("hit ok and close")
        if ene == ecne:
            self.texte.set_text(ene)
            print("e matched")
            self.erre.set_text("")
            self.ene.set_text("")
            self.ecne.set_text("")
            fe = open("/home/clientshared/.General/.ee=ee", "w")
            fe.write(ene)
            fe.close()
            self.change_e_window.hide()
        else:
            self.erre.set_text("Error:  name does not match")

    def on_SA_clicked(object, data=None):
        for i in range(1,97):
            if i < 10:
                prg = open('/home/clientshared/.Temp/.B0{}/.prg.txt'.format(i)).read().strip()
            else:
                prg = open('/home/clientshared/.Temp/.B{}/.prg.txt'.format(i)).read().strip()
            if prg != "Wiping" and prg != "Stopping" and prg !="Testing":
                B = 'B"{}"'.format(i)
                beast = "on_B{}_clicked".format(i)
                beast = getattr(main_window, "on_B{}_clicked".format(i))
                beast("clicked")

    def update_label(self):
        #full cycle:
        #####E and JN
        for i in range(1,97):
            #Bay overall
            if i < 10:
                t = "B0{}".format(i)
            else:
                t = "B{}".format(i)

            #progress
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            prg = 'BB"{}"'.format(i)
            self.BB = self.builder.get_object("BB{}".format(i))
            prg = open('/home/clientshared/.Temp/.{}/.prg.txt'.format(t)).read().strip()
            #part 2
            prgx = self.prg.get_text()
            if prgx != prg:
                if prg == "Passed":
                    #normal tab
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Passed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('failed')
                    self.prg_style.add_class('passed')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('twiping')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tfailed')
                    self.BB_style.add_class('tpassed')
                    #button tab
                    BBB = 'BBB"{}"'.format(i)
                    self.BBB = self.builder.get_object("BBB{}".format(i))
                    self.BBB_style = self.BBB.get_style_context()
                    self.BBB_style.remove_class('invisible')
                    self.BBB_style.remove_class('twiping')
                    self.BBB_style.remove_class('treg')
                    self.BBB_style.remove_class('tfailed')
                    self.BBB_style.add_class('tpassed')

                elif prg == "Stopping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Stopping")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('failed')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('twiping')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tpassed')
                    self.BB_style.add_class('tfailed')
                    #button tab
                    BBB = 'BBB"{}"'.format(i)
                    self.BBB = self.builder.get_object("BBB{}".format(i))
                    self.BBB_style = self.BBB.get_style_context()
                    self.BBB_style.remove_class('invisible')
                    self.BBB_style.remove_class('twiping')
                    self.BBB_style.remove_class('treg')
                    self.BBB_style.remove_class('tpassed')
                    self.BBB_style.add_class('tfailed')

                elif prg == "Failed" or prg == "Failed: Wiping" or prg == "Stopping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Failed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('failed')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('twiping')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tpassed')
                    self.BB_style.add_class('tfailed')
                    #button tab
                    BBB = 'BBB"{}"'.format(i)
                    self.BBB = self.builder.get_object("BBB{}".format(i))
                    self.BBB_style = self.BBB.get_style_context()
                    self.BBB_style.remove_class('invisible')
                    self.BBB_style.remove_class('twiping')
                    self.BBB_style.remove_class('treg')
                    self.BBB_style.remove_class('tpassed')
                    self.BBB_style.add_class('tfailed')

                elif prg == "Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Wiping")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('failed')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('wiping')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('tpassed')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tfailed')
                    self.BB_style.add_class('twiping')
                    #button tab
                    BBB = 'BBB"{}"'.format(i)
                    self.BBB = self.builder.get_object("BBB{}".format(i))
                    self.BBB_style = self.BBB.get_style_context()
                    self.BBB_style.remove_class('invisible')
                    self.BBB_style.remove_class('tpassed')
                    self.BBB_style.remove_class('treg')
                    self.BBB_style.remove_class('tfailed')
                    self.BBB_style.add_class('twiping')

                elif prg == "No Device":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("No Device")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('failed')
                    self.prg_style.remove_class('passed')
                    self.prg_style.remove_class('wiping')
                    self.prg_style.add_class('treg')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('tpassed')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tfailed')
                    self.BB_style.remove_class('twiping')
                    self.BB_style.add_class('treg')
                    #button tab
                    BBB = 'BBB"{}"'.format(i)
                    self.BBB = self.builder.get_object("BBB{}".format(i))
                    self.BBB_style = self.BBB.get_style_context()
                    self.BBB_style.remove_class('invisible')
                    self.BBB_style.remove_class('tpassed')
                    self.BBB_style.remove_class('treg')
                    self.BBB_style.remove_class('tfailed')
                    self.BBB_style.remove_class('twiping')
                    self.BBB_style.add_class('treg')
            #Type and Cap
            tc = 'tc"{}"'.format(i)
            self.tc = self.builder.get_object("tc{}".format(i))
            tc = open('/home/clientshared/.Temp/.{}/.tc.txt'.format(t)).read().strip()
            self.tc.set_text(tc)
            #Serial
            s = 's"{}"'.format(i)
            self.s = self.builder.get_object("s{}".format(i))
            s = open('/home/clientshared/.Temp/.{}/.s.txt'.format(t)).read().strip()
            self.s.set_text(s)
            #Perc
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            p = open('/home/clientshared/.Temp/.{}/.p.txt'.format(t)).read().strip()
            self.p.set_text(p)
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            tr = open('/home/clientshared/.Temp/.{}/.tr.txt'.format(t)).read().strip()
            self.tr.set_text(tr)
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            te = open('/home/clientshared/.Temp/.{}/.te.txt'.format(t)).read().strip()
            self.te.set_text(te)
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            etf = open('/home/clientshared/.Temp/.{}/.etf.txt'.format(t)).read().strip()
            self.etf.set_text(etf)
            #trr
            trr = 'trr"{}"'.format(i)
            self.trr = self.builder.get_object("trr{}".format(i))
            trr = open('/home/clientshared/.Temp/.{}/.tr1.txt'.format(t)).read().strip()
            self.trr.set_text(trr)
            #ss
            ss = 'ss"{}"'.format(i)
            self.ss = self.builder.get_object("ss{}".format(i))
            ss = open('/home/clientshared/.Temp/.{}/.s.txt'.format(t)).read().strip()
            self.ss.set_text(ss)

        return False

    def update(self):
        while True:
            GLib.idle_add(self.update_label)
            time.sleep(1)


b = """#!/bin/bash
#sleep 15s
####Bay 16
#####
#ac=$1
ac="$1"
#what is the type?

employee=$(cat /home/clientshared/.General/.employee)

loadnum=$(cat /home/clientshared/.General/.job_number)

compnum=""

touch /home/clientshared/.Temp/."$ac"/.prg.txt
touch /home/clientshared/.Temp/."$ac"/.tr1.txt
touch /home/clientshared/.Temp/."$ac"/.tr.txt
touch /home/clientshared/.Temp/."$ac"/.te.txt
touch /home/clientshared/.Temp/."$ac"/.etf.txt
touch /home/clientshared/.Temp/."$ac"/.s.txt
touch /home/clientshared/.Temp/."$ac"/.t.txt
touch /home/clientshared/.Temp/."$ac"/.c.txt
touch /home/clientshared/.Temp/."$ac"/.p.txt
touch /home/clientshared/.Temp/."$ac"/.tc.txt
sleep 3s

prog=$(cat "/home/clientshared/.Temp/."$ac"/.prg.txt")
echo "$prog"
if [[ "$prog" == "Wiping" || "$prog" == "Testing" ]];
then
  true
else
  echo "Started Wiping"
  echo "Wiping" > /home/clientshared/.Temp/."$ac"/.prg.txt
  #send serial number
  touch /home/clientshared/.Temp/."$ac"/.p.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

  touch /home/clientshared/.Temp/."$ac"/.te.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

  touch /home/clientshared/.Temp/."$ac"/.tr.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

  touch /home/clientshared/.Temp/."$ac"/.etf.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

  touch /home/clientshared/.Temp/."$ac"/.t.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.t.txt

  touch /home/clientshared/.Temp/."$ac"/.c.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.c.txt
  ## scan and get data

  # # BAYS SEARCH
  # #4Bay
  # dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)
  # #45 BAY
  hst=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $2}')
  ex=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $3}')
  ex2=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $4}')
  loc=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $5}')
  dev7=$(find /sys/class/scsi_host/host"$hst"/device/phy-"$hst":"$ex2"/port/expander-"$hst":"$ex"/phy-"$hst":"$ex":"$loc"/port/ -type d -name "sd*" | head -n 1)
  dev7="sd${dev7##*sd}"
  hpasectors=$(sudo hdparm -N /dev/"$dev7" | grep -i "max" | awk '{print $4}' | tr -d ",")
  hpasectors=${hpasectors##*/}
  remove=$(sudo hdparm -N p$hpasectors /dev/"$dev7")
  restore=$(sudo hdparm --yes-i-know-what-i-am-doing --dco-restore /dev/"$dev7")
  sleep 2s
  s7=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $6}')
  #
  # #24 Bay
  # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
  # h=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $3}')
  # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
  # dev7="sd${dev7##*sd}"
  #
  # #15 Bay
  # h=$(find /sys/class/scsi_host/*/device/ -type d -name "phy-*:15" | head -n 1 | cut -d '/' -f 5)
  # h=${h##*host}
  # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
  # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
  # dev7="sd${dev7##*sd}"
  # ######

  #check if Showing Serial
  s7=$(sudo smartctl -i /dev/"$dev7" | grep -i "Serial Number" | awk '{print $3,$4}' | tr -d " ")
  touch /home/clientshared/.Temp/."$ac"/.dev.txt
  echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt
  # fi
  s5="$s7"
  if [[ ! -z "$s5" ]]
    then
      echo "Drive Present Starting Wipe: $(date)"

      # # BAYS SEARCH
      # #4Bay
      # dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)
      #45 BAY
      hst=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $2}')
      ex=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $3}')
      ex2=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $4}')
      loc=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $5}')
      dev7=$(find /sys/class/scsi_host/host"$hst"/device/phy-"$hst":"$ex2"/port/expander-"$hst":"$ex"/phy-"$hst":"$ex":"$loc"/port/ -type d -name "sd*" | head -n 1)
      dev7="sd${dev7##*sd}"
      s7=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $6}')
      #
      # #24 Bay
      # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
      # h=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $3}')
      # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
      # dev7="sd${dev7##*sd}"
      #
      # #15 Bay
      # h=$(find /sys/class/scsi_host/*/device/ -type d -name "phy-*:15" | head -n 1 | cut -d '/' -f 5)
      # h=${h##*host}
      # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
      # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
      # dev7="sd${dev7##*sd}"

      ## scan and get dat
      hdsent=$(sudo /home/clientshared/.HD -dev /dev/"$dev7")
      s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
      #verify through sg
      ttSAT=$(sudo smartctl -i /dev/"$dev7" | grep "SATA")
      ttSAS=$(sudo smartctl -i /dev/"$dev7" | grep "SAS")
      if [[ -z "$ttSAT" ]]; then if [[ ! -z "ttSAS" ]]; then t7="SAS"; else "NA"; fi; else t7="SATA"; fi
      echo "$t7"
      #rotation per minute
      rpm=$(sudo smartctl -i /dev/"$dev7" | grep -i "rotation" | awk '{print $3,$4}')
      rpm1=$(sudo smartctl -i /dev/"$dev7" | grep -i "solid")
      if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
      #manufacturer and model
      testman=$(echo "$hdsent" | grep "Model" | wc -w)
      if [[ $"testman" -eq 6 ]];
      then mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
      else manuf=$(sudo smartctl -i /dev/"$dev7" | grep -i "Family" | awk '{print $3}'); mdl=$(echo "$hdsent" | grep "Model" | awk '{print $4}'); fi
      #send serial
      touch /home/clientshared/.Temp/."$ac"/.s.txt
      echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
      #send type
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      #send capacity
      c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
      echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      #set Write cache
      sleep 2
      w=$(sudo hdparm -W1 /dev/"$dev7")
      sleep 1
      w=$(sudo sdparm -s WCE /dev/"$dev7")
      ## start time
      st=$(date '+%H:%M:%S')
      sts=$(date '+%s' -d "$st")

      #### wiping dump file
      rm -f /home/clientshared/.Temp/."$ac"/.dump.txt
      touch /home/clientshared/.Temp/."$ac"/.dump.txt

      #initial health and set to zero if ?
      htx=$(echo "$hdsent" | grep "Health" | awk '{print $3}')
      if [[ "$htx" == "?" ]]; then htx="0"; else true; fi
      sleep 1
      ##########################################
      ### print up to window
      echo "$h $d $s7 $t7 $c7 $mdl $rpm $htx $s"

      ##date
      dte=$(date "+%Y-%m-%d")

      sleep 2
      ###Testing how to wipe
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      ###
      #get existing percetn if already SAS
      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')
      if [[ "$t7" == "SATA" ]]; then test1="a"; else test1=""; fi
      if [[ ! -z "$test1" ]]
      then
      ####################################start wiping if SATA
      echo "Drive is SATA capable: Wiping"
      rm -f /home/clientshared/.Temp/."$ac"/.log.log
      touch /home/clientshared/.Temp/."$ac"/.log.log
      SSDD=$(sudo blockdev --getsize64 /dev/"$dev7")
      echo "" > /home/clientshared/.Temp/."$ac"/.log.log
      sudo ddrescue -fnDN -r 3 -s ${SSDD//[!0-9]/} -b 8 -K 0 --log-events=/home/clientshared/.Temp/."$ac"/.log.log /dev/zero /dev/"$dev7" > /home/clientshared/.Temp/."$ac"/.dump.txt &
      sleep 2

      ## start time loop
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      stoppingloop=1
      while [[ -z "$a" ]]
      do
      ## CURRENT PERCENTAGE
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      p=$(cat /home/clientshared/.Temp/."$ac"/.dump.txt | grep -a "pct" | tail -n 1 | awk '{print $3}' | tr -d " %, ")
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt
      sleep 1
      b="$p"
      b=${b%.*}
      if [ "$b" -gt 99 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      stoppingloop=$(cat /home/clientshared/.Temp/."$ac"/.stopping.txt)
      if [[ "$stoppingloop" == "Stop" ]]; then a=1; final=""; else false; fi

      done
      #####WIPE AS SAS
      else
      ###start formatting
      echo "Drive is not SAS capable and if was started is at $p percent"
      sudo sg_format --format --ffmt=2 -Q -6 -e -l -b /dev/"$dev7"
      sleep 3s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l /dev/"$dev7"
      sleep 5s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l /dev/"$dev7"
      sleep 3s
      sudo smartctl -i /dev/"$dev7" | grep -i "rotation" | awk '{print $3,$4}'
      sleep 5s
      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')
      if [[ -z "$p" ]]; then sudo sg_format --format -Q -6 -e -l /dev/"$dev7"; else true; fi
      sleep 1s
      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')
      while [[ ! -z "$p" ]]
      do
      ## CURRENT PERCENTAGE

      sleep 1

      ## CURRENT TIME
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      ### if goes over
      b="$p"
      b=${b%.*}
      if [ "$b" -gt 99 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')

      stoppingloop=$(cat /home/clientshared/.Temp/."$ac"/.stopping.txt)
      if [[ "$stoppingloop" == "Stop" ]]; then p=""; final=""; else false; fi

      done
      fi
      ##done wiping
      #####finished now done and clear counts
      echo "Drive Started testing: $(date)"
      echo "Testing" > /home/clientshared/.Temp/."$ac"/.prg.txt
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

      ### What percent

      #sample if it wipe, if it did, then proceed to test, else result=Failed: Verify
      #sleep 30
      sleep 15s
      #verify if went over 97%
        if [ "$final" == "pass" ]
        then
          echo "Drive Passed Write Sequence"
          p="100%"

          # # BAYS SEARCH
          # #4Bay
          # dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)
          #45 BAY
          hst=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $2}')
          ex=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $3}')
          ex2=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $4}')
          loc=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $5}')
          dev7=$(find /sys/class/scsi_host/host"$hst"/device/phy-"$hst":"$ex2"/port/expander-"$hst":"$ex"/phy-"$hst":"$ex":"$loc"/port/ -type d -name "sd*" | head -n 1)
          dev7="sd${dev7##*sd}"
          s7=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $6}')
          #
          # #24 Bay
          # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
          # h=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $3}')
          # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
          # dev7="sd${dev7##*sd}"
          #
          # #15 Bay
          # h=$(find /sys/class/scsi_host/*/device/ -type d -name "phy-*:15" | head -n 1 | cut -d '/' -f 5)
          # h=${h##*host}
          # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
          # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
          # dev7="sd${dev7##*sd}"

          ## scan and get dat
          hdsent=$(sudo /home/clientshared/.HD -dev /dev/"$dev7")
          s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
          #verify through sg
          ttSAT=$(sudo smartctl -i /dev/"$dev7" | grep "SATA")
          ttSAS=$(sudo smartctl -i /dev/"$dev7" | grep "SAS")
          if [[ -z "$ttSAT" ]]; then if [[ ! -z "ttSAS" ]]; then t7="SAS"; else "NA"; fi; else t7="SATA"; fi

          #rotation per minute
          rpm=$(sudo smartctl -i /dev/"$dev7" | grep -i "rotation" | awk '{print $3,$4}')
          rpm1=$(sudo smartctl -i /dev/"$dev7" | grep -i "solid")
          if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
          #manufacturer and model
          testman=$(echo "$hdsent" | grep "Model" | wc -w)
          if [[ $"testman" -eq 6 ]];
          then mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
          else manuf="None"; mdl=$(echo "$hdsent" | grep "Model" | awk '{print $5}'); fi
          #send serial
          touch /home/clientshared/.Temp/."$ac"/.s.txt
          echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
          #send type
          echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
          #send capacity
          c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
          echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
          echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt

          #Bay 45 SG DEV
          hst=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $2}')
          ex=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $3}')
          ex2=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $4}')
          loc=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $5}')
          sg7=$(find /sys/class/scsi_host/host"$hst"/device/phy-"$hst":"$ex2"/port/expander-"$hst":"$ex"/phy-"$hst":"$ex":"$loc"/port/ -type d -name "sg*" | head -n 1)
          sgdev="sg${sg7##*sg}"

          echo "$sgdev"

          bloc=$(sudo sginfo -a /dev/"$sgdev" | grep -i "phys" | awk '{print $6}')
          a=$(sudo sg_dd if=/dev/"$sgdev" of=- count=4MB bs="$bloc" dio=1 | od)
          b=$(echo "$a" | tail -n 1)
          echo "number of blocks for verify $b"
          num=$(echo "$a" | wc -l)
          if [[ "$b" -eq "17376444000" || "$b" -eq "17204400000" || "$b" -eq "172044000000" || "$b" -eq "173764440000" ]]; then num1="3"; else num1="1"; fi
          #end verify
          echo "num is $num1, if 3 then verifies, else 1"
          if [[ "$num1" -eq 3 ]]
          then
                echo "Start Self Test for:"
                echo ""
                s7=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $6}')
                type7=$(sudo smartctl -i /dev/"$dev7" | grep -e "SATA")
                if [[ ! -z "$type7" ]]; then type7="SATA"; else type7="SAS"; fi
                htx=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
                if [[ "$htx" == "?" ]]; then htx=0; else false; fi
                echo "intial health $htx"
                #begin testing
                # does device support logging
                t1=$(sudo smartctl -l selftest /dev/"$dev7" | grep -e "does not support")
                if [[ -z "$t1" ]]
                  #yes it does
                then
                  startest=$(sudo smartctl -t short /dev/"$dev7")
                  t1=$(sudo smartctl -l selftest /dev/"$dev7" | grep -e "Background")
                  sleep 3
                  if [[ ! -z "$t1" ]]
                  then
                    startest=$(sudo smartctl -t short /dev/"$dev7")
                    test=$(sudo smartctl -l selftest /dev/"$dev7" | grep -i "Self-test execution status:" )
                    perc=$(echo "$test" | awk '{print $4}')
                    count=1
                    while [[ ! -z "$test" ]]
                    do
                      test=$(sudo smartctl -l selftest /dev/"$dev7" | grep -i "Self-test execution status:" )
                      perc1=$(echo "$test" | awk '{print $1}')
                      if [[ "$perc" != "$perc1" ]]
                      then
                        echo "$perc1"
                      else
                        true
                      fi
                      sleep 3
                      if [[ "$count" -lt 210 ]]
                      then
                        count=$(($count + 1))
                      else
                        test=""
                      fi
                      perc=$(echo "$test" | awk '{print $1}')
                    done
                  else
                    startest=$(sudo smartctl -t short /dev/"$dev7")
                    sleep 1
                    test=$(sudo smartctl -c /dev/"$dev7" | grep -i "remaining" )
                    perc=$(echo "$test" | awk '{print $1}')
                    count=1
                    while [[ ! -z "$test" ]]
                    do
                      test=$(sudo smartctl -c /dev/"$dev7" | grep -i "remaining")
                      perc1=$(echo "$test" | awk '{print $1}')
                      if [[ "$perc" != "$perc1" ]]
                      then
                        echo "$perc1"
                      else
                        true
                      fi
                      sleep 1
                      if [[ "$count" -lt 210 ]]
                      then
                        count=$(($count + 1))
                      else
                        test=""
                      fi
                      perc=$(echo "$test" | awk '{print $1}')
                    done
                  fi
                  result=$(sudo smartctl -l selftest /dev/"$dev7" | grep "# 1")

                  #is it the offline type?
                  resulta=$(echo "$result" | grep "offline")
                  #is it the completed type?
                  resultb=$(echo "$result" | grep "Completed")

                  if [[ ! -z "$resulta" ]]
                    then
                      resultc=$(sudo smartctl -l selftest /dev/"$dev7" | grep "# 1" | awk '{print $6,$7}')
                        if [ "$resultc" == "without error" ]
                          then
                          ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
                          if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                            if [ "$ht" -gt 59 ]
                              then
                              result="Passed"
                              result2="Passed"
                            else
                              result2="Failed: Health"
                              result="Failed"
                            fi
                        else
                          result2="Failed: DST"
                          result="Failed"
                        fi
                # different for SAS type
                  elif [[ ! -z "$resultb" ]]
                      then
                        ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
                        if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                        if [ "$ht" -gt 59 ]
                          then
                            result="Passed"
                            result2="Passed"
                        else
                          result2="Failed: Health"
                          result="Failed"
                        fi
                  else
                      result2="Failed: DST"
                      result="Failed"
                    fi
                else
                  ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
                  if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                  if [ "$ht" -gt 59 ]
                    then
                      result="Passed"
                      result2="Passed"
                  else
                      result2="Failed: Health SAS"
                      result="Failed"
                  fi
                fi
          else
              result2="Failed: Verify"
              result="Failed"
          fi

          echo "$ac result = $result and result2 = $result2"
          ##### testing end
          ######
          hdsent=$(sudo /home/clientshared/.HD -dev /dev/"$dev7")
          s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
          #verify through sg
          ttSAT=$(sudo smartctl -i /dev/"$dev7" | grep "SATA")
          ttSAS=$(sudo smartctl -i /dev/"$dev7" | grep "SAS")
          if [[ -z "$ttSAT" ]]; then if [[ ! -z "ttSAS" ]]; then t7="SAS"; else "NA"; fi; else t7="SATA"; fi
          echo "$t7"

          #rotation per minute
          rpm=$(sudo smartctl -i /dev/"$dev7" | grep -i "rotation" | awk '{print $3,$4}')
          rpm1=$(sudo smartctl -i /dev/"$dev7" | grep -i "solid")
          if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
          #manufacturer and model
          testman=$(echo "$hdsent" | grep "Model" | wc -w)
          if [[ $"testman" -eq 6 ]];
          then mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
          else manuf="None"; mdl=$(echo "$hdsent" | grep "Model" | awk '{print $5}'); fi
          #send serial
          touch /home/clientshared/.Temp/."$ac"/.s.txt
          echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
          #send type
          echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
          #send capacity
          c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
          echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
          echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
          echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
          echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
          if [[ "$result" == "Passed" ]] && [[ "$ht" -eq 100 ]]
            then result="Tested for Full Function R2/Ready for Reuse"
          elif [[ "$result" == "Passed" && "$ht" -lt 100 ]]
            then result="Tested for Key Function R2/Ready for Resale"
          else false
          fi
          echo "time to test: $count"
          echo "device: $dev7"

        else
          sleep 1

          # # BAYS SEARCH
          # #4Bay
          # dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)
          #45 BAY
          #hst=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $2}')
          #ex=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $3}')
          #ex2=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $4}')
          #loc=$(cat /home/clientshared/set96.txt | grep "$ac" | awk '{print $5}')
          #dev7=$(find /sys/class/scsi_host/host"$hst"/device/phy-"$hst":"$ex2"/port/expander-"$hst":"$ex"/phy-"$hst":"$ex":"$loc"/port/ -type d -name "sd*" | head -n 1)
          #dev7="sd${dev7##*sd}"
          #s7=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $6}')
          #echo "$s7"
          #
          # #24 Bay
          # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
          # h=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $3}')
          # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
          # dev7="sd${dev7##*sd}"
          #
          # #15 Bay
          # h=$(find /sys/class/scsi_host/*/device/ -type d -name "phy-*:15" | head -n 1 | cut -d '/' -f 5)
          # h=${h##*host}
          # d=$(cat /home/clientshared/.set.txt | grep "$ac" | awk '{print $2}')
          # dev7=$(find /sys/class/scsi_host/host"$h"/device/phy-"$h":"$d"/port/ -type d -name "sd*" | head -n 1)
          # dev7="sd${dev7##*sd}"

          sleep 1
          if [[ "$ht" == "?" ]] || [[ "$ht" == "" ]]; then ht=0; else false; fi
          echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
          echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
          result2="Failed: Wiping"
          result="Failed"
          echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
        fi
        dte=$(date "+%Y-%m-%d")
        cserial=$(sudo dmidecode -t system | grep Serial | awk '{print $3}')
    if [[ -z "$ch" ]]; then ch="N"; else true; fi
    me=$(whoami)
    size1=$(sudo smartctl -i /dev/"$dev7" | grep "Form Factor:" | awk '{print $3}')
    #manufacturer and model
    hdsent=$(sudo /home/clientshared/.HD -dev /dev/"$dev7")
    mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6,$7,$8,$9,$10,$11,$12,$13}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
    modelnum=$(echo "$mdl" | wc -w)
    if [[ "$mdl" -eq 0 ]]; then mdl=$(echo "$hdsent" | grep "Model" | awk '{print $5,$6,$7,$8,$9,$10,$11,$12,$13}'); manuf=$(sudo smartctl -i /dev/"$dev7" | grep -i "Family" | awk '{print $3}'); manuf=${manuf^^}; else true; fi
    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt
    #location="jasperprogram.TIS_JBOD"

    # location="jasperprogram.TIS"
        running=$(mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into jasperprogram.TIS_JBOD1 (client, process, result, charge, serial_number, manufacturer, model, capacity, type_drive, size, RPM, date_wiped, job_number, employee, system_name, sub_system_name, system_serial, software_version, compliance, sub_result, time_lapsed, health_init, health_final, perc_done) values ('TIS', 'Wiping', '$result', '$ch', '$s7', '$manuf', '$mdl', '$c7', '$t7', '$size1', '$rpm', '$dte', '$loadnm', '$employee', '$me', '$compnum', '$cserial', 'Jasper Wiping v2.1', 'NIST-800-88 rev1: Clear: Overwrite Method', '$result2', '$te', '$htx', '$ht', '$p')")
  else
    echo "No device shown"
    #is no device
    touch /home/clientshared/.Temp/."$ac"/.p.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

    touch /home/clientshared/.Temp/."$ac"/.te.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

    touch /home/clientshared/.Temp/."$ac"/.tr.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

    touch /home/clientshared/.Temp/."$ac"/.etf.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

    touch /home/clientshared/.Temp/."$ac"/.prg.txt
    echo "No Device" > /home/clientshared/.Temp/."$ac"/.prg.txt

    touch /home/clientshared/.Temp/."$ac"/.c.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.c.txt

    touch /home/clientshared/.Temp/."$ac"/.tc.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tc.txt

    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt

    touch /home/clientshared/.Temp/."$ac"/.s.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.s.txt

    touch /home/clientshared/.Temp/."$ac"/.dev.txt
    echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt

    touch /home/clientshared/.Temp/."$ac"/.stopping.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.stopping.txt
  fi
fi
echo "Process $ac done at $p percent"
sleep 1s
echo "" > /home/clientshared/.Temp/."$ac"/.stopping.txt
dc=$(echo "$ac" | tr -d "B"); dc=$(( "$dc" + 0 )); sudo killall .Bay$dc.sh
"""

##create files if not present
file = open("/home/clientshared/.tempfile.sh", "w")
filesopen = """#!/bin/bash
for ac in {1..9}
do
    mkdir /home/clientshared/.Temp/.B0"$ac"
    touch /home/clientshared/.Temp/.B0"$ac"/.p.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.te.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.tr.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.etf.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.prg.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.c.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.tc.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.tr1.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.s.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.dev.txt

    touch /home/clientshared/.Temp/.B0"$ac"/.stopping.txt
done 2>/dev/null
for ac in {10..96}
do
    mkdir /home/clientshared/.Temp/.B"$ac"
    touch /home/clientshared/.Temp/.B"$ac"/.p.txt

    touch /home/clientshared/.Temp/.B"$ac"/.te.txt

    touch /home/clientshared/.Temp/.B"$ac"/.tr.txt

    touch /home/clientshared/.Temp/.B"$ac"/.etf.txt

    touch /home/clientshared/.Temp/.B"$ac"/.prg.txt

    touch /home/clientshared/.Temp/.B"$ac"/.c.txt

    touch /home/clientshared/.Temp/.B"$ac"/.tc.txt

    touch /home/clientshared/.Temp/.B"$ac"/.tr1.txt

    touch /home/clientshared/.Temp/.B"$ac"/.s.txt

    touch /home/clientshared/.Temp/.B"$ac"/.dev.txt

    touch /home/clientshared/.Temp/.B"$ac"/.stopping.txt
done 2>/dev/null
"""
f1 = file.write(filesopen)
f2 = file.close()
os.chmod("/home/clientshared/.tempfile.sh",509)
a = subprocess.Popen(["/home/clientshared/.tempfile.sh"])
time.sleep(.05)
wf = os.remove("/home/clientshared/.tempfile.sh")
print("Created all files")

if __name__ == "__main__":
	main = main_window()
	Gtk.main()

#!/usr/bin/env python3
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import sys
import subprocess
import threading
from gi.repository import GObject
from gi.repository import GLib
import time
from gi.repository import Gdk
from gi.repository import Pango
from time import sleep
import os
import base64
import sendgrid
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)
import datetime
import pandas as pd
from datetime import datetime as dt
from requests import get

version_jasp = "Jasper Wiping v3.03"
##clear wiping on reboot
print(version_jasp)

for i in range(1,5):
    #Bay overall
    if i < 10:
        loc = "B0{}".format(i)
    else:
        loc = "B{}".format(i)

    #progress

    prg = open('/home/clientshared/.Temp/.{}/.prg.txt'.format(loc)).read().strip()

    if prg == "Wiping":
        #normal tab
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.log.log'.format(loc)], stderr=None, shell=True)
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.prg.txt'.format(loc)], stderr=None, shell=True)
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.tc.txt'.format(loc)], stderr=None, shell=True)
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.tr.txt'.format(loc)], stderr=None, shell=True)
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.te.txt'.format(loc)], stderr=None, shell=True)
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.etf.txt'.format(loc)], stderr=None, shell=True)
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.p.txt'.format(loc)], stderr=None, shell=True)
        subprocess.check_output(['echo "" > /home/clientshared/.Temp/.{}/.s.txt'.format(loc)], stderr=None, shell=True)


class main_window():
    #initi main window class
    def __init__(self):

        self.gladefile = "/home/clientshared/cloning.glade"

        wf = open("/home/clientshared/.General/Job_Number.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        wf = open("/home/clientshared/.General/Employee.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        #Start the hard drive wiping and send yes to visible
        self.builder = Gtk.Builder()
        self.builder.add_from_file(self.gladefile)

        cssProvider = Gtk.CssProvider()
        cssProvider.load_from_path('/home/clientshared/another.css')
        #cssProvider.load_from_path('/home/sr/Documents/GitHub/jbeta/Jasper Wiping/Desktop Wiping/another.css')
        screen = Gdk.Screen.get_default()
        styleContext = Gtk.StyleContext()
        styleContext.add_provider_for_screen(screen, cssProvider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        #main window
        self.main_window = self.builder.get_object("window1")
        #signals
        self.builder.connect_signals(self)

        # start
        self.main_window = self.builder.get_object("window1")
        # self.main_window.set_events (Gdk.enter.Notify.MASK);
        # self.main_window.add_events (Gdk.leave.Notify.MASK);
        #employ

        # ta = os.remove("/home/clientshared/sampling.py")
        # ta = os.remove("/home/clientshared/another.css")
        # ta = os.remove("/home/clientshared/sample.glade")

        for i in range(1,2):
            #prg
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            self.prg.set_text("")
            #prg style
            self.prg_style = self.prg.get_style_context()
            self.prg_style.remove_class('wiping')
            self.prg_style.add_class('invisible')

            #per
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            self.p.set_text("")
            #per
            # self.s.set_text("Serial Number Here")
            # self.s_style = self.s.get_style_context()
            # self.s_style.remove_class('bottom')
            # self.s_style.add_class('bottoms')
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            self.te.set_text("")
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            self.tr.set_text("")
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            self.etf.set_text("")

        file = os.remove("/home/clientshared/cloning.py")
        file = os.remove("/home/clientshared/cloning.glade")
        file = os.remove("/home/clientshared/another.css")
        #start thread
        thread = threading.Thread(target=self.update)
        thread.daemon = True
        thread.start()

    def on_window1_destroy(self, object, data=None):
        print("quit with cancel")
        Gtk.main_quit()

    def on_start_all_clicked(self, object, data=None):
            print("Drives Cloning")
            wf = open("/home/clientshared/.B01.sh","w")
            wf1 = wf.write(wiping_a)
            wf2 = wf.close()
            os.chmod("/home/clientshared/.B01.sh",509)
            a = subprocess.Popen(["/home/clientshared/.B01.sh","B01"])
            time.sleep(.1)
            wf = os.remove("/home/clientshared/.B01.sh")

    def update_label(self):

        #full cycle:
        for i in range(1,2):
            t = "B0{}".format(i)
            #progress
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            prgx = self.prg.get_text()
            prg = open('/home/clientshared/.Temp/.{}/.prg.txt'.format(t)).read().strip()
            #part 2
            if prgx != prg:
                if prg == "Done":
                    #normal tab
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Done")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('failed')
                    self.prg_style.add_class('passed')

                elif prg == "Failed" or prg == "Failed: Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Failed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('failed')

                elif prg == "Cloning":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Cloning")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('failed')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('wiping')
            #Perc
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            p = open('/home/clientshared/.Temp/.{}/.p.txt'.format(t)).read().strip()
            self.p.set_text(p)
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            tr = open('/home/clientshared/.Temp/.{}/.tr.txt'.format(t)).read().strip()
            self.tr.set_text(tr)
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            te = open('/home/clientshared/.Temp/.{}/.te.txt'.format(t)).read().strip()
            self.te.set_text(te)
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            etf = open('/home/clientshared/.Temp/.{}/.etf.txt'.format(t)).read().strip()
            self.etf.set_text(etf)

        return False

    def update(self):
        while True:
            GLib.idle_add(self.update_label)
            time.sleep(.5)

wiping_a = """#!/bin/bash

ac="$1"

touch /home/clientshared/.Temp/."$ac"/.prg.txt

touch /home/clientshared/.Temp/."$ac"/.tr.txt
touch /home/clientshared/.Temp/."$ac"/.te.txt
touch /home/clientshared/.Temp/."$ac"/.etf.txt
touch /home/clientshared/.Temp/."$ac"/.s.txt
touch /home/clientshared/.Temp/."$ac"/.t.txt
touch /home/clientshared/.Temp/."$ac"/.c.txt
touch /home/clientshared/.Temp/."$ac"/.p.txt
sleep 3s

prog=$(cat "/home/clientshared/.Temp/."$ac"/.prg.txt")
echo "$prog"
if [[ "$prog" == "Cloning" ]];
then
  true
else
  echo "Started Cloning"
  echo "Cloning" > /home/clientshared/.Temp/."$ac"/.prg.txt
  #send serial number
  touch /home/clientshared/.Temp/."$ac"/.p.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

  touch /home/clientshared/.Temp/."$ac"/.te.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

  touch /home/clientshared/.Temp/."$ac"/.tr.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

  touch /home/clientshared/.Temp/."$ac"/.etf.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

  touch /home/clientshared/.Temp/."$ac"/.t.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.t.txt

  touch /home/clientshared/.Temp/."$ac"/.c.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.c.txt

  touch /home/clientshared/.Temp/."$ac"/.log.log
  echo "" > /home/clientshared/.Temp/."$ac"/.log.log
  ## scan and get data
      ####################################start wiping if SATA
      echo "Drive is SATA capable: Wiping"
      rm -f /home/clientshared/.Temp/."$ac"/.log.log
      touch /home/clientshared/.Temp/."$ac"/.log.log
      SSDD=$(sudo blockdev --getsize64 /dev/sdb)
      echo "" > /home/clientshared/.Temp/."$ac"/.log.log
      sudo ddrescue -fnND -r 3 -s ${SSDD//[!0-9]/} -b 8 -K 0 --log-events=/home/clientshared/.Temp/."$ac"/.log.log /dev/sdb /dev/sdc > /home/clientshared/.Temp/."$ac"/.dump.txt &
      sleep 2
      ## start time
      st=$(date '+%H:%M:%S')
      sts=$(date '+%s' -d "$st")

      ## start time loop
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      while [[ -z "$a" ]]
      do
      ## CURRENT PERCENTAGE
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      p=$(cat /home/clientshared/.Temp/."$ac"/.dump.txt | grep -a "pct" | tail -n 1 | awk '{print $3}' | tr -d " %, ")
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt
      sleep 1
      b="$p"
      b=${b%.*}
      if [ "$b" -gt 99 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      done
      ##done wiping
      #####finished now done and clear counts
      echo "Drive Started testing: $(date)"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

      ### What percent

      #sample if it wipe, if it did, then proceed to test, else result=Failed: Verify
      #sleep 30
      sleep 6s
      if [[ -z "$test1" ]]
      then
       p=$(cat /home/clientshared/.Temp/."$ac"/.log.log | grep -i "End of run" | awk '{print $2}' | tr -d " %, ")
       testp="$p"
       testp=${testp%.*}
       if [[ "$testp" -eq 100 ]]; then final="pass"; else final=""; p+="%"; fi
       echo "Done" > /home/clientshared/.Temp/."$ac"/.prg.txt
      else
       if [[ "$final" == "pass" ]]; then true; else p="$finalp"; final=""; p+="%"; fi
      fi

fi
echo "Done Cloning" && exit

"""


if __name__ == "__main__":
    main = main_window()
    Gtk.main()

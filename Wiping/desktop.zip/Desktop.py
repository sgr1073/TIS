#!/usr/bin/env python3
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import sys
import subprocess
import threading
from gi.repository import GObject
from gi.repository import GLib
import time
from gi.repository import Gdk
from gi.repository import Pango
from time import sleep
import os
import base64
import sendgrid
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)
import datetime
import pandas as pd
from datetime import datetime as dt
from requests import get

class main_window():
    #initi main window class
    def __init__(self):

        self.gladefile = "/home/clientshared/Desktop.glade"

        wf = open("/home/clientshared/.General/Job_Number.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        wf = open("/home/clientshared/.General/Employee.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        #Start the hard drive wiping and send yes to visible
        self.builder = Gtk.Builder()
        self.builder.add_from_file(self.gladefile)

        cssProvider = Gtk.CssProvider()
        cssProvider.load_from_path('/home/clientshared/another.css')
        #cssProvider.load_from_path('/home/sr/Documents/GitHub/jbeta/Jasper Wiping/Desktop Wiping/another.css')
        screen = Gdk.Screen.get_default()
        styleContext = Gtk.StyleContext()
        styleContext.add_provider_for_screen(screen, cssProvider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        #main window
        self.main_window = self.builder.get_object("window1")
        #signals
        self.builder.connect_signals(self)

        # start
        self.main_window = self.builder.get_object("window1")
        #employee
        self.employee = self.builder.get_object("employee")
        #job number
        self.job_number = self.builder.get_object("load_all")

        self.complete = self.builder.get_object("complete")

        self.error_submitting = self.builder.get_object("error_submitting")
        self.nodrive = self.builder.get_object("nodrive")

        self.finishing_message = self.builder.get_object("finishing_message")

        self.ndrive = self.builder.get_object("ndrive")
        self.complete = self.builder.get_object("complete")

        self.load_d1 = self.builder.get_object("load_d1")
        self.load_d2 = self.builder.get_object("load_d2")
        self.load_d3 = self.builder.get_object("load_d3")
        self.load_d4 = self.builder.get_object("load_d4")
        self.load_all = self.builder.get_object("load_all")

        self.submit_all = self.builder.get_object("submit_all")
        self.submit_indv = self.builder.get_object("submit_indv")
        self.start_all = self.builder.get_object("start_all")
        self.refresh_values = self.builder.get_object("refresh_values")

        # ta = os.remove("/home/clientshared/sampling.py")
        # ta = os.remove("/home/clientshared/another.css")
        # ta = os.remove("/home/clientshared/sample.glade")

        for i in range(1,5):
            #prg
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            self.prg.set_text("")
            #prg style
            self.prg_style = self.prg.get_style_context()
            self.prg_style.remove_class('wiping')
            self.prg_style.add_class('invisible')

            #per
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            self.p.set_text("")
            #per
            s = 's"{}"'.format(i)
            self.s = self.builder.get_object("s{}".format(i))
            self.s.set_text("")
            #set ellipsis must get Pango
            self.s.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
            self.s.set_max_width_chars(18)
            # self.s.set_text("Serial Number Here")
            # self.s_style = self.s.get_style_context()
            # self.s_style.remove_class('bottom')
            # self.s_style.add_class('bottoms')
            #tc
            tc = 'tc"{}"'.format(i)
            self.tc = self.builder.get_object("tc{}".format(i))
            self.tc.set_text("")
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            self.te.set_text("")
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            self.tr.set_text("")
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            self.etf.set_text("")

        #employee list creation
        wf = open("/home/clientshared/.General/Employees.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from systeminventory.TIS_employee' >> '/home/clientshared/.General/Employees.txt'"], stderr=None, shell=True)
        em_file = open("/home/clientshared/.General/Employees.txt", "r")
        employees = []
        for line in em_file:
          stripped_line = line.strip()
          self.employee.append_text(stripped_line)
        em_file.close()

        #job_number creation
        #all
        self.list1 = Gtk.ListStore(str)

        wf = open("/home/clientshared/.General/Job_Numbers.txt","w")
        wf1 = wf.write("")
        wf2 = wf.close()
        createfile = subprocess.check_output(["mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from systeminventory.TIS_job_number' >> '/home/clientshared/.General/Job_Number.txt'"], stderr=None, shell=True)
        jn_file = open("/home/clientshared/.General/Job_Number.txt", "r")
        i = 0
        for line in jn_file:
            stripped_line = line.strip()
            self.load_all.append_text(stripped_line)
            self.load_d1.append_text(stripped_line)
            self.load_d2.append_text(stripped_line)
            self.load_d3.append_text(stripped_line)
            self.load_d4.append_text(stripped_line)
            print(stripped_line)
        jn_file.close()

        file = os.remove("/home/clientshared/Desktop.py")
        file = os.remove("/home/clientshared/Desktop.glade")
        file = os.remove("/home/clientshared/another.css")
        #start thread
        thread = threading.Thread(target=self.update)
        thread.daemon = True
        thread.start()

    def on_window1_destroy(self, object, data=None):
        print("quit with cancel")
        Gtk.main_quit()

    def on_start_all_clicked(self, object, data=None):
        wf = open("/home/clientshared/.runall.sh","w")
        wf1 = wf.write(starting_a)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.runall.sh",509)
        a = subprocess.check_output(["/home/clientshared/.runall.sh"], stderr=None, shell=True)
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.runall.sh")
        #check drives
        d1 = open("/home/clientshared/.Temp/.B01/.s.txt","r")
        dd1 = d1.read()
        df = d1.close()
        d2 = open("/home/clientshared/.Temp/.B02/.s.txt","r")
        dd2 = d2.read()
        df = d2.close()
        d3 = open("/home/clientshared/.Temp/.B03/.s.txt","r")
        dd3 = d3.read()
        df = d3.close()
        d4 = open("/home/clientshared/.Temp/.B04/.s.txt","r")
        dd4 = d4.read()
        df = d4.close()
        if dd1 != "" and dd2 != "" and dd3 != "" and dd4 != "":
            self.nodrive.hide()
            wf = open("/home/clientshared/.B01.sh","w")
            wf1 = wf.write(wiping_a)
            wf2 = wf.close()
            os.chmod("/home/clientshared/.B01.sh",509)
            a = subprocess.Popen(["/home/clientshared/.B01.sh","B01"])
            time.sleep(.05)
            wf = os.remove("/home/clientshared/.B01.sh")

            wf = open("/home/clientshared/.B02.sh","w")
            wf1 = wf.write(wiping_a)
            wf2 = wf.close()
            os.chmod("/home/clientshared/.B02.sh",509)
            a = subprocess.Popen(["/home/clientshared/.B02.sh","B02"])
            time.sleep(.05)
            wf = os.remove("/home/clientshared/.B02.sh")

            wf = open("/home/clientshared/.B03.sh","w")
            wf1 = wf.write(wiping_a)
            wf2 = wf.close()
            os.chmod("/home/clientshared/.B03.sh",509)
            a = subprocess.Popen(["/home/clientshared/.B03.sh","B03"])
            time.sleep(.05)
            wf = os.remove("/home/clientshared/.B03.sh")

            wf = open("/home/clientshared/.B04.sh","w")
            wf1 = wf.write(wiping_a)
            wf2 = wf.close()
            os.chmod("/home/clientshared/.B04.sh",509)
            a = subprocess.Popen(["/home/clientshared/.B04.sh","B04"])
            time.sleep(.05)
            wf = os.remove("/home/clientshared/.B04.sh")

            self.complete.set_text('Wiping')
            self.cstyle = self.complete.get_style_context()
            self.cstyle.remove_class('ccomplete')
            self.cstyle.remove_class('csent')
            self.cstyle.add_class('cwiping')
        else:
            self.nodrive.show()
        print("start all")

    def on_refresh_values_clicked(self, object, data=None):
        print("refresh all")

    def on_submit_all_clicked(self, object, data=None):
        isdone = self.complete.get_text()
        self.error_submitting.set_text("")
        self.error_submitting.hide()
        print("submit all clicked")
        global test
        test = ""
        if isdone != "Sent":
            for i in range(1,5):
                prg = open('/home/clientshared/.Temp/.B0{}/.prg.txt'.format(i)).read().strip()
                if prg == "Wiping" or prg == "":
                    print("error drives not done")
                    self.error_submitting.set_text("Drives must finish before submitting is available")
                    self.error_submitting.show()
                    test = ""
                    break
                elif prg == "Passed" or prg == "Failed":
                    test = "Complete"

            if test == "Complete":
                load = self.load_all.get_active_text()
                employee = self.employee.get_active_text()
                load = str(load)
                employee = str(employee)
                if load == "None":
                    if employee == "None":
                        print("Not Sending All, No employee selected")
                        self.error_submitting.set_text("Must select an Employee and All Job Number")
                        self.error_submitting.show()
                    else:
                        self.error_submitting.set_text("Must select an All Drive Job Number")
                        self.error_submitting.show()
                else:
                    if employee == "None":
                        print("Not Sending All, No employee selected")
                        self.error_submitting.set_text("Must select an Employee")
                        self.error_submitting.show()
                    else:
                        ctest = str(self.complete.get_text())
                        if ctest != "Sent":
                            print("sending report as a whole")
                            self.complete.set_text('Sent')
                            self.cstyle = self.complete.get_style_context()
                            self.cstyle.remove_class('cwiping')
                            self.cstyle.remove_class('ccomplete')
                            self.cstyle.add_class('csent')
                            self.error_submitting.hide()
                            job = self.job_number.get_active_text()
                            employee = self.employee.get_active_text()
                            print(job,employee)
                            wf = open("/home/clientshared/.sending.sh","w")
                            wf1 = wf.write(sending_info)
                            wf2 = wf.close()
                            os.chmod("/home/clientshared/.sending.sh",509)
                            # a = subprocess.check_output(["/home/clientshared/.sending.sh Y {} {}".format(employee,job)], stderr=None, shell=True)
                            stdout = subprocess.run(['/home/clientshared/.sending.sh', '{}'.format(employee),'N','{}'.format(job)], check=True, capture_output=True, text=True).stdout
                            self.error_submitting.set_text("")
                            self.error_submitting.hide()
                        else:
                            self.error_submitting.set_text("Result already submitted")
                            self.error_submitting.show()
            else:
                self.error_submitting.set_text("Send Drive Info Before Starting")
                self.error_submitting.show()

    def on_submit_indv_clicked(self, object, data=None):
        print("sending each individually")
        employee = str(self.employee.get_active_text())
        j1 = str(self.load_d1.get_active_text())
        j2 = str(self.load_d2.get_active_text())
        j3 = str(self.load_d3.get_active_text())
        j4 = str(self.load_d4.get_active_text())
        if j1 == "None" or j2 == "None" or j3 == "None" or j4 == "None":
            print("Not all drives have Job Number")
            self.error_submitting.set_text("Not all individual drives have a Job Number")
            self.error_submitting.show()
        else:
            if employee == "None":
                print("Must select an Employee")
                self.error_submitting.set_text("Must select an Employee")
                self.error_submitting.show()
            else:
                ctest = str(self.complete.get_text())
                if ctest == "Sent":
                    self.error_submitting.set_text("Result already submitted")
                    self.error_submitting.show()
                else:
                    print("All Drives Send")
                    self.complete.set_text('Sent')
                    self.cstyle = self.complete.get_style_context()
                    self.cstyle.remove_class('cwiping')
                    self.cstyle.remove_class('ccomplete')
                    self.cstyle.add_class('csent')
                    print(j1,j2,j3,j4)
                    wf = open("/home/clientshared/.sending.sh","w")
                    wf1 = wf.write(sending_info)
                    wf2 = wf.close()
                    os.chmod("/home/clientshared/.sending.sh",509)
                    stdout = subprocess.run(['/home/clientshared/.sending.sh', '{}'.format(employee),'Y','{}'.format(j1),'{}'.format(j2),'{}'.format(j3),'{}'.format(j4)], check=True, capture_output=True, text=True).stdout
                    self.error_submitting.set_text("")
                    self.error_submitting.hide()

    def update_label(self):
        #update the error for Drives
        global test1
        test1 = ""
        test2 = self.complete.get_text()
        for i in range(1,5):
            prg = open('/home/clientshared/.Temp/.B0{}/.prg.txt'.format(i)).read().strip()
            if prg == "Wiping" or prg == "":
                break
            elif prg == "Passed" or prg == "Failed":
                test1 = "Complete"

        if test1 == "Complete" and test2 != "Sent":
            #change label to finished
            self.complete.set_text('Finished')
            self.cstyle = self.complete.get_style_context()
            self.cstyle.remove_class('cwiping')
            self.cstyle.remove_class('csent')
            self.cstyle.add_class('ccomplete')

        #update complete

        #full cycle:
        for i in range(1,5):
            t = "B0{}".format(i)
            #progress
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            prgx = self.prg.get_text()
            prg = open('/home/clientshared/.Temp/.{}/.prg.txt'.format(t)).read().strip()
            #part 2
            if prgx != prg:
                if prg == "Passed":
                    #normal tab
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Passed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('failed')
                    self.prg_style.add_class('passed')

                elif prg == "Failed" or prg == "Failed: Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Failed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('failed')

                elif prg == "Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Wiping")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('failed')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('wiping')

            #Type and Cap
            tc = 'tc"{}"'.format(i)
            self.tc = self.builder.get_object("tc{}".format(i))
            tc = open('/home/clientshared/.Temp/.{}/.tc.txt'.format(t)).read().strip()
            self.tc.set_text(tc)
            #Serial
            s = 's"{}"'.format(i)
            self.s = self.builder.get_object("s{}".format(i))
            s = open('/home/clientshared/.Temp/.{}/.s.txt'.format(t)).read().strip()
            self.s.set_text(s)
            #Perc
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            p = open('/home/clientshared/.Temp/.{}/.p.txt'.format(t)).read().strip()
            self.p.set_text(p)
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            tr = open('/home/clientshared/.Temp/.{}/.tr.txt'.format(t)).read().strip()
            self.tr.set_text(tr)
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            te = open('/home/clientshared/.Temp/.{}/.te.txt'.format(t)).read().strip()
            self.te.set_text(te)
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            etf = open('/home/clientshared/.Temp/.{}/.etf.txt'.format(t)).read().strip()
            self.etf.set_text(etf)

        return False

    def update(self):
        while True:
            GLib.idle_add(self.update_label)
            time.sleep(1)

starting_a = """#!/bin/bash
for i in {1..4};
do
touch /home/clientshared/.Temp/.B0"$i"/.p.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.p.txt

touch /home/clientshared/.Temp/.B0"$i"/.te.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.te.txt

touch /home/clientshared/.Temp/.B0"$i"/.tr.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.tr.txt

touch /home/clientshared/.Temp/.B0"$i"/.etf.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.etf.txt

touch /home/clientshared/.Temp/.B0"$i"/.prg.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.prg.txt

touch /home/clientshared/.Temp/.B0"$i"/.c.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.c.txt

touch /home/clientshared/.Temp/.B0"$i"/.tc.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.tc.txt

touch /home/clientshared/.Temp/.B0"$i"/.tr1.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.tr1.txt

touch /home/clientshared/.Temp/.B0"$i"/.s.txt
echo "" > /home/clientshared/.Temp/.B0"$i"/.s.txt

touch /home/clientshared/.Temp/.B0"$i"/.dev.txt
echo "$dev7" > /home/clientshared/.Temp/.B0"$i"/.dev.txt

touch /home/clientshared/.Temp/.B0"$i"/result.txt
echo "$dev7" > /home/clientshared/.Temp/.B0"$i"/result.txt

touch /home/clientshared/.Temp/.B0"$i"/job.txt
echo "$dev7" > /home/clientshared/.Temp/.B0"$i"/job.txt

sudo killall .B0"$i".sh
done
sleep 2s
hdddev=$(sudo smartctl --scan | awk '{print $1}')
hddcount=$(echo "$hdddev" | wc -l)

echo "$hddcount" > "/home/clientshared/.General/.drives.txt"
hdddev=$(sudo smartctl --scan | awk '{print $1}')
hddcount=$(echo "$hdddev" | wc -l)
declare hddlist=($(echo "$hdddev" | tr '\n' ' '))
for i in "${!hddlist[@]}"; do test=$(($i + 1)); send_dev=$(echo "${hddlist[$i]}" > /home/clientshared/.Temp/.B0"$test"/.dev.txt); done

if [[ "$hddcount" != 4 ]]
then
echo "" > /home/clientshared/error.txt
else
for i in {1..4}
do
dev7=$(cat /home/clientshared/.Temp/.B0"$i"/.dev.txt)
hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
echo "$s7" > /home/clientshared/.Temp/.B0"$i"/.s.txt
done
echo "All drives must be present to start" > /home/clientshared/error.txt
fi
echo "Starting is Done"
exit
"""

# b = """ load drives and continue to loop until done, then send done to file once done wiping and result says wiped and values updated"""

wiping_a = """#!/bin/bash
#sleep 15s
####Bay 16
#####
#ac=$1
ac=$1
#what is the type?

touch /home/clientshared/.Temp/."$ac"/.prg.txt
touch /home/clientshared/.Temp/."$ac"/.tr1.txt
touch /home/clientshared/.Temp/."$ac"/.tr.txt
touch /home/clientshared/.Temp/."$ac"/.te.txt
touch /home/clientshared/.Temp/."$ac"/.etf.txt
touch /home/clientshared/.Temp/."$ac"/.s.txt
touch /home/clientshared/.Temp/."$ac"/.t.txt
touch /home/clientshared/.Temp/."$ac"/.c.txt
touch /home/clientshared/.Temp/."$ac"/.p.txt
touch /home/clientshared/.Temp/."$ac"/.tc.txt
touch /home/clientshared/.Temp/."$ac"/result.txt
touch /home/clientshared/.Temp/."$ac"/job.txt
sleep 3s

echo "" > /home/clientshared/.Temp/."$ac"/.prg.txt

prog=$(cat "/home/clientshared/.Temp/."$ac"/.prg.txt")
echo "$prog"
if [[ "$prog" == "Wiping" || "$prog" == "Testing" ]];
then
  true
else
  echo "Started Wiping"
  echo "Wiping" > /home/clientshared/.Temp/."$ac"/.prg.txt
  #send serial number
  touch /home/clientshared/.Temp/."$ac"/.p.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

  touch /home/clientshared/.Temp/."$ac"/.te.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

  touch /home/clientshared/.Temp/."$ac"/.tr.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

  touch /home/clientshared/.Temp/."$ac"/.etf.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

  touch /home/clientshared/.Temp/."$ac"/.t.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.t.txt

  touch /home/clientshared/.Temp/."$ac"/.c.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.c.txt
  ## scan and get data

  # # BAYS SEARCH
  dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)

  #check if Showing Serial
  s7=$(sudo smartctl -i "$dev7" | grep -i "Serial Number" | awk '{print $3,$4}' | tr -d " ")
  # touch /home/clientshared/.Temp/."$ac"/.dev.txt
  # echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt
  # fi
  s5="$s7"
  if [[ ! -z "$s5" ]]
    then
      echo "Drive Present Starting Wipe: $(date)"

      # # BAYS SEARCH
      # dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)
      # dev7=$(dev7="sd${dev7##*sd}")

      ## scan and get dat
      hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
      s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
      #verify through sg
      ttSAT=$(sudo smartctl -i "$dev7" | grep "SATA")
      ttSAS=$(sudo smartctl -i "$dev7" | grep "SAS")
      if [[ -z "$ttSAT" ]]; then if [[ ! -z "ttSAS" ]]; then t7="SAS"; else "NA"; fi; else t7="SATA"; fi
      echo "$t7"
      #rotation per minute
      rpm=$(sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}')
      rpm1=$(sudo smartctl -i "$dev7" | grep -i "solid")
      if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
      #manufacturer and model
      mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6,$7,$8,$9,$10,$11,$12,$13}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
      #send serial
      touch /home/clientshared/.Temp/."$ac"/.s.txt
      echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
      #send type
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      #send capacity
      c7=$(sudo smartctl -i "$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
      echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      #set Write cache
      sleep 2
      w=$(sudo hdparm -W1 "$dev7")
      sleep 1
      w=$(sudo sdparm -s WCE "$dev7")
      ## start time
      st=$(date '+%H:%M:%S')
      sts=$(date '+%s' -d "$st")

      #### wiping dump file
      rm -f /home/clientshared/.Temp/."$ac"/.dump.txt
      touch /home/clientshared/.Temp/."$ac"/.dump.txt

      #initial health and set to zero if ?
      htx=$(echo "$hdsent" | grep "Health" | awk '{print $3}')
      if [[ "$htx" == "?" ]]; then htx="0"; else true; fi
      sleep 1
      ##########################################
      ### print up to window
      echo "$h $d $s7 $t7 $c7 $mdl $rpm $htx $s"

      ##date
      dte=$(date "+%Y-%m-%d")

      sleep 2
      ###Testing how to wipe
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      ###
      #get existing percetn if already SAS
      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      if [[ "$t7" == "SATA" ]]; then test1="a"; else test1=""; fi
      if [[ ! -z "$test1" ]]
      then
      ####################################start wiping if SATA
      echo "Drive is SATA capable: Wiping"
      rm -f /home/clientshared/.Temp/."$ac"/.log.log
      touch /home/clientshared/.Temp/."$ac"/.log.log
      SSDD=$(sudo blockdev --getsize64 "$dev7")
      echo "" > /home/clientshared/.Temp/."$ac"/.log.log
      sudo ddrescue -fnDN -r 3 -s ${SSDD//[!0-9]/} -b 8 -K 0 --log-events=/home/clientshared/.Temp/."$ac"/.log.log /dev/zero "$dev7" > /home/clientshared/.Temp/."$ac"/.dump.txt &
      sleep 2

      ## start time loop
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      while [[ -z "$a" ]]
      do
      ## CURRENT PERCENTAGE
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      p=$(cat /home/clientshared/.Temp/."$ac"/.dump.txt | grep -a "pct" | tail -n 1 | awk '{print $3}' | tr -d " %, ")
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt
      sleep 1
      b="$p"
      b=${b%.*}
      if [ "$b" -gt 97 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      done
      #####WIPE AS SAS
      else
      ###start formatting
      echo "Drive is not SAS capable and if was started is at $p percent"
      sudo sg_format --format --ffmt=2 -Q -6 -e -l "$dev7"
      sleep 3s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l "$dev7"
      sleep 5s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l "$dev7"
      sleep 3s
      sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}'
      sleep 5s
      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      if [[ -z "$p" ]]; then sudo sg_format --format -Q -6 -e -l "$dev7"; else true; fi
      sleep 1s
      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      while [[ ! -z "$p" ]]
      do
      ## CURRENT PERCENTAGE

      sleep 1

      ## CURRENT TIME
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      ### if goes over
      b="$p"
      b=${b%.*}
      if [ "$b" -gt 97 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      p=$(sudo sg_requests -p "$dev7" | awk '{print $3}' | sed 's/%//g')
      done
      fi
      ##done wiping
      #####finished now done and clear counts
      echo "Drive Started testing: $(date)"
      echo "Testing" > /home/clientshared/.Temp/."$ac"/.prg.txt
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

      ### What percent

      #sample if it wipe, if it did, then proceed to test, else result=Failed: Verify
      #sleep 30
      sleep 15s
      #verify if went over 97%
        if [ "$final" == "pass" ]
        then
          echo "Drive Passed Write Sequence"
          p="100%"

          # # BAYS SEARCH
          # dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)
          # dev7=$(dev7="sd${dev7##*sd}")

          ## scan and get dat
          hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
          s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
          #verify through sg
          ttSAT=$(sudo smartctl -i "$dev7" | grep "SATA")
          ttSAS=$(sudo smartctl -i "$dev7" | grep "SAS")
          if [[ -z "$ttSAT" ]]; then if [[ ! -z "ttSAS" ]]; then t7="SAS"; else "NA"; fi; else t7="SATA"; fi

          #rotation per minute
          rpm=$(sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}')
          rpm1=$(sudo smartctl -i "$dev7" | grep -i "solid")
          if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
          #manufacturer and model
          #manufacturer and model
          mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6,$7,$8,$9,$10,$11,$12,$13}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
          #send serial
          touch /home/clientshared/.Temp/."$ac"/.s.txt
          echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
          #send type
          echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
          #send capacity
          c7=$(sudo smartctl -i "$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
          echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
          echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt

          sg7=$(sudo sg_map | grep -i "$dev7" | awk '{print$1}')
          sgdev="${sg7:5}"
          bloc=$(sudo sginfo -a /dev/"$sgdev" | grep -i "phys" | awk '{print $6}')

          a=$(sudo sg_dd if="$dev7" of=- count=4MB bs="$bloc" dio=1 | od)
          b=$(echo "$a" | tail -n 1)
          echo "number of blocks for verify $b"
          num=$(echo "$a" | wc -l)
          if [[ "$b" -eq "17376444000" || "$b" -eq "17204400000" || "$b" -eq "172044000000" || "$b" -eq "173764440000" ]]; then num1="3"; else num1="1"; fi
          #end verify
          echo "num is $num1, if 3 then verifies, else 1"
          if [[ "$num1" -eq 3 ]]
          then
                echo "Start Self Test for:"
                echo ""
                s7=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $6}')
                type7=$(sudo smartctl -i "$dev7" | grep -e "SATA")
                if [[ ! -z "$type7" ]]; then type7="SATA"; else type7="SAS"; fi
                htx=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
                if [[ "$htx" == "?" ]]; then htx=0; else false; fi
                echo "intial health $htx"
                #begin testing
                # does device support logging
                t1=$(sudo smartctl -l selftest "$dev7" | grep -e "does not support")
                if [[ -z "$t1" ]]
                  #yes it does
                then
                  startest=$(sudo smartctl -t short "$dev7")
                  t1=$(sudo smartctl -l selftest "$dev7" | grep -e "Background")
                  sleep 3
                  if [[ ! -z "$t1" ]]
                  then
                    startest=$(sudo smartctl -t short "$dev7")
                    test=$(sudo smartctl -l selftest "$dev7" | grep -i "Self-test execution status:" )
                    perc=$(echo "$test" | awk '{print $4}')
                    count=1
                    while [[ ! -z "$test" ]]
                    do
                      test=$(sudo smartctl -l selftest "$dev7" | grep -i "Self-test execution status:" )
                      perc1=$(echo "$test" | awk '{print $1}')
                      if [[ "$perc" != "$perc1" ]]
                      then
                        echo "$perc1"
                      else
                        true
                      fi
                      sleep 3
                      if [[ "$count" -lt 210 ]]
                      then
                        count=$(($count + 1))
                      else
                        test=""
                      fi
                      perc=$(echo "$test" | awk '{print $1}')
                    done
                  else
                    startest=$(sudo smartctl -t short "$dev7")
                    sleep 1
                    test=$(sudo smartctl -c "$dev7" | grep -i "remaining" )
                    perc=$(echo "$test" | awk '{print $1}')
                    count=1
                    while [[ ! -z "$test" ]]
                    do
                      test=$(sudo smartctl -c "$dev7" | grep -i "remaining")
                      perc1=$(echo "$test" | awk '{print $1}')
                      if [[ "$perc" != "$perc1" ]]
                      then
                        echo "$perc1"
                      else
                        true
                      fi
                      sleep 1
                      if [[ "$count" -lt 210 ]]
                      then
                        count=$(($count + 1))
                      else
                        test=""
                      fi
                      perc=$(echo "$test" | awk '{print $1}')
                    done
                  fi
                  result=$(sudo smartctl -l selftest "$dev7" | grep "# 1")

                  #is it the offline type?
                  resulta=$(echo "$result" | grep "offline")
                  #is it the completed type?
                  resultb=$(echo "$result" | grep "Completed")

                  if [[ ! -z "$resulta" ]]
                    then
                      resultc=$(sudo smartctl -l selftest "$dev7" | grep "# 1" | awk '{print $6,$7}')
                        if [ "$resultc" == "without error" ]
                          then
                          ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
                          if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                            if [ "$ht" -gt 59 ]
                              then
                              result="Passed"
                              result2="Passed"
                            else
                              result2="Failed: Health"
                              result="Failed"
                            fi
                        else
                          result2="Failed: DST"
                          result="Failed"
                        fi
                # different for SAS type
                  elif [[ ! -z "$resultb" ]]
                      then
                        ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
                        if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                        if [ "$ht" -gt 59 ]
                          then
                            result="Passed"
                            result2="Passed"
                        else
                          result2="Failed: Health"
                          result="Failed"
                        fi
                  else
                      result2="Failed: DST"
                      result="Failed"
                    fi
                else
                  ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
                  if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                  if [ "$ht" -gt 59 ]
                    then
                      result="Passed"
                      result2="Passed"
                  else
                      result2="Failed: Health SAS"
                      result="Failed"
                  fi
                fi
          else
              result2="Failed: Verify"
              result="Failed"
          fi

          echo "$ac result = $result and result2 = $result2"
          ##### testing end
          ######
          hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
          s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
          #verify through sg
          ttSAT=$(sudo smartctl -i "$dev7" | grep "SATA")
          ttSAS=$(sudo smartctl -i "$dev7" | grep "SAS")
          if [[ -z "$ttSAT" ]]; then if [[ ! -z "ttSAS" ]]; then t7="SAS"; else "NA"; fi; else t7="SATA"; fi
          echo "$t7"

          #rotation per minute
          rpm=$(sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}')
          rpm1=$(sudo smartctl -i "$dev7" | grep -i "solid")
          if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
          #manufacturer and model
          #manufacturer and model
          mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6,$7,$8,$9,$10,$11,$12,$13}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
          #send serial
          touch /home/clientshared/.Temp/."$ac"/.s.txt
          echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
          #send type
          echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
          #send capacity
          c7=$(sudo smartctl -i "$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
          echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
          echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
          echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
          echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
          if [[ "$result" == "Passed" ]] && [[ "$ht" -eq 100 ]]
            then result="Tested for Full Function R2/Ready for Reuse"
          elif [[ "$result" == "Passed" && "$ht" -lt 100 ]]
            then result="Tested for Key Function R2/Ready for Resale"
          else false
          fi
          echo "time to test: $count"
          echo "device: $dev7"

        else
          sleep 1

          # # BAYS SEARCH
          #24 Bay
          # dev7=$(cat /home/clientshared/.Temp/."$ac"/.dev.txt)
          # dev7=$(dev7="sd${dev7##*sd}")

          sleep 1
          ht=$(sudo /home/clientshared/.HD -solid -dev "$dev7" | awk '{print $3}')
          if [[ "$ht" == "?" ]] || [[ "$ht" == "" ]]; then ht=0; else false; fi
          echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
          echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
          result2="Failed: Wiping"
          result="Failed"
          hdsent=$(sudo /home/clientshared/.HD -dev "$dev7")
          s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
          #verify through sg
          ttSAT=$(sudo smartctl -i "$dev7" | grep "SATA")
          ttSAS=$(sudo smartctl -i "$dev7" | grep "SAS")
          if [[ -z "$ttSAT" ]]; then if [[ ! -z "ttSAS" ]]; then t7="SAS"; else "NA"; fi; else t7="SATA"; fi

          #rotation per minute
          rpm=$(sudo smartctl -i "$dev7" | grep -i "rotation" | awk '{print $3,$4}')
          rpm1=$(sudo smartctl -i "$dev7" | grep -i "solid")
          if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
          #manufacturer and model
          #manufacturer and model
          mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6,$7,$8,$9,$10,$11,$12,$13}'); manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}');
          #send serial
          touch /home/clientshared/.Temp/."$ac"/.s.txt
          echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
          #send type
          echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
          #send capacity
          c7=$(sudo smartctl -i "$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
          echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
          echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
          echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
        fi
        dte=$(date "+%Y-%m-%d")
        cserial=$(sudo dmidecode -t system | grep Serial | awk '{print $3}')
    if [[ -z "$ch" ]]; then ch="N"; else true; fi
    me=$(whoami)
    size1=$(sudo smartctl -i "$dev7" | grep "Form Factor:" | awk '{print $3}')

    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt
    #location="jasperprogram.TIS_JBOD"
    echo "'TIS', 'Wiping', '$result', '$ch', '$s7', '$manuf', '$mdl', '$c7', '$t7', '$size1', '$rpm', '$dte', '$me', '$compnum', '$cserial', 'Jasper Wiping v2.1', 'NIST-800-88 rev1: Clear: Overwrite Method', '$result2', '$te', '$htx', '$ht', '$p'" > /home/clientshared/.Temp/."$ac"/result.txt
    # location="jasperprogram.TIS"
  else
    echo "No device shown"
    #is no device
    touch /home/clientshared/.Temp/."$ac"/.p.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

    touch /home/clientshared/.Temp/."$ac"/.te.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

    touch /home/clientshared/.Temp/."$ac"/.tr.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

    touch /home/clientshared/.Temp/."$ac"/.etf.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

    touch /home/clientshared/.Temp/."$ac"/.prg.txt
    echo "No Device" > /home/clientshared/.Temp/."$ac"/.prg.txt

    touch /home/clientshared/.Temp/."$ac"/.c.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.c.txt

    touch /home/clientshared/.Temp/."$ac"/.tc.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tc.txt

    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt

    touch /home/clientshared/.Temp/."$ac"/.s.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.s.txt

    touch /home/clientshared/.Temp/."$ac"/.dev.txt
    echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt
  fi
fi
echo "Process $ac done at $p percent" && exit

"""

sending_info = """#!/bin/bash
employee=$1
answer=$2

if [[ "$answer" == "Y" ]]
then
    j1=$3
    j2=$4
    j3=$5
    j4=$6
    echo "$j1" > /home/clientshared/.Temp/.B01/job.txt
    echo "$j2" > /home/clientshared/.Temp/.B02/job.txt
    echo "$j3" > /home/clientshared/.Temp/.B03/job.txt
    echo "$j4" > /home/clientshared/.Temp/.B04/job.txt
    for i in {1..4};
    do
    result=$(cat /home/clientshared/.Temp/.B0"$i"/result.txt)
    job=$(cat /home/clientshared/.Temp/.B0"$i"/job.txt)
    running=$(mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into jasperprogram.TIS_Desktop (clients, process, result, charge, serial_number, manufacturer, model, capacity, type_drive, size, RPM, date_wiped, system_name, sub_system_name, system_serial, software_version, compliance, sub_result, time_lapsed, health_init, health_final, perc_done, employee, job_number) values ($(echo "$result"), '$employee', '$job')")
    echo "$job"
    done
else
    job=$3
    for i in {1..4};
    do
    result=$(cat /home/clientshared/.Temp/.B0"$i"/result.txt)
    running=$(mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into jasperprogram.TIS_Desktop (clients, process, result, charge, serial_number, manufacturer, model, capacity, type_drive, size, RPM, date_wiped, system_name, sub_system_name, system_serial, software_version, compliance, sub_result, time_lapsed, health_init, health_final, perc_done, employee, job_number) values ($(echo "$result"), '$employee', '$job')")
    done
fi
"""


if __name__ == "__main__":
    main = main_window()
    Gtk.main()

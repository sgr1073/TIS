#!/usr/bin/env python3
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import sys
import subprocess
import threading
from gi.repository import GObject
from gi.repository import GLib
import time
from gi.repository import Gdk
from time import sleep
import os
import base64
import sendgrid
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)
import datetime
import pandas as pd
from datetime import datetime as dt
from requests import get

for loc in range(1,5):
    subprocess.check_output(['echo "" > /home/clientshared/cp210x/USB{}/serial'.format(loc)], stderr=None, shell=True)
    subprocess.check_output(['echo "" > /home/clientshared/cp210x/USB{}/result'.format(loc)], stderr=None, shell=True)

class Email():
    def send_email(self,a,b,c,j):
        #a is start date, b is end date, c is email if empty send standard incoming, jn is job number if has value do with job
        df = pd.read_csv(r"/home/clientshared/Desktop/.Wiping_Report.txt", header=0, index_col=False)
        if a != "" and b != "":
            df['Date'] = pd.to_datetime(df['Date'])
            start_date = a
            print(a)
            end_date = b
            print(b)
            mask = (df['Date'] > start_date) & (df['Date'] <= end_date)
            df = df.loc[mask]
            df['Date'] = pd.to_datetime(df['Date']).dt.date
            t = df.to_excel("/home/clientshared/Downloads/.Wiping_Report.xlsx", index=False)
            ch = sum(df.Charge == "yes")
            total = len(df.index)
            print("The charge is {}".format(a))
            if c == "":
                to_emails = [
                ('reina.santiago.g@gmail.com', 'Santiago Reina'),
                ('jprice@priceconsultants.us', 'Jason Price')
                ]
                message = Mail(
                    from_email='acetest@tworiversitad.com',
                    to_emails=to_emails,
                    subject='Testing Sample Email',
                    html_content='<p>Sam,</p><p>Please create an invoice for ${}. The total billable wipes were {} from dates {} to {}.</p> <p>All the drive information for the date range is attached in Excel format.</p><p>Thank you,\n </p><p>-Santiago</p>'.format(ch,ch,a,b))
            else:
                a = a.strptime("%m/%d/%Y")
                # start = datetime.datetime.strptime(a,"%Y/%m/%d")
                # start = start.date()
                b = b.strptime("%m/%d/%Y")
                to_emails = [
                ('{}'.format(c))
                    #('jprice@priceconsultants.us', 'Jason Price')
                ]
                passed = sum(df["Sub-Result"] == "Passed")
                failed = sum(df["Result"] == "Failed")
                ch = sum(df.Charge == "yes")
                total = len(df.index)
                message = Mail(
                    from_email='acetest@tworiversitad.com',
                    to_emails=to_emails,
                    subject='Testing Sample Email',
                    html_content='<p>TIS,</p><p>The total attempts to wipe from dates {} to {} was {}.</p><p>A total of {} of drives passed wiping.</p><p>A total of {} failed wiping<p>A total of {} drives were charged from wiping.<p>Please see the attached excel file.</p><p>Thank you,</p><p>TIS</p>'.format(a,b,total,passed,failed,ch))
        else:
            df['Job Number'] = df['Job Number'].apply(str)
            df = df.loc[df['Job Number'] == "{}".format(j)]
            t = df.to_excel("/home/clientshared/Downloads/.Wiping_Report.xlsx", index=False)
            passed = sum(df["Sub-Result"] == "Passed")
            failed = sum(df["Result"] == "Failed")
            ch = sum(df.Charge == "yes")
            total = len(df.index)
            to_emails = [
            ('{}'.format(c))
            ]
            message = Mail(
                from_email='acetest@tworiversitad.com',
                to_emails=to_emails,
                subject='Testing Sample Email',
                html_content='<p>TIS,</p><p>The total attempts to wipe for the job {} were {}.<p>A total of {} drives passed wiping.</p><p>A total of {} failed wiping<p>A total of {} drives were charged from wiping.<p>Please see the attached excel file.</p><p>Thank you,</p><p>TIS</p>'.format(j,total,passed,failed,ch))

        data = open("/home/clientshared/Downloads/.Wiping_Report.xlsx",'rb').read()
        encoded_file = base64.b64encode(data).decode('UTF-8')

        attachedFile = Attachment(
            FileContent(encoded_file),
            FileName('Wiping Report.xlsx'),
            FileType('Excel'),
            Disposition('attachment')
        )
        message.attachment = attachedFile
        try:
            sg =SendGridAPIClient('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')
            response = sg.send(message)
            print(response.status_code)
            print(response.body)
            print(response.headers)
        except Exception as e:
            print(e.message)
        print("Message sent")

### End xml
b ="""#!/usr/bin/bash
st=$(date '+%H:%M:%S')
echo "Producing" > /home/clientshared/cp210x/USBnum/result
serial=""
echo "" > /home/clientshared/cp210x/USBnum/serial
echo "" > /home/clientshared/cp210x/USBnum/log.txt
echo "" > /home/clientshared/cp210x/USBnum/process
echo "#!/usr/bin/bash
rm /home/clientshared/cp210x/USBnum/subbashnum.sh
sudo nohup minicom USBnum -S /home/clientshared/cp210x/USBnum/script.txt -C /home/clientshared/cp210x/USBnum/log.txt -o
echo 'Done' > /home/clientshared/cp210x/USBnum/process
exit
" > /home/clientshared/cp210x/USBnum/subbashnum.sh
echo 'send "^Z"
sleep 2
send "/TJ"
expect {
	"FF FF FF FF FF FF FF FF FF FF FF FF" goto labelp
	timeout 5 goto labela
}

labela:
        sleep 2
        ! echo "Done" > /home/clientshared/cp210x/USBnum/process; killall subbashnum.sh
        exit

labelp:
	sleep 5
	send "m0,6,2,,,,,22"
	sleep 1
	expect {
	  "Successful" goto labelb
	  "F3 T>" goto label a
	}

labelb:
	send "/AP"
	expect {
	"done" goto labelc
}

labelc:
	send "^Z"
	send "^Z"
	sleep 1
	send "m0,6,2,,,,,22"
	sleep 1
    send "^Z"
	expect {
	  "F3 T>" goto labela
	}
exit
' > /home/clientshared/cp210x/USBnum/script.txt
chmod 777 /home/clientshared/cp210x/USBnum/subbashnum.sh
/home/clientshared/cp210x/USBnum/subbashnum.sh
process=$(cat /home/clientshared/cp210x/USBnum/process)
while [[ -z "$process" ]]
do
sleep 1s
process=$(cat /home/clientshared/cp210x/USBnum/process)
done
a=$(cat /home/clientshared/cp210x/USBnum/log.txt)
serial=$(echo "$a" | grep "HDA" | awk '{print $5}')
ip_address=$(wget -qO- http://ipecho.net/plain | xargs echo)
dte=$(date "+%Y-%m-%d")
if [[ -z "$serial" ]];
    then result="FAILED"
    else
        a=$(cat /home/clientshared/cp210x/USBnum/log.txt)
        b=$(echo "$a" | egrep "done|Successful" | wc -l)
        serial=$(echo "$a" | grep "HDA" | awk '{print $5}')
        echo "" > /home/clientshared/cp210x/USBnum/log.txt
        echo "" > /home/clientshared/cp210x/USBnum/script.txt
        if [[ -z "$b" ]]; then b=1; else b="$b"; fi
        if [[ "$b" -eq 3 ]];
            then result="PASSED"
            else result="FAILED"
        fi
        # if [[ "$result" == "PASSED" ]]
        #     then
                running=$(mysql -u TIS -pJasper2010! -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into jasperprogram.producing (ip_address, serial, result, time, date) values ('$ip_address', '$serial', '$result', '$st', '$dte')")
        #     else false
        # fi
    fi
echo "num $result"
echo "$result" > /home/clientshared/cp210x/USBnum/result
echo "$serial" > /home/clientshared/cp210x/USBnum/serial
exit
"""
#####BASH END
class main_window():
    #initi main window class
    def __init__(self):

        global web
        web = int(0)
        self.gladefile = "/home/clientshared/cp210x/main.glade"

        self.builder = Gtk.Builder()
        self.builder.add_from_file(self.gladefile)
        #main window
        self.main_window = self.builder.get_object("window1")
        self.builder.connect_signals(self)

        #label 1
        self.B1 = self.builder.get_object("B1")
        self.s1 = self.builder.get_object("s1")
        self.prg1 = self.builder.get_object("prg1")

        self.B2 = self.builder.get_object("B2")
        self.s2 = self.builder.get_object("s2")
        self.prg2 = self.builder.get_object("prg2")

        self.B3 = self.builder.get_object("B3")
        self.s3 = self.builder.get_object("s3")
        self.prg3 = self.builder.get_object("prg3")

        self.B4 = self.builder.get_object("B4")
        self.s4 = self.builder.get_object("s4")
        self.prg4 = self.builder.get_object("prg4")

        self.main_window.show()
        thread = threading.Thread(target=self.update)
        thread.daemon = True
        thread.start()

        #GLib.timeout_add_seconds(1,self.threaded)
#onjn
    def on_window1_destroy(self, object, data=None):
        t = """pkill .USB0.sh
pkill .USB1.sh
pkill .USB2.sh
pkill .USB3.sh
"""
        wf = open("/home/clientshared/cp210x/.killall.sh","w")
        wf1 = wf.write(t)
        wf2 = wf.close()
        os.chmod("/home/clientshared/cp210x/.killall.sh",509)
        a = subprocess.Popen(["/home/clientshared/cp210x/.killall.sh"], shell=True)
        time.sleep(.2)
        file = os.remove("/home/clientshared/cp210x/.killall.sh")
        Gtk.main_quit()
        sys.exit()

    def on_B1_clicked(self, object, data=None):
        wf = open("/home/clientshared/cp210x/USB0/.USB0.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        wf = open("/home/clientshared/cp210x/USB0/.USB0.sh","r")
        wf1 = wf.read()
        wf.close()
        newdata = wf1.replace("num","0")
        wf = open("/home/clientshared/cp210x/USB0/.USB0.sh","w")
        wf1 = wf.write(newdata)
        wf2 = wf.close()
        os.chmod("/home/clientshared/cp210x/USB0/.USB0.sh",509)
        # a = subprocess.Popen(['gnome-terminal','-x','/home/clientshared/cp210x/USB0/.USB0.sh','&','disown','&','exit'])
        a = subprocess.Popen(["/home/clientshared/cp210x/USB0/.USB0.sh"])
        time.sleep(.05)
        # wf = os.remove("/home/clientshared/cp210x/USB0/.USB0.sh")
        print("Process 1 started in background")
        wf = os.remove("/home/clientshared/cp210x/USB0/.USB0.sh")

    def on_B2_clicked(self, object, data=None):
        wf = open("/home/clientshared/cp210x/USB1/.USB1.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        wf = open("/home/clientshared/cp210x/USB1/.USB1.sh","r")
        wf1 = wf.read()
        wf.close()
        newdata = wf1.replace("num","1")
        wf = open("/home/clientshared/cp210x/USB1/.USB1.sh","w")
        wf1 = wf.write(newdata)
        wf2 = wf.close()
        os.chmod("/home/clientshared/cp210x/USB1/.USB1.sh",509)
        # a = subprocess.Popen(['gnome-terminal','-x','/home/clientshared/cp210x/USB0/.USB0.sh','&','disown','&','exit'])
        a = subprocess.Popen(["/home/clientshared/cp210x/USB1/.USB1.sh"])
        time.sleep(.05)
        # wf = os.remove("/home/clientshared/cp210x/USB0/.USB0.sh")
        print("Process 2 started in background")
        wf = os.remove("/home/clientshared/cp210x/USB1/.USB1.sh")

    def on_B3_clicked(self, object, data=None):
        wf = open("/home/clientshared/cp210x/USB2/.USB2.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        wf = open("/home/clientshared/cp210x/USB2/.USB2.sh","r")
        wf1 = wf.read()
        wf.close()
        newdata = wf1.replace("num","2")
        wf = open("/home/clientshared/cp210x/USB2/.USB2.sh","w")
        wf1 = wf.write(newdata)
        wf2 = wf.close()
        os.chmod("/home/clientshared/cp210x/USB2/.USB2.sh",509)
        # a = subprocess.Popen(['gnome-terminal','-x','/home/clientshared/cp210x/USB0/.USB0.sh','&','disown','&','exit'])
        a = subprocess.Popen(["/home/clientshared/cp210x/USB2/.USB2.sh"])
        time.sleep(.05)
        # wf = os.remove("/home/clientshared/cp210x/USB0/.USB0.sh")
        print("Process 3 started in background")
        wf = os.remove("/home/clientshared/cp210x/USB2/.USB2.sh")

    def on_B4_clicked(self, object, data=None):
        wf = open("/home/clientshared/cp210x/USB3/.USB3.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        wf = open("/home/clientshared/cp210x/USB3/.USB3.sh","r")
        wf1 = wf.read()
        wf.close()
        newdata = wf1.replace("num","3")
        wf = open("/home/clientshared/cp210x/USB3/.USB3.sh","w")
        wf1 = wf.write(newdata)
        wf2 = wf.close()
        os.chmod("/home/clientshared/cp210x/USB3/.USB3.sh",509)
        # a = subprocess.Popen(['gnome-terminal','-x','/home/clientshared/cp210x/USB0/.USB0.sh','&','disown','&','exit'])
        a = subprocess.Popen(["/home/clientshared/cp210x/USB3/.USB3.sh"])
        time.sleep(.05)
        # wf = os.remove("/home/clientshared/cp210x/USB0/.USB0.sh")
        print("Process 4 started in background")
        wf = os.remove("/home/clientshared/cp210x/USB3/.USB3.sh")

    def update_label(self):

        ###Labels
        ####Label 1
        #s1
        s1 = open("/home/clientshared/cp210x/USB0/serial").read().strip()
        self.s1.set_text(s1)
        #prog1
        prg1 = open("/home/clientshared/cp210x/USB0/result").read().strip()
        self.prg1.set_text(prg1)

        if prg1 == "PASSED":
            self.prg1.set_markup('<span foreground="green"> {} </span>'.format(prg1))

        elif prg1 == "FAILED" or prg1 == "Failed: Wiping":
            self.prg1.set_markup('<span foreground="red"> {} </span>'.format(prg1))

        ####Label 2
        #s2
        s2 = open("/home/clientshared/cp210x/USB1/serial").read().strip()
        self.s2.set_text(s2)
        #prog2
        prg2 = open("/home/clientshared/cp210x/USB1/result").read().strip()
        self.prg2.set_text(prg2)

        if prg2 == "PASSED":
            self.prg2.set_markup('<span foreground="green"> {} </span>'.format(prg2))

        elif prg2 == "FAILED" or prg2 == "FAILED: Wiping":
            self.prg2.set_markup('<span foreground="red"> {} </span>'.format(prg2))

        ####Label 3
        #s3
        s3 = open("/home/clientshared/cp210x/USB2/serial").read().strip()
        self.s3.set_text(s3)
        #prog3
        prg3 = open("/home/clientshared/cp210x/USB2/result").read().strip()
        self.prg3.set_text(prg3)

        if prg3 == "PASSED":
            self.prg3.set_markup('<span foreground="green"> {} </span>'.format(prg3))

        elif prg3 == "FAILED" or prg3 == "FAILED: Wiping":
            self.prg3.set_markup('<span foreground="red"> {} </span>'.format(prg3))

        ####Label 4
        #s4
        s4 = open("/home/clientshared/cp210x/USB3/serial").read().strip()
        self.s4.set_text(s4)
        #prog4
        prg4 = open("/home/clientshared/cp210x/USB3/result").read().strip()
        self.prg4.set_text(prg4)

        if prg4 == "PASSED":
            self.prg4.set_markup('<span foreground="green"> {} </span>'.format(prg4))

        elif prg4 == "FAILED" or prg4 == "FAILED: Wiping":
            self.prg4.set_markup('<span foreground="red"> {} </span>'.format(prg4))

        return False

    def update(self):
        while True:
            GLib.idle_add(self.update_label)
            time.sleep(1)


print('version 1.01')

if __name__ == "__main__":
    main = main_window()
    Gtk.main()

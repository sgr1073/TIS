#!/usr/bin/env python3
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import sys
import subprocess
import threading
from gi.repository import GObject
from gi.repository import GLib
import time
from gi.repository import Gdk
from gi.repository import Pango
from time import sleep
import os
import base64
import datetime
import pandas as pd
from datetime import datetime as dt
import requests
from requests import get
import postmarker
import email
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import formatdate
from email import encoders
import sendgrid
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)
from postmarker.core import PostmarkClient

# ipt = "96.77.99.254" #TIS
# ipt1 = "38.88.190.26"
# ipt2 = "97.104.99.49" #Here
# # ipt = "70.62.107.226" #synergy
# ip = get('https://api.ipify.org').content.decode('utf8')
# print (ip)
# if ip == "97.100.109.182":
# if ip == "96.77.99.254":
# if ip == ipt or ip == ipt1 or ip == ipt2:
#     True
# else:
#     sys.exit()

class Email():
    def send_email(self,a, b, c, j):
        # The thing is start date, b is end date, c is email if empty send standard incoming, The jn is job number then has
        # value do with job
        em = """#!/bin/bash
        touch /home/clientshared/.report.tsv
        echo -e "Client\tProcess\tResult\tCharge\tSerial Number\tManufacturer\tModel\tCapacity\tDrive Type\tSize\tRPM\tDate Wiped\tJob Number\tEmployee\tSystem Name\tSubsystem Name\tSystem Serial Number\tSoftware Version\tCompliance\tSub Result\tTime Elapsed\tInitial Health\tFinal Health\tPercent Done" > /home/clientshared/report.tsv
        """
        wf = open("/home/clientshared/.report.sh", "w")
        wf1 = wf.write(em)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.report.sh", 509)
        wf3 = subprocess.check_output(["/home/clientshared/.report.sh"], stderr=None, shell=True)
        time.sleep(.05)
        os.remove("/home/clientshared/.report.sh")
        subprocess.check_output(["mysql -u stream_client -pvh%G3/DmjM+8.Xk -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se 'select * from stream_client.wiping' >> /home/clientshared/report.tsv"], stderr=None, shell=True)
        df = pd.read_csv(r"/home/clientshared/report.tsv", header=0, index_col=False, sep='\t')
        print("ATTTTEEEENNN {} to {}".format(a, b))
        if a != "" and b != "":
            # df['Date Wiped'] = pd.to_datetime(df['Date Wiped'])
            start_date = a
            print(a)
            end_date = b
            print(b)
            mask = (df['Date Wiped'] > start_date) & (df['Date Wiped'] <= end_date)
            df = df.loc[mask]
            # df['Date Wiped'] = pd.to_datetime(df['Date Wiped']).dt.date
            t = df.to_excel("/home/clientshared/.Report.xlsx", index=False)
            ch = sum(df.Charge == "Y")
            total = len(df.index)
            print("The charge is {}".format(ch))
            if c == "":
                to_emails = 'sreina@jasperwiping.com'
                subject = 'Charge Report TIS from {} to {}'.format(a,b)
                html_content = 'Jasper Program,\n\nPlease create an invoice for ${}. The total billable wipes were {} from dates {} to {}.\n \nAll the drive information for the date range is attached in Excel format.\n\nThank you,\n \n\n-Santiago\n'.format(ch, ch, a, b)
            else:
                passed = sum(df["Sub Result"] == "Passed")
                failed = sum(df["Result"] == "Failed")
                ch = sum(df.Charge == "Y")
                total = len(df.index)
                to_emails='{}'.format(c)
                subject='Wiping Report TIS from {} to {}'.format(a,b)
                html_content='TIS,\n\nThe total attempts to wipe from dates {} to {} was {}.\n\nA total of {} of drives passed wiping.\n\nA total of {} failed wiping\nA total of {} drives were charged from wiping.\nPlease see the attached excel file.\n\nThank you,\n\nTIS\n'.format(a, b, total, passed, failed, ch)
        else:
            df['Job Number'] = df['Job Number'].apply(str)
            df = df.loc[df['Job Number'] == "{}".format(j)]
            t = df.to_excel("/home/clientshared/.Report.xlsx", index=False)
            passed = sum(df["Sub Result"] == "Passed")
            failed = sum(df["Result"] == "Failed")
            ch = sum(df.Charge == "Y")
            total = len(df.index)
            to_emails='{}'.format(c)
            subject='Wiping Report for Job {}'.format(j)
            html_content='\nTIS,\n\nThe total attempts to wipe for the job {} were {}.\nA total of {} drives passed wiping.\n\nA total of {} failed wiping\nA total of {} drives were charged from wiping.\nPlease see the attached excel file.\n\nThank you,\n\nTIS\n'.format(j, total, passed, failed, ch)

        msg = MIMEMultipart()

        msg['From'] = 'reports@jasperwiping.com'
        msg['To'] = to_emails
        msg['Subject'] = subject

        msg.attach(MIMEText(html_content, 'plain'))

        filename = "Reports.xlsx"
        attachment = open("/home/clientshared/.Report.xlsx", 'rb')

        part = MIMEBase('application', 'octet-stream')
        part.set_payload((attachment).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

        msg.attach(part)

        api_key = subprocess.check_output(["echo $PMAK"], stderr=None, shell=True).decode("utf-8").strip()

        postmark = PostmarkClient(server_token='{}'.format(api_key))
        postmark.emails.send(msg)

class main_window():
	#initi main window class
    def __init__(self):

        self.gladefile = "/home/clientshared/45.glade"

        self.builder = Gtk.Builder()
        self.builder.add_from_file(self.gladefile)

        #main window
        self.main_window = self.builder.get_object("window1")
        self.close_button = self.builder.get_object("close_button")
        #main window
        self.popover = self.builder.get_object("popover")
        self.poplabel = self.builder.get_object("poplabel")

        cssProvider = Gtk.CssProvider()
        cssProvider.load_from_path('/home/clientshared/another.css')
        screen = Gdk.Screen.get_default()
        styleContext = Gtk.StyleContext()
        styleContext.add_provider_for_screen(screen, cssProvider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        ###Mwnu
        self.main_menu = self.builder.get_object("main_menu")
        self.Change = self.builder.get_object("Change")
        self.Jnumber = self.builder.get_object("Jnumber")
        self.Employee = self.builder.get_object("Employee")
        ### change jn
        self.change_jn_window = self.builder.get_object("change_jn_window")
        self.enjn = self.builder.get_object("e_n_jn")
        self.ecnjn = self.builder.get_object("e_cn_jn")
        self.tjn = self.builder.get_object("tjn")
        self.errjn = self.builder.get_object("err_jn")
        ##change_e_window
        self.change_e_window = self.builder.get_object("change_e_window")
        self.ene = self.builder.get_object("ene")
        self.ecne = self.builder.get_object("ecne")
        self.texte = self.builder.get_object("te")
        self.erre = self.builder.get_object("erre")
        # start loop
        ##Btab
        self.BB2 = self.builder.get_object("BB2")
        ### report window
        self.report_window = self.builder.get_object("run_report")
        self.report_window = self.builder.get_object("report_window")
        self.report_stack = self.builder.get_object("report_stack")
        ## sub report dates
        self.sd_box = self.builder.get_object("sd_box")
        self.ed_box = self.builder.get_object("ed_box")
        self.report_cancel = self.builder.get_object("report_cancel")
        self.sd_tog = self.builder.get_object("sd_tog")
        self.ed_tog = self.builder.get_object("ed_tog")
        self.sdtl = self.builder.get_object("sd_label")
        self.edtl = self.builder.get_object("ed_label")
        self.rd_email = self.builder.get_object("rd_email")
        self.rdc_email = self.builder.get_object("rdc_email")
        #
        self.rd_email.set_text("bmartinolich@tworiversrecovery.com")
        self.rdc_email.set_text("bmartinolich@tworiversrecovery.com")
        #
        self.repe = self.builder.get_object("repe")
        self.repec = self.builder.get_object("repec")
        self.sd_calendar = self.builder.get_object("sd_calendar")
        self.ed_calendar = self.builder.get_object("ed_calendar")
        self.error_dates = self.builder.get_object("error_dates")
        ## sub report job number
        self.jnr = self.builder.get_object("jnr")
        self.cjnr = self.builder.get_object("cjnr")
        self.jner = self.builder.get_object("jner")
        self.jncer = self.builder.get_object("jncer")
        #
        self.jner.set_text("bmartinolich@tworiversrecovery.com")
        self.jncer.set_text("bmartinolich@tworiversrecovery.com")
        #
        self.r_jn_err = self.builder.get_object("r_jn_err")
        self.r_jne_err = self.builder.get_object("r_jne_err")
        ### report windo
        self.internet = self.builder.get_object("internet")
        ####
        self.job_scrap = self.builder.get_object("job_scrap")
        self.r_SATA = self.builder.get_object("r_SATA")
        self.r_SAS = self.builder.get_object("r_SAS")
        self.r_SSD = self.builder.get_object("r_SSD")
        # self.r_25 = self.builder.get_object("r_25")
        # self.r_35 = self.builder.get_object("r_35")
        self.cap_e_scrap = self.builder.get_object("cap_e_scrap")
        self.serial_e_scrap = self.builder.get_object("serial_e_scrap")
        self.tree_view = self.builder.get_object("tree_view")
        self.ch_jn_scrap = self.builder.get_object("ch_jn_scrap")
        self.liststore1 = self.builder.get_object("liststore1")
        self.scrap = self.builder.get_object("scrap")
        self.scrap_add = self.builder.get_object("scrap_add")
        self.scrap_cancel = self.builder.get_object("scrap_cancel")
        self.cap_e_scrap = self.builder.get_object("cap_e_scrap")
        self.serial_e_scrap = self.builder.get_object("serial_e_scrap")
        self.liststore1 = self.builder.get_object("liststore1")
        self.remove_scrap = self.builder.get_object("remove_scrap")
        self.job_scrap = self.builder.get_object("job_scrap")
        ####
        #set the JN
        tee = open("/home/clientshared/.General/.employee").read().strip()
        self.texte.set_text(tee)
        tjne = open("/home/clientshared/.General/.job_number").read().strip()
        self.tjn.set_text(tjne)

        self.SA = self.builder.get_object("SA")
        beast = getattr(main_window, "on_SA_clicked")
        self.SA.connect("clicked", beast)

        for i in range(1,46):
            #EVENTS
            events = 'events{}'.format(i)
            self.events = self.builder.get_object("events{}".format(i))
            #
            setattr(main_window, "on_events{}_enter_notify_event".format(i), self.enters(self,i))
            setattr(main_window, "on_events{}_leave_notify_event".format(i), self.leaves(self,i))
            #
            bevent1 = getattr(main_window, "on_events{}_enter_notify_event".format(i))
            bevent2 = getattr(main_window, "on_events{}_leave_notify_event".format(i))
            self.events.connect("enter-notify-event", bevent1)
            self.events.connect("leave-notify-event", bevent2)
            self.builder.connect_signals(self)
            #button
            B = 'B"{}"'.format(i)
            self.B = self.builder.get_object("B{}".format(i))
            beast = "on_B{}_clicked".format(i)
            beast = getattr(main_window, "on_B{}_clicked".format(i))
            self.B.connect("clicked", beast)
            # self.builder.get_object("{}1").connect("clicked",self.on_B1_clicked)
            self.builder.connect_signals(self)
            #button top
            BB = 'BB"{}"'.format(i)
            self.BB = self.builder.get_object("BB{}".format(i))
            #top button style initial
            self.BB_style = self.BB.get_style_context()
            self.BB_style.add_class('treg')
            #top button connetion
            B = 'B"{}"'.format(i)
            self.BB = self.builder.get_object("BB{}".format(i))
            beast = "on_B{}_clicked".format(i)
            beast = getattr(main_window, "on_B{}_clicked".format(i))
            self.BB.connect("clicked", beast)
            # self.builder.get_object("{}1").connect("clicked",self.on_B1_clicked)
            self.builder.connect_signals(self)

            #prg
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            self.prg.set_text("")
            #prg style
            self.prg_style = self.prg.get_style_context()
            self.prg_style.remove_class('wiping')
            self.prg_style.add_class('invisible')

            #per
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            self.p.set_text("")
            #per

            #per
            s = 's"{}"'.format(i)
            self.s = self.builder.get_object("s{}".format(i))
            #set ellipsis must get Pango
            self.s.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
            self.s.set_max_width_chars(18)
            # self.s.set_text("Serial Number Here")
            self.s_style = self.s.get_style_context()
            self.s_style.remove_class('bottom')
            self.s_style.add_class('bottoms')
            #tc
            tc = 'tc"{}"'.format(i)
            self.tc = self.builder.get_object("tc{}".format(i))
            self.tc.set_text("")
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            self.te.set_text("")
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            self.tr.set_text("")
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            self.etf.set_text("")
            #trB
            trB = 'trB"{}"'.format(i)
            self.trB = self.builder.get_object("trB{}".format(i))
            self.trB.set_text("")
            #number trB length
            trB = 'trB"{}"'.format(i)
            self.trB = self.builder.get_object("trB{}".format(i))
            self.trB.set_width_chars(6)

        #remove files
        file = os.remove("/home/clientshared/Bay45.py")
        file = os.remove("/home/clientshared/45.glade")
        file = os.remove("/home/clientshared/another.css")

        self.main_window.show()

        thread = threading.Thread(target=self.update)
        thread.daemon = True
        thread.start()

    def on_window1_destroy(self, object, data=None):
        print("quit with cancel")
        Gtk.main_quit()

    def enters(self,x,z):
        def on_eventsz_enter_notify_event(x,object, data=None):
            self.poplabel = self.builder.get_object("poplabel")
            self.popover = self.builder.get_object("popover")
            events = 'events"{}"'.format(z)
            self.events = self.builder.get_object("events{}".format(z))
            self.popover.set_relative_to(self.events)
            if z < 10:
                s = open('/home/clientshared/.Temp/.B0{}/.s.txt'.format(z)).read().strip()
            else:
                s = open('/home/clientshared/.Temp/.B{}/.s.txt'.format(z)).read().strip()
            self.poplabel.set_text(s)
            self.popover.show()
        return on_eventsz_enter_notify_event

    def leaves(self,x,z):
        def on_eventsz_leave_notify_event(x, object, data=None):
            self.popover.hide()
        return on_eventsz_leave_notify_event

    def on_close_button_activate(self, object, data=None):
        print("quit with cancel")
        Gtk.main_quit()

    ###on add Scrap
    def on_add_drives_activate(self, object, data=None):
        a = self.tjn.get_text()
        self.job_scrap.set_text(a)
        self.scrap.run()

    def on_scrap_cancel_clicked(self, object, data=None):
        self.liststore1.clear()
        self.scrap.hide()

    def on_scrap_add_clicked(self, object, data=None):
        jn = self.tjn.get_text()
        e = self.texte.get_text()
        date = datetime.date.today().strftime("%m/%d/%y")
        # comp serial
        stream = os.popen("""sudo dmidecode -t system | grep Serial | awk '{print $3}'""")
        output = stream.read()
        syssn = output.replace("\n", "")
        cats = list()
        item = self.liststore1.get_iter_first()
        while (item != None):
            cats.append(["no", self.liststore1.get_value(item, 0), self.liststore1.get_value(item, 1), "NA", "NA",
                         self.liststore1.get_value(item, 2), "NA", "{}".format(e), "{}".format(jn), "{}".format(date),
                         "NA", "Jasper Wiping v2.1", "{}".format(syssn), "NA", "NA", "NA", "NA", "NA"])
            item = self.liststore1.iter_next(item)
        # print(cats)
        # df = pd.DataFrame(cats,columns=['Type','Capacity','Serial Number'])
        # print(df)
        a = ""
        for i in cats:
            a = a + "\n{}".format(i)
        print(a)
        a = a.replace("'", "")
        a = a.replace("[", "")
        a = a.replace("]", "")
        a = a.replace(" ", "")
        print(a)
        ###here
        with open("/home/jasper2/Desktop/.Wiping_Report.txt", "a") as f:
            f.write(a)
            f.close()
        self.liststore1.clear()
        self.scrap.hide()

    def on_remove_scrap_clicked(self, object, data=None):
        self.liststore1.remove(self.select)

    def on_serial_e_scrap_activate(self, object, data=None):
        cap = self.cap_e_scrap.get_text()
        cap = "{} GB".format(cap)
        serial = self.serial_e_scrap.get_text()
        serial = serial.replace(".", "")
        if self.r_SATA.get_active():
            type = "SATA"
        if self.r_SAS.get_active():
            type = "SAS"
        if self.r_SSD.get_active():
            type = "SSD"
        print(type, cap, serial)
        self.liststore1.append([type, cap, serial])
        self.serial_e_scrap.set_text("")

    def on_select_changed(self, user_data, data=None):
        selected = user_data.get_selected()[1]
        if selected:
            self.select = selected

    # on report
    def on_report_activate(self, object, data=None):
        sd = datetime.datetime.now()
        dm = int(sd.strftime("%m")) - 1
        dy = int(sd.strftime("%Y"))
        dd = int(sd.strftime("%d"))
        self.sd_calendar.select_month(dm, dy)
        self.sd_calendar.select_day(dd)
        self.ed_calendar.select_month(dm, dy)
        self.ed_calendar.select_day(dd)
        self.report_window.run()

    def on_report_cancel_clicked(self, object, data=None):
        self.report_window.hide()

    def on_report_send_clicked(self, object, data=None):
        type = self.report_stack.get_visible_child_name()
        if type == "Dates":
            email = self.rd_email.get_text()
            emailc = self.rdc_email.get_text()
            empty = self.error_dates.get_text()
            if empty == "" and email != "" and emailc != "" and email == emailc:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                start = start.strftime("%Y-%m-%d")
                end = end.strftime("%Y-%m-%d")
                print("they match now send")
                self.error_dates.set_text("")
                run = Email()
                run.send_email(start, end, email, "")
                self.report_window.hide()
            else:
                self.error_dates.set_text("Emails must match and not be empty")
        elif type == "Job_Number":
            print("Location is JN")
            job = self.jnr.get_text()
            cjob = self.cjnr.get_text()
            email = self.jner.get_text()
            cemail = self.jncer.get_text()
            if job == cjob and email == cemail and job != "" and email != "":
                print("sending through Job number")
                # send report using job Number
                run = Email()
                run.send_email("", "", email, job)
                self.report_window.hide()
            if job == "" or cjob == "":
                print("Job number cannot be empty")
                self.r_jn_err.set_text("Job Number Values Cannot Be Empty")
            if email == "" or cemail == "":
                print("Email Values cannot be empty")
                self.r_jne_err.set_text("Email Values Cannot Be Empty")
            if email != cemail:
                print("Job number doesn't match")
                self.r_jne_err.set_text("Email Values Do Not Match")
            if job != cjob:
                print("Job number cannot be empty")
                self.r_jn_err.set_text("Job Number Does Not Match")

    ######## dates for report
    def on_sd_tog_toggled(self, object, data=None):
        if self.sd_tog.get_active():
            self.error_dates.set_text("")
            self.repe.hide()
            self.repec.hide()
            self.rd_email.hide()
            self.rdc_email.hide()
            self.sd_box.show()
            self.sd_tog.hide()
            self.sdtl.set_label("Start Date")
            # self.sd_tog.set_active(False)
            # self.sd_tog.show()
        else:
            self.sd_box.hide()
            if self.ed_tog.get_active() == False:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                print(start)
                print(end)
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                if end >= start:
                    self.repe.show()
                    self.repec.show()
                    self.rd_email.show()
                    self.rdc_email.show()
                    self.error_dates.set_text("")
                else:
                    self.error_dates.set_text("End date must be the same or later than the start date")

    def on_ed_tog_toggled(self, object, data=None):
        if self.ed_tog.get_active():
            self.error_dates.set_text("")
            self.repe.hide()
            self.repec.hide()
            self.rd_email.hide()
            self.rdc_email.hide()
            self.ed_box.show()
            self.edtl.set_label("Start Date")
            self.ed_tog.hide()
        else:
            self.ed_box.hide()
            if self.sd_tog.get_active() == False:
                start = self.sdtl.get_text()
                end = self.edtl.get_text()
                start = dt.strptime(start, '%m/%d/%Y')
                end = dt.strptime(end, '%m/%d/%Y')
                if end >= start:
                    self.repe.show()
                    self.repec.show()
                    self.rd_email.show()
                    self.rdc_email.show()
                    self.error_dates.set_text("")
                else:
                    self.error_dates.set_text("End date must be the same or later than the start date")

    def on_sd_calendar_day_selected(self, object, data=None):
        a = self.sd_calendar.get_date()
        year = a[0]
        month = a[1]
        month = month + 1
        day = a[2]
        self.sdtl.set_label("{}/{}/{}".format(month, day, year))
        self.sd_tog.set_active(False)
        self.sd_tog.show()

    def on_ed_calendar_day_selected(self, object, data=None):
        a = self.ed_calendar.get_date()
        year = a[0]
        month = a[1]
        month = month + 1
        day = a[2]
        self.edtl.set_label("{}/{}/{}".format(month, day, year))
        self.ed_tog.set_active(False)
        self.ed_tog.show()

    # onjn
    def on_Jnumber_activate(self, object, data=None):
        print("J activated")
        self.change_jn_window.run()

    def on_ch_jn_scrap_clicked(self, object, data=None):
        print("J activated")
        self.change_jn_window.run()

    def on_close_jn_clicked(self, object, data=None):
        print("quit jn with cancel")
        self.errjn.set_text("")
        self.enjn.set_text("")
        self.ecnjn.set_text("")
        self.change_jn_window.hide()

    def on_ok_jn_clicked(self, object, data=None):
        njn = self.enjn.get_text()
        print(njn)
        cnjn = self.ecnjn.get_text()
        print(cnjn)
        print("hit ok and close")
        if njn == cnjn:
            self.tjn.set_text(njn)
            print("jn matched")
            self.errjn.set_text("")
            self.enjn.set_text("")
            self.ecnjn.set_text("")
            fe = open("/home/clientshared/.General/.job_number", "w")
            fe.write(njn)
            fe.close()
            self.change_jn_window.hide()
        else:
            self.errjn.set_text("Error: Job Number does not match")

    ##onem
    def on_e_activate(self, object, data=None):
        print("Employee activated")
        self.change_e_window.run()

    def on_close_e_clicked(self, object, data=None):
        print("quit e with cancel")
        self.erre.set_text("")
        self.ene.set_text("")
        self.ecne.set_text("")
        self.change_e_window.hide()

    def on_ok_e_clicked(self, object, data=None):
        ene = self.ene.get_text()
        print(ene)
        ecne = self.ecne.get_text()
        print(ecne)
        print("hit ok and close")
        if ene == ecne:
            self.texte.set_text(ene)
            print("e matched")
            self.erre.set_text("")
            self.ene.set_text("")
            self.ecne.set_text("")
            fe = open("/home/clientshared/.General/.ee=ee", "w")
            fe.write(ene)
            fe.close()
            self.change_e_window.hide()
        else:
            self.erre.set_text("Error:  name does not match")

    def on_SA_clicked(object, data=None):
        for i in range(1,46):
            B = 'B"{}"'.format(i)
            beast = "on_B{}_clicked".format(i)
            beast = getattr(main_window, "on_B{}_clicked".format(i))
            beast("clicked")

    def on_B1_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay1.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay1.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay1.sh","B01"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay1.sh")
        print("Process 1 started in background")

    def on_B2_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay2.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay2.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay2.sh","B02"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay2.sh")
        print("Process 2 started in background")

    def on_B3_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay3.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay3.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay3.sh","B03"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay3.sh")
        print("Process 3 started in background")

    def on_B4_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay4.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay4.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay4.sh","B04"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay4.sh")
        print("Process 4 started in background")

    def on_B5_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay5.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay5.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay5.sh","B05"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay5.sh")
        print("Process 5 started in background")

    def on_B6_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay6.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay6.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay6.sh","B06"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay6.sh")
        print("Process 6 started in background")

    def on_B7_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay7.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay7.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay7.sh","B07"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay7.sh")
        print("Process 7 started in background")

    def on_B8_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay8.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay8.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay8.sh","B08"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay8.sh")
        print("Process 8 started in background")

    def on_B9_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay9.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay9.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay9.sh","B09"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay9.sh")
        print("Process 8 started in background")

    def on_B10_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay10.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay10.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay10.sh","B10"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay10.sh")
        print("Process 10 started in background")

    def on_B11_clicked(object, data=None):
        wf = open("/home/clientshared/.Bay11.sh","w")
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod("/home/clientshared/.Bay11.sh",509)
        a = subprocess.Popen(["/home/clientshared/.Bay11.sh","B11"])
        time.sleep(.05)
        wf = os.remove("/home/clientshared/.Bay11.sh")
        print("Process 11 started in background")

    def on_B12_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay12.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay12.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay12.sh','B12'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay12.sh')
        print('Process 12 started in background')

    def on_B13_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay13.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay13.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay13.sh','B13'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay13.sh')
        print('Process 13 started in background')

    def on_B14_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay14.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay14.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay14.sh','B14'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay14.sh')
        print('Process 14 started in background')

    def on_B15_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay15.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay15.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay15.sh','B15'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay15.sh')
        print('Process 15 started in background')

    def on_B16_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay16.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay16.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay16.sh','B16'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay16.sh')
        print('Process 16 started in background')

    def on_B17_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay17.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay17.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay17.sh','B17'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay17.sh')
        print('Process 17 started in background')

    def on_B18_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay18.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay18.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay18.sh','B18'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay18.sh')
        print('Process 18 started in background')

    def on_B19_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay19.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay19.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay19.sh','B19'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay19.sh')
        print('Process 19 started in background')

    def on_B20_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay20.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay20.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay20.sh','B20'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay20.sh')
        print('Process 20 started in background')

    def on_B21_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay21.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay21.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay21.sh','B21'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay21.sh')
        print('Process 21 started in background')

    def on_B22_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay22.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay22.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay22.sh','B22'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay22.sh')
        print('Process 22 started in background')

    def on_B23_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay23.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay23.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay23.sh','B23'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay23.sh')
        print('Process 23 started in background')

    def on_B24_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay24.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay24.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay24.sh','B24'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay24.sh')
        print('Process 24 started in background')

    def on_B25_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay25.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay25.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay25.sh','B25'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay25.sh')
        print('Process 25 started in background')

    def on_B26_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay26.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay26.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay26.sh','B26'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay26.sh')
        print('Process 26 started in background')

    def on_B27_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay27.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay27.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay27.sh','B27'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay27.sh')
        print('Process 27 started in background')

    def on_B28_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay28.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay28.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay28.sh','B28'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay28.sh')
        print('Process 28 started in background')

    def on_B29_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay29.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay29.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay29.sh','B29'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay29.sh')
        print('Process 29 started in background')

    def on_B30_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay30.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay30.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay30.sh','B30'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay30.sh')
        print('Process 30 started in background')

    def on_B31_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay31.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay31.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay31.sh','B31'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay31.sh')
        print('Process 31 started in background')

    def on_B32_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay32.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay32.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay32.sh','B32'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay32.sh')
        print('Process 32 started in background')

    def on_B33_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay33.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay33.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay33.sh','B33'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay33.sh')
        print('Process 33 started in background')

    def on_B34_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay34.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay34.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay34.sh','B34'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay34.sh')
        print('Process 34 started in background')

    def on_B35_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay35.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay35.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay35.sh','B35'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay35.sh')
        print('Process 35 started in background')

    def on_B36_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay36.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay36.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay36.sh','B36'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay36.sh')
        print('Process 36 started in background')

    def on_B37_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay37.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay37.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay37.sh','B37'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay37.sh')
        print('Process 37 started in background')

    def on_B38_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay38.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay38.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay38.sh','B38'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay38.sh')
        print('Process 38 started in background')

    def on_B39_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay39.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay39.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay39.sh','B39'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay39.sh')
        print('Process 39 started in background')

    def on_B40_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay40.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay40.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay40.sh','B40'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay40.sh')
        print('Process 40 started in background')

    def on_B41_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay41.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay41.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay41.sh','B41'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay41.sh')
        print('Process 41 started in background')

    def on_B42_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay42.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay42.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay42.sh','B42'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay42.sh')
        print('Process 42 started in background')

    def on_B43_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay43.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay43.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay43.sh','B43'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay43.sh')
        print('Process 43 started in background')

    def on_B44_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay44.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay44.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay44.sh','B44'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay44.sh')
        print('Process 44 started in background')

    def on_B45_clicked(object, data=None):
        wf = open('/home/clientshared/.Bay45.sh','w')
        wf1 = wf.write(b)
        wf2 = wf.close()
        os.chmod('/home/clientshared/.Bay45.sh',509)
        a = subprocess.Popen(['/home/clientshared/.Bay45.sh','B45'])
        time.sleep(.05)
        wf = os.remove('/home/clientshared/.Bay45.sh')
        print('Process 45 started in background')

    def update_label(self):
        #full cycle:
        #####E and JN
        for i in range(1,46):
            #Bay overall
            if i < 10:
                t = "B0{}".format(i)
            else:
                t = "B{}".format(i)

            #progress
            prg = 'prg"{}"'.format(i)
            self.prg = self.builder.get_object("prg{}".format(i))
            prg = 'BB"{}"'.format(i)
            self.BB = self.builder.get_object("BB{}".format(i))
            prg = open('/home/clientshared/.Temp/.{}/.prg.txt'.format(t)).read().strip()
            #part 2
            prgx = self.prg.get_text()
            if prgx != prg:
                if prg == "Passed":
                    #normal tab
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Passed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('failed')
                    self.prg_style.add_class('passed')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('twiping')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tfailed')
                    self.BB_style.add_class('tpassed')

                elif prg == "Failed" or prg == "Failed: Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Failed")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('wiping')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('failed')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('twiping')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tpassed')
                    self.BB_style.add_class('tfailed')

                elif prg == "Wiping":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("Wiping")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('failed')
                    self.prg_style.remove_class('passed')
                    self.prg_style.add_class('wiping')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('tpassed')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tfailed')
                    self.BB_style.add_class('twiping')

                elif prg == "No Device":
                    self.prg = self.builder.get_object("prg{}".format(i))
                    self.prg.set_text("No Device")
                    self.prg_style = self.prg.get_style_context()
                    self.prg_style.remove_class('invisible')
                    self.prg_style.remove_class('treg')
                    self.prg_style.remove_class('failed')
                    self.prg_style.remove_class('passed')
                    self.prg_style.remove_class('wiping')
                    self.prg_style.add_class('treg')
                    #button tab
                    BB = 'BB"{}"'.format(i)
                    self.BB = self.builder.get_object("BB{}".format(i))
                    self.BB_style = self.BB.get_style_context()
                    self.BB_style.remove_class('invisible')
                    self.BB_style.remove_class('tpassed')
                    self.BB_style.remove_class('treg')
                    self.BB_style.remove_class('tfailed')
                    self.BB_style.remove_class('twiping')
                    self.BB_style.add_class('treg')
            #Type and Cap
            tc = 'tc"{}"'.format(i)
            self.tc = self.builder.get_object("tc{}".format(i))
            tc = open('/home/clientshared/.Temp/.{}/.tc.txt'.format(t)).read().strip()
            self.tc.set_text(tc)
            #Serial
            s = 's"{}"'.format(i)
            self.s = self.builder.get_object("s{}".format(i))
            s = open('/home/clientshared/.Temp/.{}/.s.txt'.format(t)).read().strip()
            self.s.set_text(s)
            #Perc
            p = 'p"{}"'.format(i)
            self.p = self.builder.get_object("p{}".format(i))
            p = open('/home/clientshared/.Temp/.{}/.p.txt'.format(t)).read().strip()
            self.p.set_text(p)
            #tr
            tr = 'tr"{}"'.format(i)
            self.tr = self.builder.get_object("tr{}".format(i))
            tr = open('/home/clientshared/.Temp/.{}/.tr.txt'.format(t)).read().strip()
            self.tr.set_text(tr)
            #trB3
            trB = 'trB"{}"'.format(i)
            self.trB = self.builder.get_object("trB{}".format(i))
            tr1 = open('/home/clientshared/.Temp/.{}/.tr1.txt'.format(t)).read().strip()
            self.trB.set_text(tr1)
            #te
            te = 'te"{}"'.format(i)
            self.te = self.builder.get_object("te{}".format(i))
            te = open('/home/clientshared/.Temp/.{}/.te.txt'.format(t)).read().strip()
            self.te.set_text(te)
            #etf
            etf = 'etf"{}"'.format(i)
            self.etf = self.builder.get_object("etf{}".format(i))
            etf = open('/home/clientshared/.Temp/.{}/.etf.txt'.format(t)).read().strip()
            self.etf.set_text(etf)

        return False

    def update(self):
        while True:
            GLib.idle_add(self.update_label)
            time.sleep(1)


b = """#!/bin/bash

ac="$1"

employee=$(cat /home/clientshared/.General/.employee)

loadnum=$(cat /home/clientshared/.General/.job_number)

# compnum=$(cat /home/clientshared/.comp.txt)

touch /home/clientshared/.Temp/."$ac"/.prg.txt

touch /home/clientshared/.Temp/."$ac"/.tr.txt
touch /home/clientshared/.Temp/."$ac"/.te.txt
touch /home/clientshared/.Temp/."$ac"/.etf.txt
touch /home/clientshared/.Temp/."$ac"/.s.txt
touch /home/clientshared/.Temp/."$ac"/.t.txt
touch /home/clientshared/.Temp/."$ac"/.c.txt
touch /home/clientshared/.Temp/."$ac"/.p.txt
sleep 3s

prog=$(cat "/home/clientshared/.Temp/."$ac"/.prg.txt")
echo "$prog"
if [[ "$prog" == "Wiping" || "$prog" == "Testing" ]];
then
  true
else
  echo "Started Wiping"
  echo "Wiping" > /home/clientshared/.Temp/."$ac"/.prg.txt
  #send serial number
  touch /home/clientshared/.Temp/."$ac"/.p.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

  touch /home/clientshared/.Temp/."$ac"/.te.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

  touch /home/clientshared/.Temp/."$ac"/.tr.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

  touch /home/clientshared/.Temp/."$ac"/.etf.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

  touch /home/clientshared/.Temp/."$ac"/.t.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.t.txt

  touch /home/clientshared/.Temp/."$ac"/.c.txt
  echo "" > /home/clientshared/.Temp/."$ac"/.c.txt
  ## scan and get data

    acc1="${ac##*B}"
    acc=$(echo "$acc1" | bc)
    if [[ "$acc" -lt 25 ]]
    then
    loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | head -n 1)" | grep -oP '(?<=host).*?(?=/)')
    else
    loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | tail -n 1)" | grep -oP '(?<=host).*?(?=/)')
    fi

    getting=$(cat /home/clientshared/set.txt | grep "$ac" | awk '{print $2}')
    h=$(echo "/sys/class/scsi_host/host"$loc"/device/phy-"$loc":7/port/expander-*/phy-*:"$getting"/port/")
    dev7=$(find $(echo "$h") -type d -name "sd*" | head -n 1)
    dev7="sd${dev7##*sd}"
    echo "$dev7"

  s7=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $6}')
  touch /home/clientshared/.Temp/."$ac"/.dev.txt
  echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt

  # fi
  s5="$s7"
  if [[ "$s5" == "?" ]]; then s5=""; else false; fi
  if [[ ! -z "$s5" ]]
    then
      echo "Drive Present Starting Wipe: $(date)"
      #45 BAY
      acc1="${ac##*B}"
      acc=$(echo "$acc1" | bc)
      if [[ "$acc" -lt 25 ]]
      then
      loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | head -n 1)" | grep -oP '(?<=host).*?(?=/)')
      else
      loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | tail -n 1)" | grep -oP '(?<=host).*?(?=/)')
      fi

      getting=$(cat /home/clientshared/set.txt | grep "$ac" | awk '{print $2}')
      h=$(echo "/sys/class/scsi_host/host"$loc"/device/phy-"$loc":7/port/expander-*/phy-*:"$getting"/port/")
      dev7=$(find $(echo "$h") -type d -name "sd*" | head -n 1)
      dev7="sd${dev7##*sd}"
      echo "$dev7"
      ## scan and get dat
      hdsent=$(sudo /home/clientshared/.HD -dev /dev/"$dev7")
      s7=$(echo "$hdsent" | grep "HDD Serial" | awk '{print $4}')
      #send type
      ttype=$(sudo smartctl -i /dev/"$dev7" | grep -i "ATA Version")
      if [[ ! -z "$ttype" ]]; then t7="SATA"; else t7="SAS"; fi
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      #rotation per minute
      size1=$(sudo smartctl -i /dev/"$dev7" | grep "Form Factor:" | awk '{print $3}')
      rpm=$(sudo smartctl -i /dev/"$dev7" | grep -i "rotation" | awk '{print $3,$4}')
      rpm1=$(sudo smartctl -i /dev/"$dev7" | grep -i "solid")
      if [[ ! -z $rpm1 ]]; then rpm="SSD"; else false; fi
      #manufacturer and model
      hdsent=$(sudo /home/clientshared/.HD -dev /dev/"$dev7")
      mdl=$(echo "$hdsent" | grep "Model" | awk '{print $6,$7,$8,$9,$10,$11,$12,$13}')
      manuf=$(echo "$hdsent" | grep "Model" | awk '{print $5}')
      tmanuf=${manuf:0:2}
      ttmanuf=${manuf:0:3}
      if [[ "$tmanuf" == "ST" ]]; then manuf="SEAGATE"; mdl=$(echo "$hdsent" | grep "Model" | awk '{print $5}'); else false; fi
      if [[ "$tmanuf" == "WD" && "$ttmanuf" != "WDC" ]]; then manuf="WDC"; mdl=$(echo "$hdsent" | grep "Model" | awk '{print $5}'); else false; fi
      #send serial
      touch /home/clientshared/.Temp/."$ac"/.s.txt
      echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
      #send type
      echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      #Remove HPA
      hpasectors=$(sudo hdparm -N /dev/"$dev7" | grep -i "max" | awk '{print $4}' | tr -d ",")
      hpasectors=${hpasectors##*/}
      remove=$(sudo hdparm -N p$hpasectors /dev/"$dev7")       remove=$(sudo hdparm -N /dev/"$dev7")
      sleep 1s
      #send capacity
      c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
      echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      #set Write cache
      w=$(sudo hdparm -W1 /dev/"$dev7")
      sleep 1s
      w=$(sudo sdparm -s WCE /dev/"$dev7")
      sleep 1s
      ## start time
      st=$(date '+%H:%M:%S')
      sts=$(date '+%s' -d "$st")

      #### wiping dump file
      rm -f /home/clientshared/.Temp/."$ac"/.dump.txt
      touch /home/clientshared/.Temp/."$ac"/.dump.txt
      hdsent=$(sudo /home/clientshared/.HD -dev /dev/"$dev7")
      #initial health and set to zero if ?
      htx=$(echo "$hdsent" | grep "Health" | awk '{print $3}')
      if [[ "$htx" == "?" ]]; then htx="0"; else true; fi
      sleep 1
      ##########################################
      ### print up to window
      echo "$h $d $s7 $t7 $c7 $mdl $rpm $htx $s"

      ##date
      dte=$(date "+%Y-%m-%d")

      sleep 2
      # ###Testing how to wipe
      # echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
      # echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      ###
      c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
      echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
      echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
      #get existing percetn if already SAS
      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')
      SSDD=$(sudo blockdev --getsize64 /dev/"$dev7")
      test1=$(sudo smartctl -i /dev/"$dev7" | grep -i "(SPL-3)")
      if [[ -z "$test1" ]]
      then
      ####################################start wiping if SATA
      echo "Drive is SATA capable: Wiping"
      rm -f /home/clientshared/.Temp/."$ac"/.log.log
      touch /home/clientshared/.Temp/."$ac"/.log.log
      SSDD=$(sudo blockdev --getsize64 /dev/"$dev7")
      echo "" > /home/clientshared/.Temp/."$ac"/.log.log
      sudo ddrescue -fnND -r 3 -s ${SSDD//[!0-9]/} -b 8 -K 0 --log-events=/home/clientshared/.Temp/."$ac"/.log.log /dev/zero /dev/"$dev7" > /home/clientshared/.Temp/."$ac"/.dump.txt &
      sleep 2

      ## start time loop
      time1=0
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      while [[ -z "$a" ]]
      do
      ## CURRENT PERCENTAGE
      a=$(cat /home/clientshared/.Temp/."$ac"/.log.log)
      p=$(cat /home/clientshared/.Temp/."$ac"/.dump.txt | grep -a "pct" | tail -n 1 | awk '{print $3}' | tr -d " %, ")
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt
      sleep 1
      b="$p"
      b=${b%.*}
      if [ "$b" -gt 98 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      done
      #####WIPE AS SAS
      else
      ###start formatting
      echo "Drive is not SAS capable and if was started is at $p percent"
      sudo sg_format --format --ffmt=2 -Q -6 -e -l /dev/"$dev7"
      sleep 3s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l /dev/"$dev7"
      sleep 5s
      sudo sg_format --format --ffmt=2 -Q -6 -e -l /dev/"$dev7"
      sleep 3s
      sudo smartctl -i /dev/"$dev7" | grep -i "rotation" | awk '{print $3,$4}'
      sleep 5s
      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')
      if [[ -z "$p" ]]; then sudo sg_format --format -Q -6 -e -l /dev/"$dev7"; else true; fi
      sleep 1s
      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')
      while [[ ! -z "$p" ]]
      do
      ## CURRENT PERCENTAGE

      sleep 1

      ## CURRENT TIME
      ## CURRENT TIME
      ct=$(date '+%H:%M:%S')
      cts=$(date '+%s' -d "$ct")

      ## TIME ELAPSED
      ets=$(expr $cts - $sts)
      te=$(date -d "00:00:00 today + $ets seconds" '+%H:%M:%S')

      ### TIME REMAINING
      #time remaining in seconds
      #trs=$(( $(expr $(expr $(expr 100 / $p)) - 1 ) * ets ))
      trs=$(echo $(echo $(echo 100 / $p | bc -l) - 1 | bc -l) \* $ets | bc -l)
      trs=${trs%.*}

      #time remaining formatted
      tr=$(date -d "00:00:00 today + $trs seconds" '+%H:%M:%S')

      ### TOTAL TIME IT'LL TAKE
      #total time it will take in seconds
      tts=$((trs + ets))
      tt=$(date -d "00:00:00 today + $tts seconds" '+%H:%M:%S')

      ### TIME IT WILL FINISH
      etf=$(date -d "$st today + $tts seconds" '+%I:%M %p')
      ### if goes over
      b="$p"
      b=${b%.*}
      time1=$(( time1 + 1 ))
      if [[ "$time1" -eq 5 ]]; then finalp="$b"; time1=0; else false; fi
      if [ "$b" -gt 97 ]
      then
      final="pass"
      else
      true
      fi
      if [ "$b" -gt 10 ]
      then
      ch="Y"
      else
      ch="N"
      fi
      #echo "
      #
      #Percent: $p

      #Elapsed Time: $te

      #Time Remaing: $tr

      #Total Time: $tt

      #Expected Time Finished: $etf
      #"
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "$p %" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.te.txt
      echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "$tr" > /home/clientshared/.Temp/."$ac"/.tr.txt

      touch /home/clientshared/.Temp/."$ac"/.etf.txt
      echo "$etf" > /home/clientshared/.Temp/."$ac"/.etf.txt

      tr1=${tr::-3}
      touch /home/clientshared/.Temp/."$ac"/.tr1.txt
      echo "$tr1" > /home/clientshared/.Temp/."$ac"/.tr1.txt

      p=$(sudo sg_requests -p /dev/"$dev7" | awk '{print $3}' | sed 's/%//g')
      done
      fi
      ##done wiping
      #####finished now done and clear counts
      echo "Drive Started testing: $(date)"
      echo "Testing" > /home/clientshared/.Temp/."$ac"/.prg.txt
      touch /home/clientshared/.Temp/."$ac"/.p.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

      touch /home/clientshared/.Temp/."$ac"/.tr.txt
      echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

      ### What percent

      #sample if it wipe, if it did, then proceed to test, else result=Failed: Verify
      #sleep 30
      sleep 6s
      if [[ -z "$test1" ]]
      then
       p=$(cat /home/clientshared/.Temp/."$ac"/.log.log | grep -i "End of run" | awk '{print $2}' | tr -d " %, ")
       testp="$p"
       testp=${testp%.*}
       if [[ "$testp" -eq 100 ]]; then final="pass"; else final=""; p+="%"; fi
      else
       if [[ "$final" == "pass" ]]; then true; else p="$finalp"; final=""; p+="%"; fi
      fi
      #verify if went over 97%
        if [ "$final" == "pass" ]
        then
        echo "Drive Passed Write Sequence"
        p="100%"
        #scan for SG
        acc1="${ac##*B}"
        acc=$(echo "$acc1" | bc)
        if [[ "$acc" -lt 25 ]]
        then
        loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | head -n 1)" | grep -oP '(?<=host).*?(?=/)')
        else
        loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | tail -n 1)" | grep -oP '(?<=host).*?(?=/)')
        fi

        getting=$(cat /home/clientshared/set.txt | grep "$ac" | awk '{print $2}')
        h=$(echo "/sys/class/scsi_host/host"$loc"/device/phy-"$loc":7/port/expander-*/phy-*:"$getting"/port/")
        sg7=$(find $(echo "$h") -type d -name "sg*" | head -n 1)
        sgdev="sg${sg7##*sg}"
        echo "$sgdev"
        bloc=$(sudo sginfo -a /dev/"$sgdev" | grep -i "phys" | awk '{print $6}')
        a=$(sudo sg_dd if=/dev/"$sgdev" of=- count=4MB bs="$bloc" dio=1 | od)
        b=$(echo "$a" | tail -n 1)
        echo "number of blocks for verify $b"
        num=$(echo "$a" | wc -l)
        if [[ "$b" -eq "17376444000" || "$b" -eq "17204400000" || "$b" -eq "172044000000" || "$b" -eq "173764440000" ]]; then num1="3"; else num1="1"; fi
        #end verify
        echo "num is $num1, if 3 then verifies, else 1"
        if [[ "$num1" -eq 3 ]]
        then
              echo "Start Self Test for:"
              echo ""
              ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
              if [[ "$ht" == "?" ]]; then ht=0; else false; fi
              #begin testing
              # does device support logging
              t1=$(sudo smartctl -l selftest /dev/"$dev7" | grep -e "does not support")
              if [[ -z "$t1" ]]
                #yes it does
              then
                startest=$(sudo smartctl -t short /dev/"$dev7")
                t1=$(sudo smartctl -l selftest /dev/"$dev7" | grep -e "Background")
                sleep 3
                if [[ ! -z "$t1" ]]
                then
                  startest=$(sudo smartctl -t short /dev/"$dev7")
                  test=$(sudo smartctl -l selftest /dev/"$dev7" | grep -i "Self-test execution status:" )
                  perc=$(echo "$test" | awk '{print $4}')
                  count=1
                  while [[ ! -z "$test" ]]
                  do
                    test=$(sudo smartctl -l selftest /dev/"$dev7" | grep -i "Self-test execution status:" )
                    perc1=$(echo "$test" | awk '{print $1}')
                    if [[ "$perc" != "$perc1" ]]
                    then
                      echo "$perc1"
                    else
                      true
                    fi
                    sleep 3
                    if [[ "$count" -lt 210 ]]
                    then
                      count=$(($count + 1))
                    else
                      test=""
                    fi
                    perc=$(echo "$test" | awk '{print $1}')
                  done
                else
                  startest=$(sudo smartctl -t short /dev/"$dev7")
                  sleep 1
                  test=$(sudo smartctl -c /dev/"$dev7" | grep -i "remaining" )
                  perc=$(echo "$test" | awk '{print $1}')
                  count=1
                  while [[ ! -z "$test" ]]
                  do
                    test=$(sudo smartctl -c /dev/"$dev7" | grep -i "remaining")
                    perc1=$(echo "$test" | awk '{print $1}')
                    if [[ "$perc" != "$perc1" ]]
                    then
                      echo "$perc1"
                    else
                      true
                    fi
                    sleep 1
                    if [[ "$count" -lt 210 ]]
                    then
                      count=$(($count + 1))
                    else
                      test=""
                    fi
                    perc=$(echo "$test" | awk '{print $1}')
                  done
                fi
                result=$(sudo smartctl -l selftest /dev/"$dev7" | grep "# 1")

                #is it the offline type?
                resulta=$(echo "$result" | grep "offline")
                #is it the completed type?
                resultb=$(echo "$result" | grep "Completed")

                if [[ ! -z "$resulta" ]]
                  then
                    resultc=$(sudo smartctl -l selftest /dev/"$dev7" | grep "# 1" | awk '{print $6,$7}')
                      if [ "$resultc" == "without error" ]
                        then
                        ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
                        if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                          if [ "$ht" -gt 59 ]
                            then
                            result="Passed"
                            result2="Passed"
                          else
                            result2="Failed: Health"
                            result="Failed"
                          fi
                      else
                        result2="Failed: DST"
                        result="Failed"
                      fi
              # different for SAS type
                elif [[ ! -z "$resultb" ]]
                    then
                      ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
                      if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                      if [ "$ht" -gt 59 ]
                        then
                          result="Passed"
                          result2="Passed"
                      else
                        result2="Failed: Health"
                        result="Failed"
                      fi
                else
                    result2="Failed: DST"
                    result="Failed"
                  fi
              else
                ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
                if [[ "$ht" == "?" ]]; then ht=0; else ht="$ht"; fi
                if [ "$ht" -gt 59 ]
                  then
                    result="Passed"
                    result2="Passed"
                else
                    result2="Failed: Health SAS"
                    result="Failed"
                fi
              fi
        else
            result2="Failed: Verify"
            result="Failed"
        fi

        echo "$ac result = $result and result2 = $result2"
        ##### testing end
        #send serial
        touch /home/clientshared/.Temp/."$ac"/.s.txt
        echo "$s7" > /home/clientshared/.Temp/."$ac"/.s.txt
        #send type
        echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
        #send capacity
        if [[ -z "$c7" ]]
        then
          c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
        else
          false
        fi
        echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
        echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
        echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
        echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
        echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
        echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
        if [[ "$result" == "Passed" ]] && [[ "$ht" -eq 100 ]]
          then result="Tested for Full Function R2/Ready for Reuse"
        elif [[ "$result" == "Passed" && "$ht" -lt 100 ]]
          then result="Tested for Key Function R2/Ready for Resale"
        else false
        fi
        echo "time to test: $count"
        echo "device: $dev7"
        else
          sleep 1

          #45 BAY
          acc1="${ac##*B}"
          acc=$(echo "$acc1" | bc)
          if [[ "$acc" -lt 25 ]]
          then
          loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | head -n 1)" | grep -oP '(?<=host).*?(?=/)')
          else
          loc=$(echo "$(find /sys/class/scsi_host/host*/device/phy-*:7 -type d -name "power" | grep -v "sas" | tail -n 1)" | grep -oP '(?<=host).*?(?=/)')
          fi

          getting=$(cat /home/clientshared/set.txt | grep "$ac" | awk '{print $2}')
          h=$(echo "/sys/class/scsi_host/host"$loc"/device/phy-"$loc":7/port/expander-*/phy-*:"$getting"/port/")
          dev7=$(find $(echo "$h") -type d -name "sd*" | head -n 1)
          dev7="sd${dev7##*sd}"
          echo "$dev7"

          sleep 1
          ht=$(sudo /home/clientshared/.HD -solid -dev /dev/"$dev7" | awk '{print $3}')
          if [[ "$ht" == "?" ]] || [[ "$ht" == "" ]]; then ht=0; else false; fi
          echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt
          echo "$te" > /home/clientshared/.Temp/."$ac"/.te.txt
          echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt
          result2="Failed: Wiping"
          result="Failed"
          #send serial
          #send type
          echo "$t7" > /home/clientshared/.Temp/."$ac"/.t.txt
          #send capacity
          if [[ -z "$c7" ]]
          then
            c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
          else
            false
          fi
          echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
          echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
          echo "$result" > /home/clientshared/.Temp/."$ac"/.prg.txt
        fi
        dte=$(date "+%Y-%m-%d")
        cserial=$(sudo dmidecode -t system | grep Serial | awk '{print $3}')
    if [[ -z "$ch" ]]; then ch="N"; else true; fi
    if [[ -z "$c7" ]]
    then
      c7=$(sudo smartctl -i /dev/"$dev7" | grep -i "capacity" | awk '{print $5,$6}' | tr -d "[ ]")
    else
      false
    fi
    echo "$c7" > /home/clientshared/.Temp/."$ac"/.c.txt
    echo "$c7 $t7" > /home/clientshared/.Temp/."$ac"/.tc.txt
    me=$(whoami)
    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt
    #location="jasperprogram.TIS_JBOD"

    # location="jasperprogram.TIS"

        running=$(mysql -u stream_client -pvh%G3/DmjM+8.Xk -h ls-4ea15f451c8aec4f3d3aaa1ae11f9f670b0e85ba.cbwhq8cxbmbu.us-east-1.rds.amazonaws.com --port 3306 -se "insert into stream_client.wiping (client, process, result, charge, serial_number, manufacturer, model, capacity, type_drive, size, RPM, date_wiped, job_number, employee, system_name, sub_system_name, system_serial, software_version, compliance, sub_result, time_lapsed, health_init, health_final, perc_done) values ('Stream', 'Wiping', '$result', '$ch', '$s5', '$manuf', '$mdl', '$c7', '$t7', '$size1', '$rpm', '$dte', '$loadnm', '$employee', '$me', '$compnum', '$cserial', 'Jasper Wiping v2.1', 'NIST-800-88 rev1: Clear: Overwrite Method', '$result2', '$te', '$htx', '$ht', '$p')")
  else
    echo "No device shown"
    #is no device
    touch /home/clientshared/.Temp/."$ac"/.p.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.p.txt

    touch /home/clientshared/.Temp/."$ac"/.te.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.te.txt

    touch /home/clientshared/.Temp/."$ac"/.tr.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr.txt

    touch /home/clientshared/.Temp/."$ac"/.etf.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.etf.txt

    touch /home/clientshared/.Temp/."$ac"/.prg.txt
    echo "No Device" > /home/clientshared/.Temp/."$ac"/.prg.txt

    touch /home/clientshared/.Temp/."$ac"/.c.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.c.txt

    touch /home/clientshared/.Temp/."$ac"/.tc.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tc.txt

    touch /home/clientshared/.Temp/."$ac"/.tr1.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.tr1.txt

    touch /home/clientshared/.Temp/."$ac"/.s.txt
    echo "" > /home/clientshared/.Temp/."$ac"/.s.txt

    touch /home/clientshared/.Temp/."$ac"/.dev.txt
    echo "$dev7" > /home/clientshared/.Temp/."$ac"/.dev.txt
  fi
fi
echo "Process $ac done at $p percent" && exit

"""

print("V3.001")
if __name__ == "__main__":
	main = main_window()
	Gtk.main()
